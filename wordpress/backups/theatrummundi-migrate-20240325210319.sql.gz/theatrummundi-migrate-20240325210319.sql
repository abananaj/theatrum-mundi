# WordPress MySQL database migration
#
# Generated: Monday 25. March 2024 21:03 UTC
# Hostname: localhost
# Database: `theatrum`
# URL: //theatrum.ssl
# Path: C:\\Library\\Theatrum Universum\\wp-root
# Tables: tu_actionscheduler_actions, tu_actionscheduler_claims, tu_actionscheduler_groups, tu_actionscheduler_logs, tu_aioseo_cache, tu_aioseo_notifications, tu_aioseo_posts, tu_aioseo_revisions, tu_aioseo_search_statistics_objects, tu_aioseo_terms, tu_aiowps_audit_log, tu_aiowps_debug_log, tu_aiowps_events, tu_aiowps_global_meta, tu_aiowps_logged_in_users, tu_aiowps_login_lockdown, tu_aiowps_message_store, tu_aiowps_permanent_block, tu_blogmeta, tu_blogs, tu_commentmeta, tu_comments, tu_links, tu_litespeed_url, tu_litespeed_url_file, tu_ms_snippets, tu_options, tu_postmeta, tu_posts, tu_registration_log, tu_signups, tu_site, tu_sitemeta, tu_snippets, tu_term_relationships, tu_term_taxonomy, tu_termmeta, tu_terms, tu_usermeta, tu_users, tu_wc_admin_note_actions, tu_wc_admin_notes, tu_wc_category_lookup, tu_wc_customer_lookup, tu_wc_download_log, tu_wc_order_addresses, tu_wc_order_coupon_lookup, tu_wc_order_operational_data, tu_wc_order_product_lookup, tu_wc_order_stats, tu_wc_order_tax_lookup, tu_wc_orders, tu_wc_orders_meta, tu_wc_product_attributes_lookup, tu_wc_product_download_directories, tu_wc_product_meta_lookup, tu_wc_rate_limits, tu_wc_reserved_stock, tu_wc_tax_rate_classes, tu_wc_webhooks, tu_woocommerce_api_keys, tu_woocommerce_attribute_taxonomies, tu_woocommerce_downloadable_product_permissions, tu_woocommerce_log, tu_woocommerce_order_itemmeta, tu_woocommerce_order_items, tu_woocommerce_payment_tokenmeta, tu_woocommerce_payment_tokens, tu_woocommerce_sessions, tu_woocommerce_shipping_zone_locations, tu_woocommerce_shipping_zone_methods, tu_woocommerce_shipping_zones, tu_woocommerce_tax_rate_locations, tu_woocommerce_tax_rates, tu_wpdm_social_shares, tu_wpspf_form_fields, tu_wpspf_payment_entry, tu_wpspf_payment_entry_meta
# Table Prefix: tu_
# Post Types: revision, acf-field, acf-field-group, acf-post-type, attachment, page, post, product, project, wp_block, wp_global_styles, wp_navigation, wp_template, wp_template_part
# Protocol: https
# Multisite: true
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `tu_actionscheduler_actions`
#

DROP TABLE IF EXISTS `tu_actionscheduler_actions`;


#
# Table structure of table `tu_actionscheduler_actions`
#

CREATE TABLE `tu_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `priority` tinyint(3) unsigned NOT NULL DEFAULT '10',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_actionscheduler_actions`
#
INSERT INTO `tu_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `priority`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(31, 'aioseo_send_usage_data', 'pending', '2024-04-03 00:00:18', '2024-04-03 00:00:18', 10, '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1712102418;s:18:"\0*\0first_timestamp";i:1712102418;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1712102418;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1712102418;s:15:"first_timestamp";i:1712102418;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1712102418;s:19:"interval_in_seconds";i:604800;}', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(45, 'action_scheduler/migration_hook', 'complete', '2024-03-25 18:08:04', '2024-03-25 18:08:04', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1711390084;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1711390084;s:19:"scheduled_timestamp";i:1711390084;s:9:"timestamp";i:1711390084;}', 2, 1, '2024-03-25 18:08:32', '2024-03-25 18:08:32', 0, NULL),
(46, 'action_scheduler/migration_hook', 'canceled', '2024-03-25 18:08:04', '2024-03-25 18:08:04', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1711390084;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1711390084;s:19:"scheduled_timestamp";i:1711390084;s:9:"timestamp";i:1711390084;}', 3, 0, '2024-03-25 18:08:32', '2024-03-25 18:08:32', 0, NULL),
(50, 'woocommerce_cleanup_draft_orders', 'complete', '2024-03-25 18:07:09', '2024-03-25 18:07:09', 10, '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1711390029;s:18:"\0*\0first_timestamp";i:1711390029;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1711390029;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1711390029;s:15:"first_timestamp";i:1711390029;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1711390029;s:19:"interval_in_seconds";i:86400;}', 4, 1, '2024-03-25 18:07:09', '2024-03-25 18:07:09', 0, NULL),
(51, 'aioseo_cache_prune', 'pending', '2024-03-26 18:07:09', '2024-03-26 18:07:09', 10, '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1711476429;s:18:"\0*\0first_timestamp";i:1711390019;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1711476429;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1711476429;s:15:"first_timestamp";i:1711390019;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1711476429;s:19:"interval_in_seconds";i:86400;}', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(52, 'woocommerce_cleanup_draft_orders', 'pending', '2024-03-26 18:07:09', '2024-03-26 18:07:09', 10, '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1711476429;s:18:"\0*\0first_timestamp";i:1711390029;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1711476429;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1711476429;s:15:"first_timestamp";i:1711390029;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1711476429;s:19:"interval_in_seconds";i:86400;}', 4, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(54, 'aioseo_v432_unschedule_objects_scan', 'complete', '2024-03-25 18:08:13', '2024-03-25 18:08:13', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1711390093;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1711390093;s:19:"scheduled_timestamp";i:1711390093;s:9:"timestamp";i:1711390093;}', 1, 1, '2024-03-25 18:08:32', '2024-03-25 18:08:32', 0, NULL),
(56, 'aioseo_image_sitemap_scan', 'failed', '2024-03-25 18:23:32', '2024-03-25 18:23:32', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1711391012;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1711391012;s:19:"scheduled_timestamp";i:1711391012;s:9:"timestamp";i:1711391012;}', 1, 1, '2024-03-25 18:24:18', '2024-03-25 18:24:18', 0, NULL),
(57, 'aioseo_old_cache_clean', 'failed', '2024-03-25 18:09:32', '2024-03-25 18:09:32', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1711390172;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1711390172;s:19:"scheduled_timestamp";i:1711390172;s:9:"timestamp";i:1711390172;}', 1, 1, '2024-03-25 18:09:58', '2024-03-25 18:09:58', 0, NULL),
(58, 'action_scheduler/migration_hook', 'complete', '2024-03-25 18:09:37', '2024-03-25 18:09:37', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1711390177;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1711390177;s:19:"scheduled_timestamp";i:1711390177;s:9:"timestamp";i:1711390177;}', 2, 1, '2024-03-25 18:09:58', '2024-03-25 18:09:58', 0, NULL),
(59, 'action_scheduler/migration_hook', 'complete', '2024-03-25 18:11:36', '2024-03-25 18:11:36', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1711390296;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1711390296;s:19:"scheduled_timestamp";i:1711390296;s:9:"timestamp";i:1711390296;}', 2, 1, '2024-03-25 18:12:27', '2024-03-25 18:12:27', 0, NULL),
(60, 'woocommerce_update_marketplace_suggestions', 'complete', '2024-03-25 18:52:42', '2024-03-25 18:52:42', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1711392762;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1711392762;s:19:"scheduled_timestamp";i:1711392762;s:9:"timestamp";i:1711392762;}', 4, 1, '2024-03-25 18:52:44', '2024-03-25 18:52:44', 0, NULL),
(61, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2024-03-25 18:52:47', '2024-03-25 18:52:47', 10, '[69,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1711392767;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1711392767;s:19:"scheduled_timestamp";i:1711392767;s:9:"timestamp";i:1711392767;}', 5, 1, '2024-03-25 18:52:50', '2024-03-25 18:52:50', 0, NULL),
(62, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2024-03-25 18:55:52', '2024-03-25 18:55:52', 10, '[70,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1711392952;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1711392952;s:19:"scheduled_timestamp";i:1711392952;s:9:"timestamp";i:1711392952;}', 5, 1, '2024-03-25 18:56:50', '2024-03-25 18:56:50', 0, NULL),
(63, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2024-03-25 18:55:56', '2024-03-25 18:55:56', 10, '[71,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1711392956;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1711392956;s:19:"scheduled_timestamp";i:1711392956;s:9:"timestamp";i:1711392956;}', 5, 1, '2024-03-25 18:56:50', '2024-03-25 18:56:50', 0, NULL) ;

#
# End of data contents of table `tu_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `tu_actionscheduler_claims`
#

DROP TABLE IF EXISTS `tu_actionscheduler_claims`;


#
# Table structure of table `tu_actionscheduler_claims`
#

CREATE TABLE `tu_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_actionscheduler_claims`
#

#
# End of data contents of table `tu_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `tu_actionscheduler_groups`
#

DROP TABLE IF EXISTS `tu_actionscheduler_groups`;


#
# Table structure of table `tu_actionscheduler_groups`
#

CREATE TABLE `tu_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_actionscheduler_groups`
#
INSERT INTO `tu_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'aioseo'),
(2, 'action-scheduler-migration'),
(3, 'action-scheduler-migration'),
(4, ''),
(5, 'woocommerce-db-updates') ;

#
# End of data contents of table `tu_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `tu_actionscheduler_logs`
#

DROP TABLE IF EXISTS `tu_actionscheduler_logs`;


#
# Table structure of table `tu_actionscheduler_logs`
#

CREATE TABLE `tu_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_actionscheduler_logs`
#
INSERT INTO `tu_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(1, 31, 'action created', '2024-03-25 18:06:57', '2024-03-25 18:06:57'),
(18, 45, 'action created', '2024-03-25 18:07:04', '2024-03-25 18:07:04'),
(19, 46, 'action created', '2024-03-25 18:07:04', '2024-03-25 18:07:04'),
(24, 50, 'action created', '2024-03-25 18:07:09', '2024-03-25 18:07:09'),
(28, 51, 'action created', '2024-03-25 18:07:09', '2024-03-25 18:07:09'),
(35, 50, 'action started via WP Cron', '2024-03-25 18:07:09', '2024-03-25 18:07:09'),
(36, 50, 'action complete via WP Cron', '2024-03-25 18:07:09', '2024-03-25 18:07:09'),
(37, 52, 'action created', '2024-03-25 18:07:09', '2024-03-25 18:07:09'),
(53, 54, 'action created', '2024-03-25 18:07:43', '2024-03-25 18:07:43'),
(58, 56, 'action created', '2024-03-25 18:08:32', '2024-03-25 18:08:32'),
(63, 57, 'action created', '2024-03-25 18:08:32', '2024-03-25 18:08:32'),
(65, 45, 'action started via WP Cron', '2024-03-25 18:08:32', '2024-03-25 18:08:32'),
(66, 46, 'action canceled', '2024-03-25 18:08:32', '2024-03-25 18:08:32'),
(67, 45, 'action complete via WP Cron', '2024-03-25 18:08:32', '2024-03-25 18:08:32'),
(68, 46, 'action ignored via WP Cron', '2024-03-25 18:08:32', '2024-03-25 18:08:32'),
(69, 54, 'action started via WP Cron', '2024-03-25 18:08:32', '2024-03-25 18:08:32'),
(70, 54, 'action complete via WP Cron', '2024-03-25 18:08:32', '2024-03-25 18:08:32'),
(71, 58, 'action created', '2024-03-25 18:08:37', '2024-03-25 18:08:37'),
(72, 57, 'action started via WP Cron', '2024-03-25 18:09:58', '2024-03-25 18:09:58'),
(73, 57, 'action failed via WP Cron: Scheduled action for aioseo_old_cache_clean will not be executed as no callbacks are registered.', '2024-03-25 18:09:58', '2024-03-25 18:09:58'),
(74, 58, 'action started via WP Cron', '2024-03-25 18:09:58', '2024-03-25 18:09:58'),
(75, 58, 'action complete via WP Cron', '2024-03-25 18:09:58', '2024-03-25 18:09:58'),
(76, 59, 'action created', '2024-03-25 18:10:36', '2024-03-25 18:10:36'),
(77, 59, 'action started via WP Cron', '2024-03-25 18:12:27', '2024-03-25 18:12:27'),
(78, 59, 'action complete via WP Cron', '2024-03-25 18:12:27', '2024-03-25 18:12:27'),
(79, 56, 'action started via WP Cron', '2024-03-25 18:24:18', '2024-03-25 18:24:18'),
(80, 56, 'action failed via WP Cron: Scheduled action for aioseo_image_sitemap_scan will not be executed as no callbacks are registered.', '2024-03-25 18:24:18', '2024-03-25 18:24:18'),
(81, 60, 'action created', '2024-03-25 18:52:42', '2024-03-25 18:52:42'),
(82, 60, 'action started via Async Request', '2024-03-25 18:52:44', '2024-03-25 18:52:44'),
(83, 60, 'action complete via Async Request', '2024-03-25 18:52:44', '2024-03-25 18:52:44'),
(84, 61, 'action created', '2024-03-25 18:52:46', '2024-03-25 18:52:46'),
(85, 61, 'action started via Async Request', '2024-03-25 18:52:50', '2024-03-25 18:52:50'),
(86, 61, 'action complete via Async Request', '2024-03-25 18:52:50', '2024-03-25 18:52:50'),
(87, 62, 'action created', '2024-03-25 18:55:51', '2024-03-25 18:55:51'),
(88, 63, 'action created', '2024-03-25 18:55:55', '2024-03-25 18:55:55'),
(89, 62, 'action started via WP Cron', '2024-03-25 18:56:49', '2024-03-25 18:56:49'),
(90, 62, 'action complete via WP Cron', '2024-03-25 18:56:50', '2024-03-25 18:56:50'),
(91, 63, 'action started via WP Cron', '2024-03-25 18:56:50', '2024-03-25 18:56:50'),
(92, 63, 'action complete via WP Cron', '2024-03-25 18:56:50', '2024-03-25 18:56:50') ;

#
# End of data contents of table `tu_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `tu_aioseo_cache`
#

DROP TABLE IF EXISTS `tu_aioseo_cache`;


#
# Table structure of table `tu_aioseo_cache`
#

CREATE TABLE `tu_aioseo_cache` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(80) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `expiration` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ndx_aioseo_cache_key` (`key`),
  KEY `ndx_aioseo_cache_expiration` (`expiration`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aioseo_cache`
#
INSERT INTO `tu_aioseo_cache` ( `id`, `key`, `value`, `expiration`, `created`, `updated`) VALUES
(6, 'addon_check_for_updates', 'b:1;', '2024-03-25 19:07:05', '2024-03-25 18:07:05', '2024-03-25 18:07:05'),
(7, 'admin_notifications_update', 'i:1711476428;', '2024-03-26 18:07:08', '2024-03-25 18:07:08', '2024-03-25 18:07:08'),
(9, 'addons', 'a:9:{i:0;O:8:"stdClass":13:{s:3:"sku";s:16:"aioseo-redirects";s:4:"name";s:19:"Redirection Manager";s:7:"version";s:5:"1.3.8";s:5:"image";N;s:4:"icon";s:480:"PHN2ZyB2aWV3Qm94PSIwIDAgMjQgMjQiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgY2xhc3M9ImFpb3Nlby1yZWRpcmVjdCI+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xMC41OSA5LjE3TDUuNDEgNEw0IDUuNDFMOS4xNyAxMC41OEwxMC41OSA5LjE3Wk0xNC41IDRMMTYuNTQgNi4wNEw0IDE4LjU5TDUuNDEgMjBMMTcuOTYgNy40NkwyMCA5LjVWNEgxNC41Wk0xMy40MiAxNC44MkwxNC44MyAxMy40MUwxNy45NiAxNi41NEwyMCAxNC41VjIwSDE0LjVMMTYuNTUgMTcuOTVMMTMuNDIgMTQuODJaIiBmaWxsPSJjdXJyZW50Q29sb3IiIC8+PC9zdmc+";s:6:"levels";a:4:{i:0;s:8:"business";i:1;s:6:"agency";i:2;s:3:"pro";i:3;s:5:"elite";}s:13:"currentLevels";a:2:{i:0;s:3:"pro";i:1;s:5:"elite";}s:11:"description";s:101:"<p>Our Redirection Manager allows you to create and manage redirects for 404s or modified posts.</p>\n";s:18:"descriptionVersion";i:0;s:10:"productUrl";s:48:"https://aioseo.com/features/redirection-manager/";s:12:"learnMoreUrl";s:48:"https://aioseo.com/features/redirection-manager/";s:9:"manageUrl";s:40:"https://route#aioseo-redirects:redirects";s:8:"features";a:1:{i:0;O:8:"stdClass":2:{s:13:"license_level";s:5:"elite";s:7:"feature";s:19:"404-parent-redirect";}}}i:1;O:8:"stdClass":13:{s:3:"sku";s:21:"aioseo-link-assistant";s:4:"name";s:14:"Link Assistant";s:7:"version";s:5:"1.1.3";s:5:"image";N;s:4:"icon";s:516:"PHN2ZyB2aWV3Qm94PSIwIDAgMjQgMjQiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xMSAxNUg3QzUuMzUgMTUgNCAxMy42NSA0IDEyQzQgMTAuMzUgNS4zNSA5IDcgOUgxMVY3SDdDNC4yNCA3IDIgOS4yNCAyIDEyQzIgMTQuNzYgNC4yNCAxNyA3IDE3SDExVjE1Wk0xNyA3SDEzVjlIMTdDMTguNjUgOSAyMCAxMC4zNSAyMCAxMkMyMCAxMy42NSAxOC42NSAxNSAxNyAxNUgxM1YxN0gxN0MxOS43NiAxNyAyMiAxNC43NiAyMiAxMkMyMiA5LjI0IDE5Ljc2IDcgMTcgN1pNMTYgMTFIOFYxM0gxNlYxMVoiIGZpbGw9ImN1cnJlbnRDb2xvciIvPjwvc3ZnPgo=";s:6:"levels";a:3:{i:0;s:6:"agency";i:1;s:3:"pro";i:2;s:5:"elite";}s:13:"currentLevels";a:2:{i:0;s:3:"pro";i:1;s:5:"elite";}s:11:"description";s:283:"<p>Super-charge your SEO with Link Assistant! Get relevant suggestions for adding internal links to older content as well as finding any orphaned posts that have no internal links. Use our reporting feature to see all link suggestions or add them directly from any page or post.</p>\n";s:18:"descriptionVersion";i:0;s:10:"productUrl";s:39:"https://aioseo.com/docs/link-assistant/";s:12:"learnMoreUrl";s:39:"https://aioseo.com/docs/link-assistant/";s:9:"manageUrl";s:44:"https://route#aioseo-link-assistant:overview";s:8:"features";a:0:{}}i:2;O:8:"stdClass":13:{s:3:"sku";s:20:"aioseo-video-sitemap";s:4:"name";s:13:"Video Sitemap";s:7:"version";s:6:"1.1.13";s:5:"image";N;s:4:"icon";s:420:"PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNMy4zMzMgNWgxMGMuNDU5IDAgLjgzNC4zNzUuODM0LjgzM1Y4Ljc1TDE3LjUgNS40MTd2OS4xNjZsLTMuMzMzLTMuMzMzdjIuOTE3YS44MzYuODM2IDAgMCAxLS44MzQuODMzaC0xMGEuODM2LjgzNiAwIDAgMS0uODMzLS44MzNWNS44MzNjMC0uNDU4LjM3NS0uODMzLjgzMy0uODMzWm05LjE2NyA4LjMzM1Y2LjY2N0g0LjE2N3Y2LjY2NkgxMi41WiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";s:6:"levels";a:5:{i:0;s:10:"individual";i:1;s:8:"business";i:2;s:6:"agency";i:3;s:3:"pro";i:4;s:5:"elite";}s:13:"currentLevels";a:2:{i:0;s:3:"pro";i:1;s:5:"elite";}s:11:"description";s:243:"<p>The Video Sitemap works in much the same way as the XML Sitemap module, it generates an XML Sitemap specifically for video content on your site. Search engines use this information to display rich snippet information in search results.</p>\n";s:18:"descriptionVersion";i:0;s:10:"productUrl";s:54:"https://aioseo.com/docs/how-to-create-a-video-sitemap/";s:12:"learnMoreUrl";s:54:"https://aioseo.com/docs/how-to-create-a-video-sitemap/";s:9:"manageUrl";s:43:"https://route#aioseo-sitemaps:video-sitemap";s:8:"features";a:0:{}}i:3;O:8:"stdClass":13:{s:3:"sku";s:21:"aioseo-local-business";s:4:"name";s:18:"Local Business SEO";s:7:"version";s:5:"1.3.0";s:5:"image";N;s:4:"icon";s:18:"svg-local-business";s:6:"levels";a:5:{i:0;s:8:"business";i:1;s:6:"agency";i:2;s:4:"plus";i:3;s:3:"pro";i:4;s:5:"elite";}s:13:"currentLevels";a:3:{i:0;s:4:"plus";i:1;s:3:"pro";i:2;s:5:"elite";}s:11:"description";s:253:"<p>Local Business schema markup enables you to tell Google about your business, including your business name, address and phone number, opening hours and price range. This information may be displayed as a Knowledge Graph card or business carousel.</p>\n";s:18:"descriptionVersion";i:0;s:10:"productUrl";s:43:"https://aioseo.com/docs/local-business-seo/";s:12:"learnMoreUrl";s:43:"https://aioseo.com/docs/local-business-seo/";s:9:"manageUrl";s:40:"https://route#aioseo-local-seo:locations";s:8:"features";a:0:{}}i:4;O:8:"stdClass":13:{s:3:"sku";s:19:"aioseo-news-sitemap";s:4:"name";s:12:"News Sitemap";s:7:"version";s:6:"1.0.15";s:5:"image";N;s:4:"icon";s:16:"svg-sitemaps-pro";s:6:"levels";a:4:{i:0;s:8:"business";i:1;s:6:"agency";i:2;s:3:"pro";i:3;s:5:"elite";}s:13:"currentLevels";a:2:{i:0;s:3:"pro";i:1;s:5:"elite";}s:11:"description";s:284:"<p>Our Google News Sitemap lets you control which content you submit to Google News and only contains articles that were published in the last 48 hours. In order to submit a News Sitemap to Google, you must have added your site to Google’s Publisher Center and had it approved.</p>\n";s:18:"descriptionVersion";i:0;s:10:"productUrl";s:60:"https://aioseo.com/docs/how-to-create-a-google-news-sitemap/";s:12:"learnMoreUrl";s:60:"https://aioseo.com/docs/how-to-create-a-google-news-sitemap/";s:9:"manageUrl";s:42:"https://route#aioseo-sitemaps:news-sitemap";s:8:"features";a:0:{}}i:5;O:8:"stdClass":13:{s:3:"sku";s:16:"aioseo-index-now";s:4:"name";s:8:"IndexNow";s:7:"version";s:6:"1.0.11";s:5:"image";N;s:4:"icon";s:1836:"PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PHBhdGggZD0iTTE3LjY0NCAxMS42NTVjLS4zMjEtLjIyOS0uNjU0LS40NDYtLjk2NC0uNjk3LS42NDMtLjUzNC0uNjMxLTEuMzcyLjAyMy0xLjg4NC4zMS0uMjQuNjQyLS40NTguOTY0LS42OTcuMTg0LS4xMy4zMjEtLjI5NC4zMzMtLjUzNCAwLS4wMzIgMC0uMDc2LS4wMTItLjEyYTcuNDQyIDcuNDQyIDAgMCAwLTEuODkzLTMuMTQ3Yy0uMjA3LS4yMDctLjQ2LS4yNC0uNzQ2LS4xMmEyMi4wNSAyMi4wNSAwIDAgMS0xLjA2OC40MzZjLS45MTguMzQ4LTEuNjg3LS4wODctMS44MTMtMS4wMjQtLjA0Ni0uMzM4LS4wOC0uNjc1LS4xMTUtMS4wMTMtLjAzNC0uMzctLjI0LS41OTktLjYzLS42NzVhOC40NDYgOC40NDYgMCAwIDAtMy40NjcgMGMtLjM2Ny4wNzYtLjU3NC4yNzItLjYwOC42MzJhMTMuNzggMTMuNzggMCAwIDEtLjE2IDEuMTc2Yy0uMTYxLjgyOC0uOTE5IDEuMjMtMS43NDUuOTE1LS4zNTYtLjEzLS43MTItLjI5NC0xLjA2Ny0uNDQ3LS4zMzMtLjE0MS0uNjA5LS4wODctLjg1LjE2NGE3Ljc3OSA3Ljc3OSAwIDAgMC0xLjc3OSAyLjkxOGMtLjExNC4zMzgtLjAyMy42MS4yODcuODI4LjI5OS4yMDcuNjA5LjQxNC44OTUuNjMyLjc3LjU4OC43NTggMS40NDgtLjAyMiAyLjAxNC0uMjg3LjIwNy0uNTc0LjQxNC0uODYxLjYxLS4zMjIuMjE4LS40MTMuNTEyLS4yOTkuODZhNy44NyA3Ljg3IDAgMCAwIDEuNzQ1IDIuODg3Yy4yNC4yNS41MTYuMzE2Ljg1LjE4NS4zOS0uMTUzLjc2OC0uMzI3IDEuMTU4LS40NjguNzU4LS4yNzMgMS41MTUuMTIgMS42NzYuODcuMDguNDA0LjEyNi44MTguMTYgMS4yMi4wMzUuMzcuMjQxLjU2Ny41OTcuNjQzIDEuMTYuMjQgMi4zMDcuMjQgMy40NjYuMDExLjQxMy0uMDg3LjYwOC0uMzE2LjY0My0uNzA4LjAyMy0uMzI3LjA2OS0uNjUzLjEwMy0uOTcuMTE1LS45MjUuODk1LTEuMzgyIDEuODE0LTEuMDQ1LjM0NC4xMzEuNjg4LjI3MyAxLjAzMi40MjUuMzY4LjE1My42NjYuMDc2LjkxOC0uMjA3YTguNDk0IDguNDk0IDAgMCAwIDEuNzEtMi44MmMuMTUtLjMzOC4wNTgtLjYyMS0uMjc1LS44NXptLTkuNDguNjk3Yy0uMTAzLjEzLS4zMS4xMi0uNDEzLS4wMUw2LjAzIDEwLjE3M2EuMjIuMjIgMCAwIDEgMC0uMjgzbDEuOTI4LTIuNDI5IDEuNDY5IDEuNzItLjYzMS44NS41MjcuNzA4YS4yMDUuMjA1IDAgMCAxLS4wMTEuMjYyem01LjgzLTIuMTc4LTIuNDc5IDMuMDE3YS4yNi4yNiAwIDAgMS0uMjA2LjEwOUg5LjEwNWEuMjUuMjUgMCAwIDEtLjIwNi0uNDAzbDIuMzUzLTIuODY1LTIuNjc0LTMuMjY3aDIuODY5bDIuNTU5IDMuMTI2YS4yMzYuMjM2IDAgMCAxLS4wMTEuMjgzeiIvPjwvc3ZnPg==";s:6:"levels";a:6:{i:0;s:8:"business";i:1;s:6:"agency";i:2;s:5:"basic";i:3;s:4:"plus";i:4;s:3:"pro";i:5;s:5:"elite";}s:13:"currentLevels";a:4:{i:0;s:5:"basic";i:1;s:4:"plus";i:2;s:3:"pro";i:3;s:5:"elite";}s:11:"description";s:193:"<p>Add IndexNow support to instantly notify search engines when your content has changed. This helps the search engines to prioritize the changes on your website and helps you rank faster.</p>\n";s:18:"descriptionVersion";i:0;s:10:"productUrl";s:28:"https://aioseo.com/index-now";s:12:"learnMoreUrl";s:28:"https://aioseo.com/index-now";s:9:"manageUrl";s:45:"https://route#aioseo-settings:webmaster-tools";s:8:"features";a:0:{}}i:6;O:8:"stdClass":13:{s:3:"sku";s:15:"aioseo-rest-api";s:4:"name";s:8:"REST API";s:7:"version";s:5:"1.0.6";s:5:"image";N;s:4:"icon";s:280:"PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgY2xhc3M9ImFpb3Nlby1jb2RlIj48cGF0aCBkPSJNOS40IDE2LjZMNC44IDEybDQuNi00LjZMOCA2bC02IDYgNiA2IDEuNC0xLjR6bTUuMiAwbDQuNi00LjYtNC42LTQuNkwxNiA2bDYgNi02IDYtMS40LTEuNHoiIGZpbGw9ImN1cnJlbnRDb2xvciIvPjwvc3ZnPg==";s:6:"levels";a:3:{i:0;s:4:"plus";i:1;s:3:"pro";i:2;s:5:"elite";}s:13:"currentLevels";a:3:{i:0;s:4:"plus";i:1;s:3:"pro";i:2;s:5:"elite";}s:11:"description";s:137:"<p>Manage your post and term SEO meta via the WordPress REST API. This addon also works seamlessly with headless WordPress installs.</p>\n";s:18:"descriptionVersion";i:0;s:10:"productUrl";s:36:"https://aioseo.com/feature/rest-api/";s:12:"learnMoreUrl";s:36:"https://aioseo.com/feature/rest-api/";s:9:"manageUrl";s:0:"";s:8:"features";a:0:{}}i:7;O:8:"stdClass":13:{s:3:"sku";s:16:"aioseo-image-seo";s:4:"name";s:9:"Image SEO";s:7:"version";s:6:"1.1.11";s:5:"image";N;s:4:"icon";s:436:"PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PHBhdGggZD0iTTE1LjgzMyA0LjE2N3YxMS42NjZINC4xNjdWNC4xNjdoMTEuNjY2Wm0wLTEuNjY3SDQuMTY3QzMuMjUgMi41IDIuNSAzLjI1IDIuNSA0LjE2N3YxMS42NjZjMCAuOTE3Ljc1IDEuNjY3IDEuNjY3IDEuNjY3aDExLjY2NmMuOTE3IDAgMS42NjctLjc1IDEuNjY3LTEuNjY3VjQuMTY3YzAtLjkxNy0uNzUtMS42NjctMS42NjctMS42NjdabS00LjA1IDcuMzgzLTIuNSAzLjIyNUw3LjUgMTAuOTUgNSAxNC4xNjdoMTBsLTMuMjE3LTQuMjg0WiIvPjwvc3ZnPg==";s:6:"levels";a:5:{i:0;s:8:"business";i:1;s:6:"agency";i:2;s:4:"plus";i:3;s:3:"pro";i:4;s:5:"elite";}s:13:"currentLevels";a:3:{i:0;s:4:"plus";i:1;s:3:"pro";i:2;s:5:"elite";}s:11:"description";s:148:"<p>Globally control the Title attribute and Alt text for images in your content. These attributes are essential for both accessibility and SEO.</p>\n";s:18:"descriptionVersion";i:0;s:10:"productUrl";s:71:"https://aioseo.com/docs/using-the-image-seo-features-in-all-in-one-seo/";s:12:"learnMoreUrl";s:71:"https://aioseo.com/docs/using-the-image-seo-features-in-all-in-one-seo/";s:9:"manageUrl";s:44:"https://route#aioseo-search-appearance:media";s:8:"features";a:0:{}}i:8;O:8:"stdClass":13:{s:3:"sku";s:11:"aioseo-eeat";s:4:"name";s:20:"Author SEO (E-E-A-T)";s:7:"version";s:5:"1.1.1";s:5:"image";N;s:4:"icon";s:1380:"PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgLTk2MCA5NjAgOTYwIiB3aWR0aD0iMjQiPjxwYXRoIGQ9Ik00NDAuMTE4LTU2MHEzMy44MzkgMCA1Ny44MTctMjQuMDk3dDIzLjk3OC01Ny45MzVxMC0zMy44MzgtMjMuOTc4LTU3LjY5Ni0yMy45NzgtMjMuODU5LTU3LjgxNy0yMy44NTktMzMuODM4IDAtNTcuOTM0IDIzLjg1OS0yNC4wOTcgMjMuODU4LTI0LjA5NyA1Ny42OTYgMCAzMy44MzggMjQuMDk3IDU3LjkzNVE0MDYuMjgtNTYwIDQ0MC4xMTgtNTYwWk00NDAtMzk2LjQxM3E0NS43MTcgMCA4NS41NzYtMTkuNDc4IDM5Ljg1OS0xOS40NzkgNjkuNTc2LTU2LjE1Mi0zNS45NTYtMjMuNzE4LTc0LjkzNS0zNS44MzdRNDgxLjIzOS01MjAgNDQwLTUyMHQtODAuMjE3IDEyLjEycS0zOC45NzkgMTIuMTE5LTc0LjkzNSAzNS44MzcgMjkuNzE3IDM2LjY3MyA2OS41NzYgNTYuMTUyIDM5Ljg1OSAxOS40NzggODUuNTc2IDE5LjQ3OFptMzg2LjM5MSAyODYuOTM1TDYzNy45MTMtMjk3Ljk1NnEtNDEuNzE3IDMxLjc2MS05MS42OTYgNDkuNDAyUTQ5Ni4yMzktMjMwLjkxMyA0NDAtMjMwLjkxM3EtMTM3LjU4NyAwLTIzMy4zMzctOTUuNzVUMTEwLjkxMy01NjBxMC0xMzcuNTg3IDk1Ljc1LTIzMy4zMzdUNDQwLTg4OS4wODdxMTM3LjU4NyAwIDIzMy4zMzcgOTUuNzVUNzY5LjA4Ny01NjBxMCA1NS43NjEtMTcuNzYxIDEwNS45NzgtMTcuNzYxIDUwLjIxOC00OS41MjEgOTIuMTc0TDg5MC4yODMtMTczLjM3bC02My44OTIgNjMuODkyWk00NDAuMTEzLTMyMS45MTNxOTkuMTU2IDAgMTY4LjU2NS02OS41MjIgNjkuNDA5LTY5LjUyMiA2OS40MDktMTY4LjY3OCAwLTk5LjE1Ni02OS40MDktMTY4LjU2NS02OS40MDktNjkuNDA5LTE2OC41NjUtNjkuNDA5LTk5LjE1NiAwLTE2OC42NzggNjkuNDA5LTY5LjUyMiA2OS40MDktNjkuNTIyIDE2OC41NjUgMCA5OS4xNTYgNjkuNTIyIDE2OC42NzggNjkuNTIyIDY5LjUyMiAxNjguNjc4IDY5LjUyMlpNNDQwLTU2MFoiLz48L3N2Zz4=";s:6:"levels";a:3:{i:0;s:4:"plus";i:1;s:3:"pro";i:2;s:5:"elite";}s:13:"currentLevels";a:3:{i:0;s:4:"plus";i:1;s:3:"pro";i:2;s:5:"elite";}s:11:"description";s:147:"<p>Optimize your site for Google\'s E-E-A-T ranking factor by proving your writer\'s expertise through author schema markup and new UI elements.</p>\n";s:18:"descriptionVersion";i:0;s:10:"productUrl";s:33:"https://aioseo.com/features/eeat/";s:12:"learnMoreUrl";s:33:"https://aioseo.com/features/eeat/";s:9:"manageUrl";s:49:"https://route#aioseo-search-appearance:author-seo";s:8:"features";a:0:{}}}', '2024-03-26 18:07:55', '2024-03-25 18:07:55', '2024-03-25 18:07:55'),
(10, 'translations_all-in-one-seo-pack_plugin', 'a:2:{s:19:"all-in-one-seo-pack";a:1:{s:12:"translations";a:33:{i:0;a:7:{s:8:"language";s:5:"nl_NL";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-18T23:26:25+00:00";s:12:"english_name";s:5:"Dutch";s:11:"native_name";s:10:"Nederlands";s:7:"package";s:77:"https://translate.aioseo.io/all-in-one-seo-pack/all-in-one-seo-pack-nl_NL.zip";s:3:"iso";a:2:{i:0;s:2:"nl";i:1;s:3:"nld";}}i:1;a:7:{s:8:"language";s:5:"fr_FR";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-21T17:26:25+00:00";s:12:"english_name";s:15:"French (France)";s:11:"native_name";s:9:"Français";s:7:"package";s:77:"https://translate.aioseo.io/all-in-one-seo-pack/all-in-one-seo-pack-fr_FR.zip";s:3:"iso";a:1:{i:0;s:2:"fr";}}i:2;a:7:{s:8:"language";s:5:"de_DE";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-18T23:26:25+00:00";s:12:"english_name";s:6:"German";s:11:"native_name";s:7:"Deutsch";s:7:"package";s:77:"https://translate.aioseo.io/all-in-one-seo-pack/all-in-one-seo-pack-de_DE.zip";s:3:"iso";a:1:{i:0;s:2:"de";}}i:3;a:7:{s:8:"language";s:5:"it_IT";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-15T23:26:26+00:00";s:12:"english_name";s:7:"Italian";s:11:"native_name";s:8:"Italiano";s:7:"package";s:77:"https://translate.aioseo.io/all-in-one-seo-pack/all-in-one-seo-pack-it_IT.zip";s:3:"iso";a:2:{i:0;s:2:"it";i:1;s:3:"ita";}}i:4;a:7:{s:8:"language";s:2:"ja";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-17T17:26:25+00:00";s:12:"english_name";s:8:"Japanese";s:11:"native_name";s:9:"日本語";s:7:"package";s:74:"https://translate.aioseo.io/all-in-one-seo-pack/all-in-one-seo-pack-ja.zip";s:3:"iso";a:1:{i:0;s:2:"ja";}}i:5;a:7:{s:8:"language";s:5:"pl_PL";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-20T23:26:26+00:00";s:12:"english_name";s:6:"Polish";s:11:"native_name";s:6:"Polski";s:7:"package";s:77:"https://translate.aioseo.io/all-in-one-seo-pack/all-in-one-seo-pack-pl_PL.zip";s:3:"iso";a:2:{i:0;s:2:"pl";i:1;s:3:"pol";}}i:6;a:7:{s:8:"language";s:5:"pt_BR";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-19T23:26:26+00:00";s:12:"english_name";s:19:"Portuguese (Brazil)";s:11:"native_name";s:20:"Português do Brasil";s:7:"package";s:77:"https://translate.aioseo.io/all-in-one-seo-pack/all-in-one-seo-pack-pt_BR.zip";s:3:"iso";a:2:{i:0;s:2:"pt";i:1;s:3:"por";}}i:7;a:7:{s:8:"language";s:5:"ru_RU";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-21T17:26:25+00:00";s:12:"english_name";s:7:"Russian";s:11:"native_name";s:14:"Русский";s:7:"package";s:77:"https://translate.aioseo.io/all-in-one-seo-pack/all-in-one-seo-pack-ru_RU.zip";s:3:"iso";a:2:{i:0;s:2:"ru";i:1;s:3:"rus";}}i:8;a:7:{s:8:"language";s:5:"es_ES";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-15T11:26:27+00:00";s:12:"english_name";s:15:"Spanish (Spain)";s:11:"native_name";s:8:"Español";s:7:"package";s:77:"https://translate.aioseo.io/all-in-one-seo-pack/all-in-one-seo-pack-es_ES.zip";s:3:"iso";a:3:{i:0;s:2:"es";i:1;s:3:"spa";i:2;s:3:"spa";}}i:9;a:7:{s:8:"language";s:5:"tr_TR";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-17T23:26:24+00:00";s:12:"english_name";s:7:"Turkish";s:11:"native_name";s:8:"Türkçe";s:7:"package";s:77:"https://translate.aioseo.io/all-in-one-seo-pack/all-in-one-seo-pack-tr_TR.zip";s:3:"iso";a:2:{i:0;s:2:"tr";i:1;s:3:"tur";}}i:10;a:7:{s:8:"language";s:2:"af";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T15:25:01+00:00";s:12:"english_name";s:9:"Afrikaans";s:11:"native_name";s:9:"Afrikaans";s:7:"package";s:92:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-af.zip";s:3:"iso";a:2:{i:0;s:2:"af";i:1;s:3:"afr";}}i:11;a:7:{s:8:"language";s:2:"ar";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T15:16:12+00:00";s:12:"english_name";s:6:"Arabic";s:11:"native_name";s:14:"العربية";s:7:"package";s:92:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-ar.zip";s:3:"iso";a:2:{i:0;s:2:"ar";i:1;s:3:"ara";}}i:12;a:7:{s:8:"language";s:5:"bg_BG";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-19T19:24:59+00:00";s:12:"english_name";s:9:"Bulgarian";s:11:"native_name";s:18:"Български";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-bg_BG.zip";s:3:"iso";a:2:{i:0;s:2:"bg";i:1;s:3:"bul";}}i:13;a:7:{s:8:"language";N;s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T15:21:17+00:00";s:12:"english_name";s:7:"Chinese";s:11:"native_name";s:6:"中文";s:7:"package";s:90:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-.zip";s:3:"iso";a:2:{i:0;s:2:"zh";i:1;s:3:"zho";}}i:14;a:7:{s:8:"language";s:5:"zh_HK";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-19T19:24:56+00:00";s:12:"english_name";s:19:"Chinese (Hong Kong)";s:11:"native_name";s:16:"香港中文版	";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-zh_HK.zip";s:3:"iso";a:2:{i:0;s:2:"zh";i:1;s:3:"zho";}}i:15;a:7:{s:8:"language";s:5:"zh_TW";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T12:58:11+00:00";s:12:"english_name";s:16:"Chinese (Taiwan)";s:11:"native_name";s:12:"繁體中文";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-zh_TW.zip";s:3:"iso";a:2:{i:0;s:2:"zh";i:1;s:3:"zho";}}i:16;a:7:{s:8:"language";s:5:"cs_CZ";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T15:30:08+00:00";s:12:"english_name";s:5:"Czech";s:11:"native_name";s:9:"Čeština";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-cs_CZ.zip";s:3:"iso";a:2:{i:0;s:2:"cs";i:1;s:3:"ces";}}i:17;a:7:{s:8:"language";s:5:"nl_BE";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T12:05:00+00:00";s:12:"english_name";s:15:"Dutch (Belgium)";s:11:"native_name";s:20:"Nederlands (België)";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-nl_BE.zip";s:3:"iso";a:2:{i:0;s:2:"nl";i:1;s:3:"nld";}}i:18;a:7:{s:8:"language";s:5:"en_GB";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-19T19:23:50+00:00";s:12:"english_name";s:12:"English (UK)";s:11:"native_name";s:12:"English (UK)";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-en_GB.zip";s:3:"iso";a:3:{i:0;s:2:"en";i:1;s:3:"eng";i:2;s:3:"eng";}}i:19;a:7:{s:8:"language";s:5:"fr_BE";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T15:09:53+00:00";s:12:"english_name";s:16:"French (Belgium)";s:11:"native_name";s:21:"Français de Belgique";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-fr_BE.zip";s:3:"iso";a:2:{i:0;s:2:"fr";i:1;s:3:"fra";}}i:20;a:7:{s:8:"language";s:5:"fr_CA";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T15:08:59+00:00";s:12:"english_name";s:15:"French (Canada)";s:11:"native_name";s:19:"Français du Canada";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-fr_CA.zip";s:3:"iso";a:2:{i:0;s:2:"fr";i:1;s:3:"fra";}}i:21;a:7:{s:8:"language";s:5:"he_IL";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T15:20:35+00:00";s:12:"english_name";s:6:"Hebrew";s:11:"native_name";s:16:"עִבְרִית";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-he_IL.zip";s:3:"iso";a:1:{i:0;s:2:"he";}}i:22;a:7:{s:8:"language";s:5:"hi_IN";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-19T19:24:39+00:00";s:12:"english_name";s:5:"Hindi";s:11:"native_name";s:18:"हिन्दी";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-hi_IN.zip";s:3:"iso";a:2:{i:0;s:2:"hi";i:1;s:3:"hin";}}i:23;a:7:{s:8:"language";s:5:"id_ID";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-19T19:25:01+00:00";s:12:"english_name";s:10:"Indonesian";s:11:"native_name";s:16:"Bahasa Indonesia";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-id_ID.zip";s:3:"iso";a:2:{i:0;s:2:"id";i:1;s:3:"ind";}}i:24;a:7:{s:8:"language";s:5:"ko_KR";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-19T19:24:57+00:00";s:12:"english_name";s:6:"Korean";s:11:"native_name";s:9:"한국어";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-ko_KR.zip";s:3:"iso";a:2:{i:0;s:2:"ko";i:1;s:3:"kor";}}i:25;a:7:{s:8:"language";s:5:"fa_IR";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T15:18:33+00:00";s:12:"english_name";s:7:"Persian";s:11:"native_name";s:10:"فارسی";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-fa_IR.zip";s:3:"iso";a:2:{i:0;s:2:"fa";i:1;s:3:"fas";}}i:26;a:7:{s:8:"language";s:5:"ro_RO";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-19T19:24:58+00:00";s:12:"english_name";s:8:"Romanian";s:11:"native_name";s:8:"Română";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-ro_RO.zip";s:3:"iso";a:2:{i:0;s:2:"ro";i:1;s:3:"ron";}}i:27;a:7:{s:8:"language";s:5:"si_LK";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-19T19:24:55+00:00";s:12:"english_name";s:7:"Sinhala";s:11:"native_name";s:15:"සිංහල";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-si_LK.zip";s:3:"iso";a:2:{i:0;s:2:"si";i:1;s:3:"sin";}}i:28;a:7:{s:8:"language";s:5:"sl_SI";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-19T19:25:00+00:00";s:12:"english_name";s:9:"Slovenian";s:11:"native_name";s:13:"Slovenščina";s:7:"package";s:95:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-sl_SI.zip";s:3:"iso";a:2:{i:0;s:2:"sl";i:1;s:3:"slv";}}i:29;a:7:{s:8:"language";s:2:"tl";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-19T19:24:38+00:00";s:12:"english_name";s:7:"Tagalog";s:11:"native_name";s:7:"Tagalog";s:7:"package";s:92:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-tl.zip";s:3:"iso";a:2:{i:0;s:2:"tl";i:1;s:3:"tgl";}}i:30;a:7:{s:8:"language";s:2:"uk";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-19T19:24:58+00:00";s:12:"english_name";s:9:"Ukrainian";s:11:"native_name";s:20:"Українська";s:7:"package";s:92:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-uk.zip";s:3:"iso";a:2:{i:0;s:2:"uk";i:1;s:3:"ukr";}}i:31;a:7:{s:8:"language";s:2:"ur";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T15:26:16+00:00";s:12:"english_name";s:4:"Urdu";s:11:"native_name";s:8:"اردو";s:7:"package";s:92:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-ur.zip";s:3:"iso";a:2:{i:0;s:2:"ur";i:1;s:3:"urd";}}i:32;a:7:{s:8:"language";s:2:"vi";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T15:32:17+00:00";s:12:"english_name";s:10:"Vietnamese";s:11:"native_name";s:14:"Tiếng Việt";s:7:"package";s:92:"https://packages.translationspress.com/aioseo/all-in-one-seo-pack/all-in-one-seo-pack-vi.zip";s:3:"iso";a:2:{i:0;s:2:"vi";i:1;s:3:"vie";}}}}s:13:"_last_checked";i:1711390077;}', NULL, '2024-03-25 18:07:57', '2024-03-25 18:07:57'),
(11, 'translations_aioseo-pro_plugin', 'a:2:{s:10:"aioseo-pro";a:1:{s:12:"translations";a:27:{i:0;a:7:{s:8:"language";s:5:"nl_NL";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-15T17:26:25+00:00";s:12:"english_name";s:5:"Dutch";s:11:"native_name";s:10:"Nederlands";s:7:"package";s:59:"https://translate.aioseo.io/aioseo-pro/aioseo-pro-nl_NL.zip";s:3:"iso";a:2:{i:0;s:2:"nl";i:1;s:3:"nld";}}i:1;a:7:{s:8:"language";s:5:"fr_FR";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-21T11:26:20+00:00";s:12:"english_name";s:15:"French (France)";s:11:"native_name";s:9:"Français";s:7:"package";s:59:"https://translate.aioseo.io/aioseo-pro/aioseo-pro-fr_FR.zip";s:3:"iso";a:1:{i:0;s:2:"fr";}}i:2;a:7:{s:8:"language";s:5:"de_DE";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-18T23:26:19+00:00";s:12:"english_name";s:6:"German";s:11:"native_name";s:7:"Deutsch";s:7:"package";s:59:"https://translate.aioseo.io/aioseo-pro/aioseo-pro-de_DE.zip";s:3:"iso";a:1:{i:0;s:2:"de";}}i:3;a:7:{s:8:"language";s:5:"it_IT";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-15T23:26:18+00:00";s:12:"english_name";s:7:"Italian";s:11:"native_name";s:8:"Italiano";s:7:"package";s:59:"https://translate.aioseo.io/aioseo-pro/aioseo-pro-it_IT.zip";s:3:"iso";a:2:{i:0;s:2:"it";i:1;s:3:"ita";}}i:4;a:7:{s:8:"language";s:2:"ja";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-18T17:26:20+00:00";s:12:"english_name";s:8:"Japanese";s:11:"native_name";s:9:"日本語";s:7:"package";s:56:"https://translate.aioseo.io/aioseo-pro/aioseo-pro-ja.zip";s:3:"iso";a:1:{i:0;s:2:"ja";}}i:5;a:7:{s:8:"language";s:5:"pl_PL";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-18T23:26:19+00:00";s:12:"english_name";s:6:"Polish";s:11:"native_name";s:6:"Polski";s:7:"package";s:59:"https://translate.aioseo.io/aioseo-pro/aioseo-pro-pl_PL.zip";s:3:"iso";a:2:{i:0;s:2:"pl";i:1;s:3:"pol";}}i:6;a:7:{s:8:"language";s:5:"pt_BR";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-19T23:26:18+00:00";s:12:"english_name";s:19:"Portuguese (Brazil)";s:11:"native_name";s:20:"Português do Brasil";s:7:"package";s:59:"https://translate.aioseo.io/aioseo-pro/aioseo-pro-pt_BR.zip";s:3:"iso";a:2:{i:0;s:2:"pt";i:1;s:3:"por";}}i:7;a:7:{s:8:"language";s:5:"ru_RU";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-19T17:26:49+00:00";s:12:"english_name";s:7:"Russian";s:11:"native_name";s:14:"Русский";s:7:"package";s:59:"https://translate.aioseo.io/aioseo-pro/aioseo-pro-ru_RU.zip";s:3:"iso";a:2:{i:0;s:2:"ru";i:1;s:3:"rus";}}i:8;a:7:{s:8:"language";s:5:"es_ES";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-15T17:26:25+00:00";s:12:"english_name";s:15:"Spanish (Spain)";s:11:"native_name";s:8:"Español";s:7:"package";s:59:"https://translate.aioseo.io/aioseo-pro/aioseo-pro-es_ES.zip";s:3:"iso";a:3:{i:0;s:2:"es";i:1;s:3:"spa";i:2;s:3:"spa";}}i:9;a:7:{s:8:"language";s:5:"tr_TR";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2024-03-17T23:26:16+00:00";s:12:"english_name";s:7:"Turkish";s:11:"native_name";s:8:"Türkçe";s:7:"package";s:59:"https://translate.aioseo.io/aioseo-pro/aioseo-pro-tr_TR.zip";s:3:"iso";a:2:{i:0;s:2:"tr";i:1;s:3:"tur";}}i:10;a:7:{s:8:"language";s:2:"ar";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-21T16:45:59+00:00";s:12:"english_name";s:6:"Arabic";s:11:"native_name";s:14:"العربية";s:7:"package";s:74:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-ar.zip";s:3:"iso";a:2:{i:0;s:2:"ar";i:1;s:3:"ara";}}i:11;a:7:{s:8:"language";s:5:"bg_BG";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-11-27T08:03:09+00:00";s:12:"english_name";s:9:"Bulgarian";s:11:"native_name";s:18:"Български";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-bg_BG.zip";s:3:"iso";a:2:{i:0;s:2:"bg";i:1;s:3:"bul";}}i:12;a:7:{s:8:"language";s:2:"ca";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-21T17:03:32+00:00";s:12:"english_name";s:7:"Catalan";s:11:"native_name";s:7:"Català";s:7:"package";s:74:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-ca.zip";s:3:"iso";a:2:{i:0;s:2:"ca";i:1;s:3:"cat";}}i:13;a:7:{s:8:"language";s:5:"zh_HK";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-16T16:43:35+00:00";s:12:"english_name";s:19:"Chinese (Hong Kong)";s:11:"native_name";s:16:"香港中文版	";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-zh_HK.zip";s:3:"iso";a:2:{i:0;s:2:"zh";i:1;s:3:"zho";}}i:14;a:7:{s:8:"language";s:5:"nl_BE";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-20T14:25:59+00:00";s:12:"english_name";s:15:"Dutch (Belgium)";s:11:"native_name";s:20:"Nederlands (België)";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-nl_BE.zip";s:3:"iso";a:2:{i:0;s:2:"nl";i:1;s:3:"nld";}}i:15;a:7:{s:8:"language";s:5:"en_GB";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-01-24T16:29:11+00:00";s:12:"english_name";s:12:"English (UK)";s:11:"native_name";s:12:"English (UK)";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-en_GB.zip";s:3:"iso";a:3:{i:0;s:2:"en";i:1;s:3:"eng";i:2;s:3:"eng";}}i:16;a:7:{s:8:"language";s:5:"he_IL";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-21T16:47:38+00:00";s:12:"english_name";s:6:"Hebrew";s:11:"native_name";s:16:"עִבְרִית";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-he_IL.zip";s:3:"iso";a:1:{i:0;s:2:"he";}}i:17;a:7:{s:8:"language";s:5:"hi_IN";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-12-04T07:22:12+00:00";s:12:"english_name";s:5:"Hindi";s:11:"native_name";s:18:"हिन्दी";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-hi_IN.zip";s:3:"iso";a:2:{i:0;s:2:"hi";i:1;s:3:"hin";}}i:18;a:7:{s:8:"language";s:5:"id_ID";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-16T16:43:36+00:00";s:12:"english_name";s:10:"Indonesian";s:11:"native_name";s:16:"Bahasa Indonesia";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-id_ID.zip";s:3:"iso";a:2:{i:0;s:2:"id";i:1;s:3:"ind";}}i:19;a:7:{s:8:"language";s:5:"ko_KR";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-16T16:43:35+00:00";s:12:"english_name";s:6:"Korean";s:11:"native_name";s:9:"한국어";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-ko_KR.zip";s:3:"iso";a:2:{i:0;s:2:"ko";i:1;s:3:"kor";}}i:20;a:7:{s:8:"language";s:5:"ro_RO";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-16T16:43:34+00:00";s:12:"english_name";s:8:"Romanian";s:11:"native_name";s:8:"Română";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-ro_RO.zip";s:3:"iso";a:2:{i:0;s:2:"ro";i:1;s:3:"ron";}}i:21;a:7:{s:8:"language";s:5:"si_LK";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-16T16:43:34+00:00";s:12:"english_name";s:7:"Sinhala";s:11:"native_name";s:15:"සිංහල";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-si_LK.zip";s:3:"iso";a:2:{i:0;s:2:"si";i:1;s:3:"sin";}}i:22;a:7:{s:8:"language";s:5:"sl_SI";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-16T16:43:35+00:00";s:12:"english_name";s:9:"Slovenian";s:11:"native_name";s:13:"Slovenščina";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-sl_SI.zip";s:3:"iso";a:2:{i:0;s:2:"sl";i:1;s:3:"slv";}}i:23;a:7:{s:8:"language";s:5:"es_MX";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-21T16:42:40+00:00";s:12:"english_name";s:16:"Spanish (Mexico)";s:11:"native_name";s:19:"Español de México";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-es_MX.zip";s:3:"iso";a:3:{i:0;s:2:"es";i:1;s:3:"spa";i:2;s:3:"spa";}}i:24;a:7:{s:8:"language";s:5:"sv_SE";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-08-21T16:43:04+00:00";s:12:"english_name";s:7:"Swedish";s:11:"native_name";s:7:"Svenska";s:7:"package";s:77:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-sv_SE.zip";s:3:"iso";a:2:{i:0;s:2:"sv";i:1;s:3:"swe";}}i:25;a:7:{s:8:"language";s:2:"tl";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2020-12-04T07:25:30+00:00";s:12:"english_name";s:7:"Tagalog";s:11:"native_name";s:7:"Tagalog";s:7:"package";s:74:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-tl.zip";s:3:"iso";a:2:{i:0;s:2:"tl";i:1;s:3:"tgl";}}i:26;a:7:{s:8:"language";s:2:"uk";s:7:"version";s:3:"1.0";s:7:"updated";s:25:"2023-06-16T16:43:46+00:00";s:12:"english_name";s:9:"Ukrainian";s:11:"native_name";s:20:"Українська";s:7:"package";s:74:"https://packages.translationspress.com/aioseo/aioseo-pro/aioseo-pro-uk.zip";s:3:"iso";a:2:{i:0;s:2:"uk";i:1;s:3:"ukr";}}}}s:13:"_last_checked";i:1711390077;}', NULL, '2024-03-25 18:07:57', '2024-03-25 18:07:57') ;

#
# End of data contents of table `tu_aioseo_cache`
# --------------------------------------------------------



#
# Delete any existing table `tu_aioseo_notifications`
#

DROP TABLE IF EXISTS `tu_aioseo_notifications`;


#
# Table structure of table `tu_aioseo_notifications`
#

CREATE TABLE `tu_aioseo_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(13) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `addon` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `level` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `notification_id` bigint(20) unsigned DEFAULT NULL,
  `notification_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `start` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `button1_label` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `button1_action` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `button2_label` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `button2_action` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dismissed` tinyint(1) NOT NULL DEFAULT '0',
  `new` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ndx_aioseo_notifications_slug` (`slug`),
  KEY `ndx_aioseo_notifications_dates` (`start`,`end`),
  KEY `ndx_aioseo_notifications_type` (`type`),
  KEY `ndx_aioseo_notifications_dismissed` (`dismissed`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aioseo_notifications`
#
INSERT INTO `tu_aioseo_notifications` ( `id`, `slug`, `addon`, `title`, `content`, `type`, `level`, `notification_id`, `notification_name`, `start`, `end`, `button1_label`, `button1_action`, `button2_label`, `button2_action`, `dismissed`, `new`, `created`, `updated`) VALUES
(1, '6601bd428d161', NULL, 'Advanced WooCommerce Support', 'We have detected you are running WooCommerce. Upgrade to AIOSEO Pro to unlock our advanced eCommerce SEO features, including SEO for Product Categories and more.', 'info', '["all"]', NULL, 'woo-upsell', '2024-03-25 18:06:58', NULL, 'Upgrade to Pro', 'https://aioseo.com/pricing/?utm_source=WordPress&utm_campaign=proplugin&utm_medium=woo-notification-upsell-unlicensed', NULL, NULL, 0, 0, '2024-03-25 18:06:58', '2024-03-25 18:06:58') ;

#
# End of data contents of table `tu_aioseo_notifications`
# --------------------------------------------------------



#
# Delete any existing table `tu_aioseo_posts`
#

DROP TABLE IF EXISTS `tu_aioseo_posts`;


#
# Table structure of table `tu_aioseo_posts`
#

CREATE TABLE `tu_aioseo_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `title` text COLLATE utf8mb4_unicode_520_ci,
  `description` text COLLATE utf8mb4_unicode_520_ci,
  `keywords` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `keyphrases` longtext COLLATE utf8mb4_unicode_520_ci,
  `page_analysis` longtext COLLATE utf8mb4_unicode_520_ci,
  `primary_term` longtext COLLATE utf8mb4_unicode_520_ci,
  `canonical_url` text COLLATE utf8mb4_unicode_520_ci,
  `og_title` text COLLATE utf8mb4_unicode_520_ci,
  `og_description` text COLLATE utf8mb4_unicode_520_ci,
  `og_object_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `og_image_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `og_image_url` text COLLATE utf8mb4_unicode_520_ci,
  `og_image_width` int(11) DEFAULT NULL,
  `og_image_height` int(11) DEFAULT NULL,
  `og_image_custom_url` text COLLATE utf8mb4_unicode_520_ci,
  `og_image_custom_fields` text COLLATE utf8mb4_unicode_520_ci,
  `og_video` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `og_custom_url` text COLLATE utf8mb4_unicode_520_ci,
  `og_article_section` text COLLATE utf8mb4_unicode_520_ci,
  `og_article_tags` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_use_og` tinyint(1) DEFAULT '0',
  `twitter_card` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `twitter_image_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `twitter_image_url` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_image_custom_url` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_image_custom_fields` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_title` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_description` text COLLATE utf8mb4_unicode_520_ci,
  `seo_score` int(11) NOT NULL DEFAULT '0',
  `schema` longtext COLLATE utf8mb4_unicode_520_ci,
  `schema_type` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `schema_type_options` longtext COLLATE utf8mb4_unicode_520_ci,
  `pillar_content` tinyint(1) DEFAULT NULL,
  `robots_default` tinyint(1) NOT NULL DEFAULT '1',
  `robots_noindex` tinyint(1) NOT NULL DEFAULT '0',
  `robots_noarchive` tinyint(1) NOT NULL DEFAULT '0',
  `robots_nosnippet` tinyint(1) NOT NULL DEFAULT '0',
  `robots_nofollow` tinyint(1) NOT NULL DEFAULT '0',
  `robots_noimageindex` tinyint(1) NOT NULL DEFAULT '0',
  `robots_noodp` tinyint(1) NOT NULL DEFAULT '0',
  `robots_notranslate` tinyint(1) NOT NULL DEFAULT '0',
  `robots_max_snippet` int(11) DEFAULT NULL,
  `robots_max_videopreview` int(11) DEFAULT NULL,
  `robots_max_imagepreview` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT 'large',
  `images` longtext COLLATE utf8mb4_unicode_520_ci,
  `image_scan_date` datetime DEFAULT NULL,
  `priority` float DEFAULT NULL,
  `frequency` tinytext COLLATE utf8mb4_unicode_520_ci,
  `videos` longtext COLLATE utf8mb4_unicode_520_ci,
  `video_thumbnail` text COLLATE utf8mb4_unicode_520_ci,
  `video_scan_date` datetime DEFAULT NULL,
  `local_seo` longtext COLLATE utf8mb4_unicode_520_ci,
  `limit_modified_date` tinyint(1) NOT NULL DEFAULT '0',
  `options` longtext COLLATE utf8mb4_unicode_520_ci,
  `open_ai` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ndx_aioseo_posts_post_id` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aioseo_posts`
#
INSERT INTO `tu_aioseo_posts` ( `id`, `post_id`, `title`, `description`, `keywords`, `keyphrases`, `page_analysis`, `primary_term`, `canonical_url`, `og_title`, `og_description`, `og_object_type`, `og_image_type`, `og_image_url`, `og_image_width`, `og_image_height`, `og_image_custom_url`, `og_image_custom_fields`, `og_video`, `og_custom_url`, `og_article_section`, `og_article_tags`, `twitter_use_og`, `twitter_card`, `twitter_image_type`, `twitter_image_url`, `twitter_image_custom_url`, `twitter_image_custom_fields`, `twitter_title`, `twitter_description`, `seo_score`, `schema`, `schema_type`, `schema_type_options`, `pillar_content`, `robots_default`, `robots_noindex`, `robots_noarchive`, `robots_nosnippet`, `robots_nofollow`, `robots_noimageindex`, `robots_noodp`, `robots_notranslate`, `robots_max_snippet`, `robots_max_videopreview`, `robots_max_imagepreview`, `images`, `image_scan_date`, `priority`, `frequency`, `videos`, `video_thumbnail`, `video_scan_date`, `local_seo`, `limit_modified_date`, `options`, `open_ai`, `created`, `updated`) VALUES
(1, 26, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, '{"blockGraphs":[],"customGraphs":[],"default":{"data":{"Article":[],"Course":[],"Dataset":[],"FAQPage":[],"Movie":[],"Person":[],"Product":[],"Recipe":[],"Service":[],"SoftwareApplication":[],"WebPage":[]},"graphName":"","isEnabled":true},"graphs":[]}', 'default', NULL, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', '[{"image:loc":"https:\\/\\/theatrum.ssl\\/wp-content\\/uploads\\/2024\\/03\\/placeholder.png"}]', '2024-03-25 18:07:31', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"linkFormat":{"internalLinkCount":0,"linkAssistantDismissed":false},"primaryTerm":{"productEducationDismissed":false}}', NULL, '2024-03-25 18:07:31', '2024-03-25 18:07:31'),
(2, 30, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, '{"blockGraphs":[],"customGraphs":[],"default":{"data":{"Article":[],"Course":[],"Dataset":[],"FAQPage":[],"Movie":[],"Person":[],"Product":[],"Recipe":[],"Service":[],"SoftwareApplication":[],"WebPage":[]},"graphName":"","isEnabled":true},"graphs":[]}', 'default', NULL, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', '[{"image:loc":"https:\\/\\/theatrum.ssl\\/wp-content\\/uploads\\/woocommerce-placeholder.png"}]', '2024-03-25 18:07:31', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"linkFormat":{"internalLinkCount":0,"linkAssistantDismissed":false},"primaryTerm":{"productEducationDismissed":false}}', NULL, '2024-03-25 18:07:31', '2024-03-25 18:07:31'),
(3, 31, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, '{"blockGraphs":[],"customGraphs":[],"default":{"data":{"Article":[],"Course":[],"Dataset":[],"FAQPage":[],"Movie":[],"Person":[],"Product":[],"Recipe":[],"Service":[],"SoftwareApplication":[],"WebPage":[]},"graphName":"","isEnabled":true},"graphs":[]}', 'default', NULL, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, '2024-03-25 18:07:31', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"linkFormat":{"internalLinkCount":0,"linkAssistantDismissed":false},"primaryTerm":{"productEducationDismissed":false}}', NULL, '2024-03-25 18:07:31', '2024-03-25 18:07:31'),
(4, 32, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, '{"blockGraphs":[],"customGraphs":[],"default":{"data":{"Article":[],"Course":[],"Dataset":[],"FAQPage":[],"Movie":[],"Person":[],"Product":[],"Recipe":[],"Service":[],"SoftwareApplication":[],"WebPage":[]},"graphName":"","isEnabled":true},"graphs":[]}', 'default', NULL, 0, 0, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, '2024-03-25 18:07:31', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"linkFormat":{"internalLinkCount":0,"linkAssistantDismissed":false},"primaryTerm":{"productEducationDismissed":false}}', NULL, '2024-03-25 18:07:31', '2024-03-25 18:07:31'),
(5, 33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, '{"blockGraphs":[],"customGraphs":[],"default":{"data":{"Article":[],"Course":[],"Dataset":[],"FAQPage":[],"Movie":[],"Person":[],"Product":[],"Recipe":[],"Service":[],"SoftwareApplication":[],"WebPage":[]},"graphName":"","isEnabled":true},"graphs":[]}', 'default', NULL, 0, 0, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, '2024-03-25 18:07:31', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"linkFormat":{"internalLinkCount":0,"linkAssistantDismissed":false},"primaryTerm":{"productEducationDismissed":false}}', NULL, '2024-03-25 18:07:31', '2024-03-25 18:07:31'),
(6, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, '{"blockGraphs":[],"customGraphs":[],"default":{"data":{"Article":[],"Course":[],"Dataset":[],"FAQPage":[],"Movie":[],"Person":[],"Product":[],"Recipe":[],"Service":[],"SoftwareApplication":[],"WebPage":[]},"graphName":"","isEnabled":true},"graphs":[]}', 'default', NULL, 0, 0, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, '2024-03-25 18:07:31', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"linkFormat":{"internalLinkCount":0,"linkAssistantDismissed":false},"primaryTerm":{"productEducationDismissed":false}}', NULL, '2024-03-25 18:07:31', '2024-03-25 18:07:31'),
(7, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, '{"blockGraphs":[],"customGraphs":[],"default":{"data":{"Article":[],"Course":[],"Dataset":[],"FAQPage":[],"Movie":[],"Person":[],"Product":[],"Recipe":[],"Service":[],"SoftwareApplication":[],"WebPage":[]},"graphName":"","isEnabled":true},"graphs":[]}', 'default', NULL, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, '2024-03-25 18:07:31', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"linkFormat":{"internalLinkCount":0,"linkAssistantDismissed":false},"primaryTerm":{"productEducationDismissed":false}}', NULL, '2024-03-25 18:07:31', '2024-03-25 18:07:31') ;

#
# End of data contents of table `tu_aioseo_posts`
# --------------------------------------------------------



#
# Delete any existing table `tu_aioseo_revisions`
#

DROP TABLE IF EXISTS `tu_aioseo_revisions`;


#
# Table structure of table `tu_aioseo_revisions`
#

CREATE TABLE `tu_aioseo_revisions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `object_id` bigint(20) NOT NULL,
  `object_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `author_id` bigint(20) NOT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `revision_data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `object` (`object_id`,`object_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aioseo_revisions`
#

#
# End of data contents of table `tu_aioseo_revisions`
# --------------------------------------------------------



#
# Delete any existing table `tu_aioseo_search_statistics_objects`
#

DROP TABLE IF EXISTS `tu_aioseo_search_statistics_objects`;


#
# Table structure of table `tu_aioseo_search_statistics_objects`
#

CREATE TABLE `tu_aioseo_search_statistics_objects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` bigint(20) unsigned DEFAULT NULL,
  `object_type` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `object_subtype` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `object_path` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `object_path_hash` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `seo_score` int(11) unsigned NOT NULL,
  `inspection_result` longtext COLLATE utf8mb4_unicode_520_ci,
  `inspection_result_date` datetime DEFAULT NULL,
  `indexed` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ndx_aioseo_object_id1` (`object_id`),
  KEY `ndx_aioseo_object_path_hash1` (`object_path_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aioseo_search_statistics_objects`
#

#
# End of data contents of table `tu_aioseo_search_statistics_objects`
# --------------------------------------------------------



#
# Delete any existing table `tu_aioseo_terms`
#

DROP TABLE IF EXISTS `tu_aioseo_terms`;


#
# Table structure of table `tu_aioseo_terms`
#

CREATE TABLE `tu_aioseo_terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL,
  `title` text COLLATE utf8mb4_unicode_520_ci,
  `description` text COLLATE utf8mb4_unicode_520_ci,
  `keywords` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `canonical_url` text COLLATE utf8mb4_unicode_520_ci,
  `og_title` text COLLATE utf8mb4_unicode_520_ci,
  `og_description` text COLLATE utf8mb4_unicode_520_ci,
  `og_object_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `og_image_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `og_image_url` text COLLATE utf8mb4_unicode_520_ci,
  `og_image_width` int(11) DEFAULT NULL,
  `og_image_height` int(11) DEFAULT NULL,
  `og_image_custom_url` text COLLATE utf8mb4_unicode_520_ci,
  `og_image_custom_fields` text COLLATE utf8mb4_unicode_520_ci,
  `og_video` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `og_custom_url` text COLLATE utf8mb4_unicode_520_ci,
  `og_article_section` text COLLATE utf8mb4_unicode_520_ci,
  `og_article_tags` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_use_og` tinyint(1) DEFAULT '0',
  `twitter_card` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `twitter_image_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `twitter_image_url` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_image_custom_url` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_image_custom_fields` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_title` text COLLATE utf8mb4_unicode_520_ci,
  `twitter_description` text COLLATE utf8mb4_unicode_520_ci,
  `pillar_content` tinyint(1) DEFAULT NULL,
  `robots_default` tinyint(1) NOT NULL DEFAULT '1',
  `robots_noindex` tinyint(1) NOT NULL DEFAULT '0',
  `robots_noarchive` tinyint(1) NOT NULL DEFAULT '0',
  `robots_nosnippet` tinyint(1) NOT NULL DEFAULT '0',
  `robots_nofollow` tinyint(1) NOT NULL DEFAULT '0',
  `robots_noimageindex` tinyint(1) NOT NULL DEFAULT '0',
  `robots_noodp` tinyint(1) NOT NULL DEFAULT '0',
  `robots_notranslate` tinyint(1) NOT NULL DEFAULT '0',
  `robots_max_snippet` int(11) DEFAULT NULL,
  `robots_max_videopreview` int(11) DEFAULT NULL,
  `robots_max_imagepreview` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT 'large',
  `priority` float DEFAULT NULL,
  `frequency` tinytext COLLATE utf8mb4_unicode_520_ci,
  `images` longtext COLLATE utf8mb4_unicode_520_ci,
  `videos` longtext COLLATE utf8mb4_unicode_520_ci,
  `video_scan_date` datetime DEFAULT NULL,
  `local_seo` longtext COLLATE utf8mb4_unicode_520_ci,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ndx_aioseo_terms_term_id` (`term_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aioseo_terms`
#
INSERT INTO `tu_aioseo_terms` ( `id`, `term_id`, `title`, `description`, `keywords`, `canonical_url`, `og_title`, `og_description`, `og_object_type`, `og_image_type`, `og_image_url`, `og_image_width`, `og_image_height`, `og_image_custom_url`, `og_image_custom_fields`, `og_video`, `og_custom_url`, `og_article_section`, `og_article_tags`, `twitter_use_og`, `twitter_card`, `twitter_image_type`, `twitter_image_url`, `twitter_image_custom_url`, `twitter_image_custom_fields`, `twitter_title`, `twitter_description`, `pillar_content`, `robots_default`, `robots_noindex`, `robots_noarchive`, `robots_nosnippet`, `robots_nofollow`, `robots_noimageindex`, `robots_noodp`, `robots_notranslate`, `robots_max_snippet`, `robots_max_videopreview`, `robots_max_imagepreview`, `priority`, `frequency`, `images`, `videos`, `video_scan_date`, `local_seo`, `created`, `updated`) VALUES
(1, 3, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(2, 4, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(3, 5, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(4, 6, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(5, 7, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(6, 8, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(7, 9, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(8, 10, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(9, 11, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(10, 12, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(11, 13, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(12, 14, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(13, 15, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(14, 16, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:06:18', '2024-03-25 18:06:18'),
(15, 17, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'none', NULL, 'default', NULL, NULL, NULL, NULL, '2024-03-25 18:07:02', '2024-03-25 18:07:02') ;

#
# End of data contents of table `tu_aioseo_terms`
# --------------------------------------------------------



#
# Delete any existing table `tu_aiowps_audit_log`
#

DROP TABLE IF EXISTS `tu_aiowps_audit_log`;


#
# Table structure of table `tu_aiowps_audit_log`
#

CREATE TABLE `tu_aiowps_audit_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `network_id` bigint(20) NOT NULL DEFAULT '0',
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `username` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `ip` varchar(45) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `level` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `event_type` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `details` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `stacktrace` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `created` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `ip` (`ip`),
  KEY `level` (`level`),
  KEY `event_type` (`event_type`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aiowps_audit_log`
#
INSERT INTO `tu_aiowps_audit_log` ( `id`, `network_id`, `site_id`, `username`, `ip`, `level`, `event_type`, `details`, `stacktrace`, `created`) VALUES
(1, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"All In One WP Security","version":"5.2.9","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389972),
(2, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"All-in-One Security and Firewall Premium","version":"1.0.3","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389972),
(3, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"All-in-One WP Migration","version":"7.81","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389972),
(4, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"Code Snippets Pro (Premium)","version":"3.6.4","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389973),
(5, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"Health Check &amp; Troubleshooting","version":"1.7.0","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389973),
(6, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"LiteSpeed Cache","version":"6.1","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389973),
(7, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"Media Cleaner","version":"6.7.3","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389973),
(8, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"Media Library Assistant","version":"3.13","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389973),
(9, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"Notion WP Sync Pro","version":"2.0.1","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389974),
(10, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"Query Monitor","version":"3.15.0","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389974),
(11, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"WooCommerce","version":"8.6.1","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389979),
(12, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"WP Dark Mode","version":"5.0.1","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389979),
(13, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"WP Dark Mode Ultimate","version":"3.0.4","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389979),
(14, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"WP Migrate","version":"2.6.10","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389979),
(15, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"WP Migrate Lite","version":"2.6.10","action":"activated","network":"network"}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389979),
(16, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'warning', 'plugin_deactivated', '{"plugin":{"name":"WP Migrate","version":"2.6.10","action":"deactivated","network":"network"}}', 'a:17:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:213;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:18:"plugin_deactivated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:830;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:95:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\wp-migrate-db-pro\\class\\deactivate.php";s:4:"line";i:38;s:8:"function";s:18:"deactivate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:326;s:8:"function";s:32:"wpmdb_deactivate_other_instances";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:12;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:13;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:14;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:869;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:15;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:124;s:8:"function";s:16:"activate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:16;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711389979) ;
INSERT INTO `tu_aiowps_audit_log` ( `id`, `network_id`, `site_id`, `username`, `ip`, `level`, `event_type`, `details`, `stacktrace`, `created`) VALUES
(17, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'warning', 'plugin_deactivated', '{"plugin":{"name":"WP Dark Mode Ultimate","version":"3.0.4","action":"deactivated","network":"network"}}', 'a:11:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:213;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:18:"plugin_deactivated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:830;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:209;s:8:"function";s:18:"deactivate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711390112),
(18, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'warning', 'plugin_deactivated', '{"plugin":{"name":"WP Migrate Lite","version":"2.6.10","action":"deactivated","network":"network"}}', 'a:11:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:213;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:18:"plugin_deactivated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:830;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:209;s:8:"function";s:18:"deactivate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711390116),
(19, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'warning', 'plugin_deactivated', '{"plugin":{"name":"All in One SEO Pro","version":"4.5.3","action":"deactivated","network":"network"}}', 'a:11:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:213;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:18:"plugin_deactivated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:830;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:209;s:8:"function";s:18:"deactivate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711390122),
(20, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'warning', 'plugin_deactivated', '{"plugin":{"name":"WooCommerce","version":"8.6.1","action":"deactivated","network":"network"}}', 'a:11:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:213;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:18:"plugin_deactivated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:830;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:209;s:8:"function";s:18:"deactivate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711390129),
(21, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'warning', 'plugin_deactivated', '{"plugin":{"name":"All-in-One Security and Firewall Premium","version":"1.0.3","action":"deactivated","network":"network"}}', 'a:11:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:213;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:18:"plugin_deactivated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:830;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:209;s:8:"function";s:18:"deactivate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711390235),
(22, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'warning', 'plugin_deactivated', '{"plugin":{"name":"All-in-One WP Migration","version":"7.81","action":"deactivated","network":"network"}}', 'a:11:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:213;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:18:"plugin_deactivated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:830;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:209;s:8:"function";s:18:"deactivate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711390238),
(23, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_updated', '{"plugin":{"name":"Advanced Custom Fields PRO","version":"6.2.6.1","action":"updated","network":""}}', 'a:14:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:198;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:14:"plugin_updated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:81:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-plugin-upgrader.php";s:4:"line";i:414;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:6:{s:4:"file";s:72:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\ajax-actions.php";s:4:"line";i:4627;s:8:"function";s:12:"bulk_upgrade";s:5:"class";s:15:"Plugin_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:21:"wp_ajax_update_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:12;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:13;a:4:{s:4:"file";s:61:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\admin-ajax.php";s:4:"line";i:188;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}}', 1711390247),
(24, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_updated', '{"plugin":{"name":"All in One SEO Pro","version":"4.5.3","action":"updated","network":""}}', 'a:14:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:198;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:14:"plugin_updated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:81:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-plugin-upgrader.php";s:4:"line";i:414;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:6:{s:4:"file";s:72:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\ajax-actions.php";s:4:"line";i:4627;s:8:"function";s:12:"bulk_upgrade";s:5:"class";s:15:"Plugin_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:21:"wp_ajax_update_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:12;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:13;a:4:{s:4:"file";s:61:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\admin-ajax.php";s:4:"line";i:188;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}}', 1711390249),
(25, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_updated', '{"plugin":{"name":"Media Library Assistant","version":"3.14","action":"updated","network":""}}', 'a:14:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:198;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:14:"plugin_updated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:81:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-plugin-upgrader.php";s:4:"line";i:414;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:6:{s:4:"file";s:72:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\ajax-actions.php";s:4:"line";i:4627;s:8:"function";s:12:"bulk_upgrade";s:5:"class";s:15:"Plugin_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:21:"wp_ajax_update_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:12;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:13;a:4:{s:4:"file";s:61:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\admin-ajax.php";s:4:"line";i:188;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}}', 1711390253),
(26, 1, 1, 'theatrum-admin', '172.116.247.151', 'info', 'plugin_updated', '{"plugin":{"name":"Notion WP Sync Pro","version":"2.0.1","action":"updated","network":""}}', 'a:14:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:198;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:14:"plugin_updated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:81:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-plugin-upgrader.php";s:4:"line";i:414;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:6:{s:4:"file";s:72:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\ajax-actions.php";s:4:"line";i:4627;s:8:"function";s:12:"bulk_upgrade";s:5:"class";s:15:"Plugin_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:21:"wp_ajax_update_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:12;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:13;a:4:{s:4:"file";s:61:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\admin-ajax.php";s:4:"line";i:188;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}}', 1711390254),
(27, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_updated', '{"plugin":{"name":"WooCommerce","version":"8.7.0","action":"updated","network":""}}', 'a:14:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:198;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:14:"plugin_updated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:81:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-plugin-upgrader.php";s:4:"line";i:414;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:6:{s:4:"file";s:72:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\ajax-actions.php";s:4:"line";i:4627;s:8:"function";s:12:"bulk_upgrade";s:5:"class";s:15:"Plugin_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:21:"wp_ajax_update_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:12;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:13;a:4:{s:4:"file";s:61:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\admin-ajax.php";s:4:"line";i:188;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}}', 1711390262),
(28, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_updated', '{"plugin":{"name":"WP Dark Mode","version":"5.0.3","action":"updated","network":""}}', 'a:14:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:198;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:14:"plugin_updated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:81:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-plugin-upgrader.php";s:4:"line";i:414;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:6:{s:4:"file";s:72:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\ajax-actions.php";s:4:"line";i:4627;s:8:"function";s:12:"bulk_upgrade";s:5:"class";s:15:"Plugin_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:21:"wp_ajax_update_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:12;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:13;a:4:{s:4:"file";s:61:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\admin-ajax.php";s:4:"line";i:188;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}}', 1711390266),
(29, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'warning', 'plugin_deactivated', '{"plugin":{"name":"WP Dark Mode","version":"5.0.3","action":"deactivated","network":"network"}}', 'a:11:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:213;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:18:"plugin_deactivated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:830;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:209;s:8:"function";s:18:"deactivate_plugins";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711390272),
(30, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'theme_installed', '{"theme":{"name":"Theatrum Fundamentum","version":"1.0.0","action":"installed","network":""}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:394;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:290;s:8:"function";s:19:"event_theme_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:15:"theme_installed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:77:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-wp-upgrader.php";s:4:"line";i:961;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:6:{s:4:"file";s:80:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-theme-upgrader.php";s:4:"line";i:248;s:8:"function";s:3:"run";s:5:"class";s:11:"WP_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:6:{s:4:"file";s:57:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\update.php";s:4:"line";i:332;s:8:"function";s:7:"install";s:5:"class";s:14:"Theme_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:65:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\update.php";s:4:"line";i:17;s:4:"args";a:1:{i:0;s:57:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\update.php";}s:8:"function";s:7:"require";}}', 1711392375),
(31, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'theme_activated', '{"theme":{"name":"Theatrum Fundamentum","action":"activated"}}', 'a:9:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:307;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:326;s:8:"function";s:15:"theme_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:4:{s:4:"file";s:59:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\theme.php";s:4:"line";i:855;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:57:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\themes.php";s:4:"line";i:33;s:8:"function";s:12:"switch_theme";s:4:"args";a:1:{i:0;s:0:"";}}}', 1711392392),
(32, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"WooCommerce","version":"8.7.0","action":"activated","network":""}}', 'a:10:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:58;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}}', 1711392696) ;
INSERT INTO `tu_aiowps_audit_log` ( `id`, `network_id`, `site_id`, `username`, `ip`, `level`, `event_type`, `details`, `stacktrace`, `created`) VALUES
(33, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'successful_logout', '{"successful_logout":{"username":"theatrum-admin","force_logout":""}}', 'a:10:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:639;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:127:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-user-login.php";s:4:"line";i:681;s:8:"function";s:23:"event_successful_logout";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:24:"wp_logout_action_handler";s:5:"class";s:24:"AIOWPSecurity_User_Login";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:63:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\pluggable.php";s:4:"line";i:671;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:50:"C:\\Library\\Theatrum Universum\\wp-root\\wp-login.php";s:4:"line";i:793;s:8:"function";s:9:"wp_logout";s:4:"args";a:1:{i:0;s:0:"";}}}', 1711395486),
(34, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'successful_login', '{"successful_login":{"username":"theatrum-admin"}}', 'a:11:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:621;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:127:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-user-login.php";s:4:"line";i:589;s:8:"function";s:22:"event_successful_login";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:127:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-user-login.php";s:4:"line";i:634;s:8:"function";s:21:"update_login_activity";s:5:"class";s:24:"AIOWPSecurity_User_Login";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:23:"wp_login_action_handler";s:5:"class";s:24:"AIOWPSecurity_User_Login";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\user.php";s:4:"line";i:121;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:50:"C:\\Library\\Theatrum Universum\\wp-root\\wp-login.php";s:4:"line";i:1311;s:8:"function";s:9:"wp_signon";s:4:"args";a:1:{i:0;s:0:"";}}}', 1711395507),
(35, 1, 1, 'theatrum-admin', '172.116.247.151', 'info', 'plugin_activated', '{"plugin":{"name":"WP Migrate","version":"2.6.10","action":"activated","network":"network"}}', 'a:11:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:58;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711399843),
(36, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_installed', '{"plugin":{"name":"WP Migrate","version":"2.6.12","action":"installed","network":""}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:165;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_installed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:77:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-wp-upgrader.php";s:4:"line";i:961;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:6:{s:4:"file";s:81:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-plugin-upgrader.php";s:4:"line";i:135;s:8:"function";s:3:"run";s:5:"class";s:11:"WP_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:6:{s:4:"file";s:57:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\update.php";s:4:"line";i:180;s:8:"function";s:7:"install";s:5:"class";s:15:"Plugin_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:65:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\update.php";s:4:"line";i:17;s:4:"args";a:1:{i:0;s:57:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\update.php";}s:8:"function";s:7:"require";}}', 1711400150),
(37, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_installed', '{"plugin":{"name":"WP Migrate","version":"2.6.12","action":"installed","network":""}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:165;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_installed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:77:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-wp-upgrader.php";s:4:"line";i:961;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:6:{s:4:"file";s:81:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-plugin-upgrader.php";s:4:"line";i:135;s:8:"function";s:3:"run";s:5:"class";s:11:"WP_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:6:{s:4:"file";s:57:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\update.php";s:4:"line";i:180;s:8:"function";s:7:"install";s:5:"class";s:15:"Plugin_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:65:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\update.php";s:4:"line";i:17;s:4:"args";a:1:{i:0;s:57:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\update.php";}s:8:"function";s:7:"require";}}', 1711400154),
(38, 1, 1, 'theatrum-admin', '172.116.247.151', 'info', 'plugin_installed', '{"plugin":{"name":"WP Migrate","version":"2.6.12","action":"installed","network":""}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:165;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_installed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:77:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-wp-upgrader.php";s:4:"line";i:961;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:6:{s:4:"file";s:81:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-plugin-upgrader.php";s:4:"line";i:135;s:8:"function";s:3:"run";s:5:"class";s:11:"WP_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:6:{s:4:"file";s:57:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\update.php";s:4:"line";i:180;s:8:"function";s:7:"install";s:5:"class";s:15:"Plugin_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:65:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\update.php";s:4:"line";i:17;s:4:"args";a:1:{i:0;s:57:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\update.php";}s:8:"function";s:7:"require";}}', 1711400243),
(39, 1, 1, 'theatrum-admin', '172.116.247.151', 'info', 'plugin_installed', '{"plugin":{"name":"WP Migrate","version":"2.6.12","action":"installed","network":""}}', 'a:12:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:165;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_installed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:77:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-wp-upgrader.php";s:4:"line";i:961;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:6:{s:4:"file";s:81:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\class-plugin-upgrader.php";s:4:"line";i:135;s:8:"function";s:3:"run";s:5:"class";s:11:"WP_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:6:{s:4:"file";s:57:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\update.php";s:4:"line";i:180;s:8:"function";s:7:"install";s:5:"class";s:15:"Plugin_Upgrader";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:11;a:4:{s:4:"file";s:65:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\update.php";s:4:"line";i:17;s:4:"args";a:1:{i:0;s:57:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\update.php";}s:8:"function";s:7:"require";}}', 1711400283),
(40, 1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 'info', 'plugin_activated', '{"plugin":{"name":"WP Migrate","version":"2.6.12","action":"activated","network":"network"}}', 'a:11:{i:0;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:12:"record_event";s:5:"class";s:33:"AIOWPSecurity_Audit_Event_Handler";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:1;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:2;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:3;a:4:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:274;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:4;a:6:{s:4:"file";s:129:"C:\\Library\\Theatrum Universum\\wp-root\\wp-content\\plugins\\all-in-one-wp-security-and-firewall\\classes\\wp-security-audit-events.php";s:4:"line";i:178;s:8:"function";s:20:"event_plugin_changed";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:5;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:324;s:8:"function";s:16:"plugin_activated";s:5:"class";s:26:"AIOWPSecurity_Audit_Events";s:4:"type";s:2:"::";s:4:"args";a:1:{i:0;s:0:"";}}i:6;a:6:{s:4:"file";s:67:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\class-wp-hook.php";s:4:"line";i:348;s:8:"function";s:13:"apply_filters";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:7;a:6:{s:4:"file";s:60:"C:\\Library\\Theatrum Universum\\wp-root\\wp-includes\\plugin.php";s:4:"line";i:517;s:8:"function";s:9:"do_action";s:5:"class";s:7:"WP_Hook";s:4:"type";s:2:"->";s:4:"args";a:1:{i:0;s:0:"";}}i:8;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\includes\\plugin.php";s:4:"line";i:720;s:8:"function";s:9:"do_action";s:4:"args";a:1:{i:0;s:0:"";}}i:9;a:4:{s:4:"file";s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";s:4:"line";i:58;s:8:"function";s:15:"activate_plugin";s:4:"args";a:1:{i:0;s:0:"";}}i:10;a:4:{s:4:"file";s:66:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\network\\plugins.php";s:4:"line";i:13;s:4:"args";a:1:{i:0;s:58:"C:\\Library\\Theatrum Universum\\wp-root\\wp-admin\\plugins.php";}s:8:"function";s:7:"require";}}', 1711400285) ;

#
# End of data contents of table `tu_aiowps_audit_log`
# --------------------------------------------------------



#
# Delete any existing table `tu_aiowps_debug_log`
#

DROP TABLE IF EXISTS `tu_aiowps_debug_log`;


#
# Table structure of table `tu_aiowps_debug_log`
#

CREATE TABLE `tu_aiowps_debug_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `logtime` int(10) unsigned DEFAULT NULL,
  `level` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `network_id` bigint(20) NOT NULL DEFAULT '0',
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aiowps_debug_log`
#

#
# End of data contents of table `tu_aiowps_debug_log`
# --------------------------------------------------------



#
# Delete any existing table `tu_aiowps_events`
#

DROP TABLE IF EXISTS `tu_aiowps_events`;


#
# Table structure of table `tu_aiowps_events`
#

CREATE TABLE `tu_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `created` int(10) unsigned DEFAULT NULL,
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aiowps_events`
#

#
# End of data contents of table `tu_aiowps_events`
# --------------------------------------------------------



#
# Delete any existing table `tu_aiowps_global_meta`
#

DROP TABLE IF EXISTS `tu_aiowps_global_meta`;


#
# Table structure of table `tu_aiowps_global_meta`
#

CREATE TABLE `tu_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `created` int(10) unsigned DEFAULT NULL,
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aiowps_global_meta`
#

#
# End of data contents of table `tu_aiowps_global_meta`
# --------------------------------------------------------



#
# Delete any existing table `tu_aiowps_logged_in_users`
#

DROP TABLE IF EXISTS `tu_aiowps_logged_in_users`;


#
# Table structure of table `tu_aiowps_logged_in_users`
#

CREATE TABLE `tu_aiowps_logged_in_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `site_id` bigint(20) NOT NULL,
  `created` int(10) unsigned DEFAULT NULL,
  `expires` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_id` (`user_id`),
  KEY `created` (`created`),
  KEY `expires` (`expires`),
  KEY `user_id` (`user_id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aiowps_logged_in_users`
#
INSERT INTO `tu_aiowps_logged_in_users` ( `id`, `user_id`, `username`, `ip_address`, `site_id`, `created`, `expires`) VALUES
(1, 1, 'theatrum-admin', '2603:8001:4041:9d53:1562:a1e4:733b:ded3', 1, 1711395507, 1711568307) ;

#
# End of data contents of table `tu_aiowps_logged_in_users`
# --------------------------------------------------------



#
# Delete any existing table `tu_aiowps_login_lockdown`
#

DROP TABLE IF EXISTS `tu_aiowps_login_lockdown`;


#
# Table structure of table `tu_aiowps_login_lockdown`
#

CREATE TABLE `tu_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `created` int(10) unsigned DEFAULT NULL,
  `release_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `released` int(10) unsigned DEFAULT NULL,
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `is_lockout_email_sent` tinyint(1) NOT NULL DEFAULT '1',
  `backtrace_log` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `ip_lookup_result` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `failed_login_ip` (`failed_login_ip`),
  KEY `is_lockout_email_sent` (`is_lockout_email_sent`),
  KEY `unlock_key` (`unlock_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aiowps_login_lockdown`
#

#
# End of data contents of table `tu_aiowps_login_lockdown`
# --------------------------------------------------------



#
# Delete any existing table `tu_aiowps_message_store`
#

DROP TABLE IF EXISTS `tu_aiowps_message_store`;


#
# Table structure of table `tu_aiowps_message_store`
#

CREATE TABLE `tu_aiowps_message_store` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message_key` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message_value` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `created` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aiowps_message_store`
#

#
# End of data contents of table `tu_aiowps_message_store`
# --------------------------------------------------------



#
# Delete any existing table `tu_aiowps_permanent_block`
#

DROP TABLE IF EXISTS `tu_aiowps_permanent_block`;


#
# Table structure of table `tu_aiowps_permanent_block`
#

CREATE TABLE `tu_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `created` int(10) unsigned DEFAULT NULL,
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `blocked_ip` (`blocked_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_aiowps_permanent_block`
#

#
# End of data contents of table `tu_aiowps_permanent_block`
# --------------------------------------------------------



#
# Delete any existing table `tu_blogmeta`
#

DROP TABLE IF EXISTS `tu_blogmeta`;


#
# Table structure of table `tu_blogmeta`
#

CREATE TABLE `tu_blogmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `blog_id` (`blog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_blogmeta`
#

#
# End of data contents of table `tu_blogmeta`
# --------------------------------------------------------



#
# Delete any existing table `tu_blogs`
#

DROP TABLE IF EXISTS `tu_blogs`;


#
# Table structure of table `tu_blogs`
#

CREATE TABLE `tu_blogs` (
  `blog_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `domain` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `public` tinyint(2) NOT NULL DEFAULT '1',
  `archived` tinyint(2) NOT NULL DEFAULT '0',
  `mature` tinyint(2) NOT NULL DEFAULT '0',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  `lang_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`blog_id`),
  KEY `domain` (`domain`(50),`path`(5)),
  KEY `lang_id` (`lang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_blogs`
#
INSERT INTO `tu_blogs` ( `blog_id`, `site_id`, `domain`, `path`, `registered`, `last_updated`, `public`, `archived`, `mature`, `spam`, `deleted`, `lang_id`) VALUES
(1, 1, 'theatrum.ssl', '/', '2024-03-25 05:31:33', '2024-03-25 20:07:52', 1, 0, 0, 0, 0, 0) ;

#
# End of data contents of table `tu_blogs`
# --------------------------------------------------------



#
# Delete any existing table `tu_commentmeta`
#

DROP TABLE IF EXISTS `tu_commentmeta`;


#
# Table structure of table `tu_commentmeta`
#

CREATE TABLE `tu_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_commentmeta`
#

#
# End of data contents of table `tu_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `tu_comments`
#

DROP TABLE IF EXISTS `tu_comments`;


#
# Table structure of table `tu_comments`
#

CREATE TABLE `tu_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_comments`
#
INSERT INTO `tu_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2024-03-25 05:27:36', '2024-03-25 05:27:36', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `tu_comments`
# --------------------------------------------------------



#
# Delete any existing table `tu_links`
#

DROP TABLE IF EXISTS `tu_links`;


#
# Table structure of table `tu_links`
#

CREATE TABLE `tu_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_links`
#

#
# End of data contents of table `tu_links`
# --------------------------------------------------------



#
# Delete any existing table `tu_litespeed_url`
#

DROP TABLE IF EXISTS `tu_litespeed_url`;


#
# Table structure of table `tu_litespeed_url`
#

CREATE TABLE `tu_litespeed_url` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `cache_tags` varchar(1000) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`(191)),
  KEY `cache_tags` (`cache_tags`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_litespeed_url`
#

#
# End of data contents of table `tu_litespeed_url`
# --------------------------------------------------------



#
# Delete any existing table `tu_litespeed_url_file`
#

DROP TABLE IF EXISTS `tu_litespeed_url_file`;


#
# Table structure of table `tu_litespeed_url_file`
#

CREATE TABLE `tu_litespeed_url_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url_id` bigint(20) NOT NULL,
  `vary` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'md5 of final vary',
  `filename` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'md5 of file content',
  `type` tinyint(4) NOT NULL COMMENT 'css=1,js=2,ccss=3,ucss=4',
  `mobile` tinyint(4) NOT NULL COMMENT 'mobile=1',
  `webp` tinyint(4) NOT NULL COMMENT 'webp=1',
  `expired` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `filename` (`filename`),
  KEY `type` (`type`),
  KEY `url_id_2` (`url_id`,`vary`,`type`),
  KEY `filename_2` (`filename`,`expired`),
  KEY `url_id` (`url_id`,`expired`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_litespeed_url_file`
#

#
# End of data contents of table `tu_litespeed_url_file`
# --------------------------------------------------------



#
# Delete any existing table `tu_ms_snippets`
#

DROP TABLE IF EXISTS `tu_ms_snippets`;


#
# Table structure of table `tu_ms_snippets`
#

CREATE TABLE `tu_ms_snippets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `code` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tags` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scope` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'global',
  `priority` smallint(6) NOT NULL DEFAULT '10',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `revision` bigint(20) NOT NULL DEFAULT '1',
  `cloud_id` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scope` (`scope`),
  KEY `active` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_ms_snippets`
#
INSERT INTO `tu_ms_snippets` ( `id`, `name`, `description`, `code`, `tags`, `scope`, `priority`, `active`, `modified`, `revision`, `cloud_id`) VALUES
(1, 'Make upload filenames lowercase', 'Makes sure that image and file uploads have lowercase filenames.\n\nThis is a sample snippet. Feel free to use it, edit it, or remove it.', 'add_filter( \'sanitize_file_name\', \'mb_strtolower\' );', 'sample, media', 'global', 10, 0, '2024-03-25 18:06:54', 3, NULL),
(2, 'Disable admin bar', 'Turns off the WordPress admin bar for everyone except administrators.\n\nThis is a sample snippet. Feel free to use it, edit it, or remove it.', 'add_action( \'wp\', function () {\n	if ( ! current_user_can( \'manage_options\' ) ) {\n		show_admin_bar( false );\n	}\n} );', 'sample, admin-bar', 'front-end', 10, 0, '2024-03-25 18:06:54', 3, NULL),
(3, 'Allow smilies', 'Allows smiley conversion in obscure places.\n\nThis is a sample snippet. Feel free to use it, edit it, or remove it.', 'add_filter( \'widget_text\', \'convert_smilies\' );\nadd_filter( \'the_title\', \'convert_smilies\' );\nadd_filter( \'wp_title\', \'convert_smilies\' );\nadd_filter( \'get_bloginfo\', \'convert_smilies\' );', 'sample', 'global', 10, 0, '2024-03-25 18:06:54', 3, NULL),
(4, 'Current year', 'Shortcode for inserting the current year into a post or page..\n\nThis is a sample snippet. Feel free to use it, edit it, or remove it.', '<?php echo date( \'Y\' ); ?>', 'sample, dates', 'content', 10, 0, '2024-03-25 18:06:54', 3, NULL) ;

#
# End of data contents of table `tu_ms_snippets`
# --------------------------------------------------------



#
# Delete any existing table `tu_options`
#

DROP TABLE IF EXISTS `tu_options`;


#
# Table structure of table `tu_options`
#

CREATE TABLE `tu_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1034 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_options`
#
INSERT INTO `tu_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'https://theatrum.ssl', 'yes'),
(2, 'home', 'https://theatrum.ssl', 'yes'),
(3, 'blogname', 'Theatrum Mundi', 'yes'),
(4, 'blogdescription', 'All the world&#039;s a stage...', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'anna@theatrummundi.co', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '1', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/blog/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:219:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:7:"shop/?$";s:27:"index.php?post_type=product";s:37:"shop/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:32:"shop/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:24:"shop/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:22:"^wc-api/v([1-3]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-3]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:24:"^wc-auth/v([1]{1})/(.*)?";s:63:"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]";s:21:"^wc/file/transient/?$";s:33:"index.php?wc-transient-file-name=";s:24:"^wc/file/transient/(.+)$";s:44:"index.php?wc-transient-file-name=$matches[1]";s:52:"blog/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:47:"blog/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:28:"blog/category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:40:"blog/category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:37:"blog/category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:48:"blog/category/(.+?)/wc/file/transient(/(.*))?/?$";s:65:"index.php?category_name=$matches[1]&wc/file/transient=$matches[3]";s:22:"blog/category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:49:"blog/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:44:"blog/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:25:"blog/tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:37:"blog/tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:34:"blog/tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:45:"blog/tag/([^/]+)/wc/file/transient(/(.*))?/?$";s:55:"index.php?tag=$matches[1]&wc/file/transient=$matches[3]";s:19:"blog/tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:50:"blog/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:45:"blog/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:26:"blog/type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:38:"blog/type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:20:"blog/type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:40:"blog/project/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"blog/project/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"blog/project/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"blog/project/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"blog/project/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:46:"blog/project/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:29:"blog/project/([^/]+)/embed/?$";s:40:"index.php?project=$matches[1]&embed=true";s:33:"blog/project/([^/]+)/trackback/?$";s:34:"index.php?project=$matches[1]&tb=1";s:41:"blog/project/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&paged=$matches[2]";s:48:"blog/project/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&cpage=$matches[2]";s:38:"blog/project/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?project=$matches[1]&wc-api=$matches[3]";s:49:"blog/project/([^/]+)/wc/file/transient(/(.*))?/?$";s:59:"index.php?project=$matches[1]&wc/file/transient=$matches[3]";s:44:"blog/project/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:55:"blog/project/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:55:"blog/project/[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:66:"blog/project/[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:37:"blog/project/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?project=$matches[1]&page=$matches[2]";s:29:"blog/project/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"blog/project/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"blog/project/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"blog/project/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"blog/project/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"blog/project/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:65:"blog/attachment_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?attachment_category=$matches[1]&feed=$matches[2]";s:60:"blog/attachment_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?attachment_category=$matches[1]&feed=$matches[2]";s:41:"blog/attachment_category/([^/]+)/embed/?$";s:52:"index.php?attachment_category=$matches[1]&embed=true";s:53:"blog/attachment_category/([^/]+)/page/?([0-9]{1,})/?$";s:59:"index.php?attachment_category=$matches[1]&paged=$matches[2]";s:35:"blog/attachment_category/([^/]+)/?$";s:41:"index.php?attachment_category=$matches[1]";s:60:"blog/attachment_tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?attachment_tag=$matches[1]&feed=$matches[2]";s:55:"blog/attachment_tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?attachment_tag=$matches[1]&feed=$matches[2]";s:36:"blog/attachment_tag/([^/]+)/embed/?$";s:47:"index.php?attachment_tag=$matches[1]&embed=true";s:48:"blog/attachment_tag/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?attachment_tag=$matches[1]&paged=$matches[2]";s:30:"blog/attachment_tag/([^/]+)/?$";s:36:"index.php?attachment_tag=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"product/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"product/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:33:"product/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?product=$matches[1]&wc-api=$matches[3]";s:44:"product/([^/]+)/wc/file/transient(/(.*))?/?$";s:59:"index.php?product=$matches[1]&wc/file/transient=$matches[3]";s:39:"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"product/[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:61:"product/[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:32:"product/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"product/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:55:"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:50:"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:31:"product-category/(.+?)/embed/?$";s:44:"index.php?product_cat=$matches[1]&embed=true";s:43:"product-category/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:25:"product-category/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:52:"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:47:"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:28:"product-tag/([^/]+)/embed/?$";s:44:"index.php?product_tag=$matches[1]&embed=true";s:40:"product-tag/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:22:"product-tag/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:16:".*wp-signup.php$";s:21:"index.php?signup=true";s:18:".*wp-activate.php$";s:23:"index.php?activate=true";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=11&cpage=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:28:"wc/file/transient(/(.*))?/?$";s:40:"index.php?&wc/file/transient=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:37:"comments/wc/file/transient(/(.*))?/?$";s:40:"index.php?&wc/file/transient=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:40:"search/(.+)/wc/file/transient(/(.*))?/?$";s:53:"index.php?s=$matches[1]&wc/file/transient=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:52:"blog/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:47:"blog/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:28:"blog/author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:40:"blog/author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:37:"blog/author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:48:"blog/author/([^/]+)/wc/file/transient(/(.*))?/?$";s:63:"index.php?author_name=$matches[1]&wc/file/transient=$matches[3]";s:22:"blog/author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:74:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:69:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:50:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:62:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:59:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:70:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc/file/transient(/(.*))?/?$";s:93:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc/file/transient=$matches[5]";s:44:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:61:"blog/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:56:"blog/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:37:"blog/([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:49:"blog/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:46:"blog/([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:57:"blog/([0-9]{4})/([0-9]{1,2})/wc/file/transient(/(.*))?/?$";s:77:"index.php?year=$matches[1]&monthnum=$matches[2]&wc/file/transient=$matches[4]";s:31:"blog/([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:48:"blog/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:43:"blog/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:24:"blog/([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:36:"blog/([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:33:"blog/([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:44:"blog/([0-9]{4})/wc/file/transient(/(.*))?/?$";s:56:"index.php?year=$matches[1]&wc/file/transient=$matches[3]";s:18:"blog/([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:63:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:73:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:93:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:88:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:88:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:69:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:58:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:62:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:82:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:77:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:70:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:77:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:67:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/wc-api(/(.*))?/?$";s:99:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&wc-api=$matches[6]";s:78:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/wc/file/transient(/(.*))?/?$";s:110:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&wc/file/transient=$matches[6]";s:67:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:78:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:78:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:89:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:66:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:52:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:62:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:82:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:77:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:77:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:58:"blog/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:69:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:56:"blog/([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:43:"blog/([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:25:"(.?.+?)/orders(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&orders=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:28:"(.?.+?)/downloads(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&downloads=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:34:"(.?.+?)/payment-methods(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&payment-methods=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:40:"(.?.+?)/delete-payment-method(/(.*))?/?$";s:64:"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]";s:45:"(.?.+?)/set-default-payment-method(/(.*))?/?$";s:69:"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:36:"(.?.+?)/wc/file/transient(/(.*))?/?$";s:60:"index.php?pagename=$matches[1]&wc/file/transient=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:53:".?.+?/attachment/([^/]+)/wc/file/transient(/(.*))?/?$";s:62:"index.php?attachment=$matches[1]&wc/file/transient=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:1:{i:0;s:27:"woocommerce/woocommerce.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'theatrum-fundamentum', 'yes'),
(41, 'stylesheet', 'theatrum-fundamentum', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '56657', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:5:{s:53:"advanced-database-cleaner-pro/advanced-db-cleaner.php";a:2:{i:0;s:28:"ADBC_Advanced_DB_Cleaner_Pro";i:1;s:14:"aDBc_uninstall";}s:51:"all-in-one-wp-security-and-firewall/wp-security.php";a:2:{i:0;s:15:"AIO_WP_Security";i:1;s:17:"uninstall_handler";}s:62:"all-in-one-wp-security-and-firewall-premium/aiowps-premium.php";a:2:{i:0;s:14:"AIOWPS_PREMIUM";i:1;s:17:"uninstall_handler";}s:35:"litespeed-cache/litespeed-cache.php";s:47:"LiteSpeed\\Activation::uninstall_litespeed_cache";s:87:"wp-service-payment-form-with-authorizenet/wp-service-payment-form-with-authorizenet.php";s:18:"wpspf_on_uninstall";}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '65', 'yes'),
(82, 'page_on_front', '11', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1726896455', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'wp_attachment_pages_enabled', '0', 'yes'),
(100, 'initial_db_version', '56657', 'yes') ;
INSERT INTO `tu_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'tu_user_roles', 'a:9:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:141:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:17:"aioseo_manage_seo";b:1;s:20:"aioseo_page_analysis";b:1;s:28:"aioseo_page_general_settings";b:1;s:29:"aioseo_page_advanced_settings";b:1;s:27:"aioseo_page_schema_settings";b:1;s:27:"aioseo_page_social_settings";b:1;s:16:"aioseo_dashboard";b:1;s:23:"aioseo_general_settings";b:1;s:33:"aioseo_search_appearance_settings";b:1;s:31:"aioseo_social_networks_settings";b:1;s:23:"aioseo_sitemap_settings";b:1;s:30:"aioseo_link_assistant_settings";b:1;s:23:"aioseo_redirects_manage";b:1;s:28:"aioseo_page_redirects_manage";b:1;s:25:"aioseo_redirects_settings";b:1;s:28:"aioseo_seo_analysis_settings";b:1;s:33:"aioseo_search_statistics_settings";b:1;s:21:"aioseo_tools_settings";b:1;s:31:"aioseo_feature_manager_settings";b:1;s:35:"aioseo_page_link_assistant_settings";b:1;s:30:"aioseo_page_redirects_settings";b:1;s:25:"aioseo_local_seo_settings";b:1;s:30:"aioseo_page_local_seo_settings";b:1;s:20:"aioseo_about_us_page";b:1;s:19:"aioseo_setup_wizard";b:1;s:34:"aioseo_page_seo_revisions_settings";b:1;s:12:"aioseo_admin";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:46:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:20:"aioseo_page_analysis";b:1;s:28:"aioseo_page_general_settings";b:1;s:29:"aioseo_page_advanced_settings";b:1;s:27:"aioseo_page_schema_settings";b:1;s:27:"aioseo_page_social_settings";b:1;s:23:"aioseo_general_settings";b:1;s:33:"aioseo_search_appearance_settings";b:1;s:31:"aioseo_social_networks_settings";b:1;s:23:"aioseo_redirects_manage";b:1;s:28:"aioseo_page_redirects_manage";b:1;s:20:"aioseo_about_us_page";b:1;s:34:"aioseo_page_seo_revisions_settings";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:15:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"aioseo_page_analysis";b:1;s:28:"aioseo_page_general_settings";b:1;s:29:"aioseo_page_advanced_settings";b:1;s:27:"aioseo_page_schema_settings";b:1;s:27:"aioseo_page_social_settings";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:10:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:20:"aioseo_page_analysis";b:1;s:28:"aioseo_page_general_settings";b:1;s:29:"aioseo_page_advanced_settings";b:1;s:27:"aioseo_page_schema_settings";b:1;s:27:"aioseo_page_social_settings";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:14:"aioseo_manager";a:2:{s:4:"name";s:11:"SEO Manager";s:12:"capabilities";a:31:{s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:10:"edit_pages";b:1;s:10:"edit_posts";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:20:"edit_published_pages";b:1;s:20:"edit_published_posts";b:1;s:17:"manage_categories";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:4:"read";b:1;s:16:"aioseo_dashboard";b:1;s:23:"aioseo_general_settings";b:1;s:23:"aioseo_sitemap_settings";b:1;s:30:"aioseo_link_assistant_settings";b:1;s:23:"aioseo_redirects_manage";b:1;s:28:"aioseo_page_redirects_manage";b:1;s:25:"aioseo_redirects_settings";b:1;s:33:"aioseo_search_statistics_settings";b:1;s:20:"aioseo_page_analysis";b:1;s:28:"aioseo_page_general_settings";b:1;s:29:"aioseo_page_advanced_settings";b:1;s:27:"aioseo_page_schema_settings";b:1;s:27:"aioseo_page_social_settings";b:1;s:35:"aioseo_page_link_assistant_settings";b:1;s:25:"aioseo_local_seo_settings";b:1;s:30:"aioseo_page_local_seo_settings";b:1;s:20:"aioseo_about_us_page";b:1;s:19:"aioseo_setup_wizard";b:1;s:34:"aioseo_page_seo_revisions_settings";b:1;}}s:13:"aioseo_editor";a:2:{s:4:"name";s:10:"SEO Editor";s:12:"capabilities";a:21:{s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:10:"edit_pages";b:1;s:10:"edit_posts";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:20:"edit_published_pages";b:1;s:20:"edit_published_posts";b:1;s:17:"manage_categories";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:4:"read";b:1;s:28:"aioseo_page_redirects_manage";b:1;s:20:"aioseo_page_analysis";b:1;s:28:"aioseo_page_general_settings";b:1;s:29:"aioseo_page_advanced_settings";b:1;s:27:"aioseo_page_schema_settings";b:1;s:27:"aioseo_page_social_settings";b:1;s:35:"aioseo_page_link_assistant_settings";b:1;s:30:"aioseo_page_local_seo_settings";b:1;s:34:"aioseo_page_seo_revisions_settings";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:1:{s:4:"read";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop manager";s:12:"capabilities";a:92:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"edit_theme_options";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}}', 'yes'),
(102, 'fresh_site', '0', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:29:{i:1711400639;a:2:{s:27:"litespeed_task_imgoptm_pull";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:16:"litespeed_filter";s:4:"args";a:0:{}s:8:"interval";i:60;}}s:19:"litespeed_task_lqip";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:16:"litespeed_filter";s:4:"args";a:0:{}s:8:"interval";i:60;}}}i:1711400648;a:1:{s:26:"action_scheduler_run_queue";a:1:{s:32:"0d04ed39571b55704c122d726248bbac";a:3:{s:8:"schedule";s:12:"every_minute";s:4:"args";a:1:{i:0;s:7:"WP Cron";}s:8:"interval";i:60;}}}i:1711400771;a:2:{s:24:"aiowps_hourly_cron_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}s:26:"aios_15_minutes_cron_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:21:"aios-every-15-minutes";s:4:"args";a:0:{}s:8:"interval";i:900;}}}i:1711400814;a:1:{s:20:"jetpack_clean_nonces";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1711400855;a:1:{s:29:"wc_admin_unsnooze_admin_notes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1711402060;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1711403056;a:1:{s:26:"fs_data_sync_code-snippets";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1711403495;a:2:{s:24:"woocommerce_cleanup_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:31:"woocommerce_cleanup_rate_limits";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1711403496;a:1:{s:33:"wc_admin_process_orders_milestone";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1711403529;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1711407349;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"7bf5f727a3c8db3fad704de83bbdef74";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:113;}}}}i:1711411200;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1711414295;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1711430860;a:5:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1711430889;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1711430890;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1711431134;a:1:{s:21:"update_network_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1711435896;a:1:{s:40:"woocommerce_marketplace_fetch_promotions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1711453812;a:1:{s:66:"puc_cron_check_updates-all-in-one-wp-security-and-firewall-premium";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1711476370;a:1:{s:23:"aiowps_clean_old_events";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1711476371;a:1:{s:23:"aiowps_daily_cron_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1711476378;a:1:{s:14:"wc_admin_daily";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1711476414;a:1:{s:20:"jetpack_v2_heartbeat";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1711476428;a:2:{s:21:"ai1wm_storage_cleanup";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:33:"aiowps_premium_daily_geoip_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1711479105;a:2:{s:33:"woocommerce_cleanup_personal_data";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:30:"woocommerce_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1711949613;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1711994771;a:1:{s:24:"aiowps_weekly_cron_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1712688755;a:1:{s:25:"woocommerce_geoip_updater";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:11:"fifteendays";s:4:"args";a:0:{}s:8:"interval";i:1296000;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(123, 'recovery_keys', 'a:0:{}', 'yes'),
(138, 'can_compress_scripts', '1', 'yes'),
(151, 'finished_updating_comment_type', '1', 'yes'),
(156, 'WPLANG', '', 'yes'),
(157, 'new_admin_email', 'anna@theatrummundi.co', 'yes'),
(159, 'recently_activated', 'a:0:{}', 'yes'),
(172, 'acf_first_activated_version', '6.2.6.1', 'yes'),
(173, 'action_scheduler_hybrid_store_demarkation', '30', 'yes'),
(174, 'schema-ActionScheduler_StoreSchema', '7.0.1711389968', 'yes'),
(175, 'schema-ActionScheduler_LoggerSchema', '3.0.1711389968', 'yes'),
(176, 'aio_wp_security_configs', 'a:100:{s:19:"aiowps_enable_debug";s:0:"";s:36:"aiowps_enable_php_backtrace_in_email";s:0:"";s:36:"aiowps_remove_wp_generator_meta_info";s:0:"";s:25:"aiowps_prevent_hotlinking";s:0:"";s:28:"aiowps_enable_login_lockdown";s:0:"";s:28:"aiowps_allow_unlock_requests";s:1:"1";s:25:"aiowps_max_login_attempts";s:1:"3";s:24:"aiowps_retry_time_period";s:1:"5";s:26:"aiowps_lockout_time_length";s:1:"5";s:30:"aiowps_max_lockout_time_length";s:2:"60";s:28:"aiowps_set_generic_login_msg";s:0:"";s:26:"aiowps_enable_email_notify";s:0:"";s:20:"aiowps_email_address";s:21:"anna@theatrummundi.co";s:27:"aiowps_enable_forced_logout";s:0:"";s:25:"aiowps_logout_time_period";s:2:"60";s:39:"aiowps_enable_invalid_username_lockdown";s:0:"";s:43:"aiowps_instantly_lockout_specific_usernames";a:0:{}s:32:"aiowps_unlock_request_secret_key";s:20:"y18ar9tqilgfc635xw7s";s:35:"aiowps_lockdown_enable_whitelisting";s:0:"";s:36:"aiowps_lockdown_allowed_ip_addresses";s:0:"";s:26:"aiowps_enable_whitelisting";s:0:"";s:27:"aiowps_allowed_ip_addresses";s:0:"";s:22:"aiowps_default_captcha";s:0:"";s:27:"aiowps_enable_login_captcha";s:0:"";s:34:"aiowps_enable_custom_login_captcha";s:0:"";s:31:"aiowps_enable_woo_login_captcha";s:0:"";s:34:"aiowps_enable_woo_register_captcha";s:0:"";s:38:"aiowps_enable_woo_lostpassword_captcha";s:0:"";s:36:"aiowps_enable_contact_form_7_captcha";s:0:"";s:25:"aiowps_captcha_secret_key";s:20:"lig63wftu07d6u7sr0kj";s:42:"aiowps_enable_manual_registration_approval";s:0:"";s:39:"aiowps_enable_registration_page_captcha";s:0:"";s:35:"aiowps_enable_registration_honeypot";s:0:"";s:27:"aiowps_enable_random_prefix";s:0:"";s:27:"aiowps_disable_file_editing";s:0:"";s:37:"aiowps_prevent_default_wp_file_access";s:0:"";s:35:"aiowps_auto_delete_default_wp_files";s:0:"";s:22:"aiowps_system_log_file";s:9:"error_log";s:26:"aiowps_enable_blacklisting";s:0:"";s:26:"aiowps_banned_ip_addresses";s:0:"";s:28:"aiowps_enable_basic_firewall";s:0:"";s:27:"aiowps_max_file_upload_size";i:100;s:38:"aiowps_disable_xmlrpc_pingback_methods";s:0:"";s:33:"aiowps_disable_rss_and_atom_feeds";s:0:"";s:34:"aiowps_block_debug_log_file_access";s:0:"";s:26:"aiowps_disable_index_views";s:0:"";s:30:"aiowps_disable_trace_and_track";s:0:"";s:25:"aiowps_enable_5g_firewall";s:0:"";s:25:"aiowps_enable_6g_firewall";s:0:"";s:26:"aiowps_enable_custom_rules";s:0:"";s:32:"aiowps_place_custom_rules_at_top";s:0:"";s:19:"aiowps_custom_rules";s:0:"";s:25:"aiowps_enable_404_logging";s:0:"";s:28:"aiowps_enable_404_IP_lockout";s:0:"";s:30:"aiowps_404_lockout_time_length";s:2:"60";s:28:"aiowps_404_lock_redirect_url";s:16:"http://127.0.0.1";s:31:"aiowps_enable_rename_login_page";s:0:"";s:28:"aiowps_enable_login_honeypot";s:0:"";s:35:"aiowps_disable_application_password";s:0:"";s:43:"aiowps_enable_brute_force_attack_prevention";s:0:"";s:30:"aiowps_brute_force_secret_word";s:0:"";s:24:"aiowps_cookie_brute_test";s:0:"";s:44:"aiowps_cookie_based_brute_force_redirect_url";s:16:"http://127.0.0.1";s:59:"aiowps_brute_force_attack_prevention_pw_protected_exception";s:0:"";s:51:"aiowps_brute_force_attack_prevention_ajax_exception";s:0:"";s:19:"aiowps_site_lockout";s:0:"";s:23:"aiowps_site_lockout_msg";s:0:"";s:30:"aiowps_enable_spambot_blocking";s:0:"";s:29:"aiowps_enable_comment_captcha";s:0:"";s:33:"aiowps_spam_ip_min_comments_block";s:0:"";s:33:"aiowps_enable_bp_register_captcha";s:0:"";s:35:"aiowps_enable_bbp_new_topic_captcha";s:0:"";s:31:"aiowps_enable_spambot_detecting";s:0:"";s:27:"aiowps_spam_comments_should";s:0:"";s:33:"aiowps_enable_trash_spam_comments";s:0:"";s:37:"aiowps_trash_spam_comments_after_days";s:2:"14";s:32:"aiowps_enable_automated_fcd_scan";s:0:"";s:25:"aiowps_fcd_scan_frequency";s:1:"4";s:24:"aiowps_fcd_scan_interval";s:1:"2";s:28:"aiowps_fcd_exclude_filetypes";s:0:"";s:24:"aiowps_fcd_exclude_files";s:0:"";s:26:"aiowps_send_fcd_scan_email";s:0:"";s:29:"aiowps_fcd_scan_email_address";s:21:"anna@theatrummundi.co";s:27:"aiowps_fcds_change_detected";b:0;s:22:"aiowps_copy_protection";s:0:"";s:40:"aiowps_prevent_site_display_inside_frame";s:0:"";s:32:"aiowps_prevent_users_enumeration";s:0:"";s:42:"aiowps_disallow_unauthorized_rest_requests";s:0:"";s:25:"aiowps_turnstile_site_key";s:0:"";s:27:"aiowps_turnstile_secret_key";s:0:"";s:25:"aiowps_recaptcha_site_key";s:0:"";s:27:"aiowps_recaptcha_secret_key";s:0:"";s:24:"aiowps_default_recaptcha";s:0:"";s:36:"aiowps_on_uninstall_delete_db_tables";s:1:"1";s:34:"aiowps_on_uninstall_delete_configs";s:1:"1";s:12:"installed-at";i:1711389971;s:31:"aiowps_enable_pingback_firewall";s:1:"0";s:28:"aiowps_forbid_proxy_comments";s:1:"0";s:29:"aiowps_deny_bad_query_strings";s:1:"0";s:34:"aiowps_advanced_char_string_filter";s:1:"0";}', 'yes'),
(177, 'aiowpsec_db_version', '2.0.10', 'yes'),
(178, 'ai1wm_secret_key', 'CYuQrIqefVSZ', 'yes'),
(179, 'fs_active_plugins', 'O:8:"stdClass":3:{s:7:"plugins";a:1:{s:47:"code-snippets-pro/vendor/freemius/wordpress-sdk";O:8:"stdClass":4:{s:7:"version";s:6:"2.5.12";s:4:"type";s:6:"plugin";s:9:"timestamp";i:1711389972;s:11:"plugin_path";s:35:"code-snippets-pro/code-snippets.php";}}s:7:"abspath";s:38:"C:\\Library\\Theatrum Universum\\wp-root/";s:6:"newest";O:8:"stdClass":5:{s:11:"plugin_path";s:35:"code-snippets-pro/code-snippets.php";s:8:"sdk_path";s:47:"code-snippets-pro/vendor/freemius/wordpress-sdk";s:7:"version";s:6:"2.5.12";s:13:"in_activation";b:0;s:9:"timestamp";i:1711389972;}}', 'yes'),
(180, 'fs_debug_mode', '', 'yes'),
(183, 'litespeed.conf.__activation', '-1', 'yes'),
(184, 'litespeed.purge.queue', '-1', 'yes'),
(185, 'litespeed.purge.queue2', '-1', 'yes'),
(188, 'woocommerce_newly_installed', 'no', 'yes'),
(189, 'woocommerce_schema_version', '430', 'yes'),
(190, 'woocommerce_store_address', '', 'yes'),
(191, 'woocommerce_store_address_2', '', 'yes'),
(192, 'woocommerce_store_city', '', 'yes'),
(193, 'woocommerce_default_country', 'US:CA', 'yes'),
(194, 'woocommerce_store_postcode', '', 'yes'),
(195, 'woocommerce_allowed_countries', 'all', 'yes'),
(196, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(197, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(198, 'woocommerce_ship_to_countries', '', 'yes'),
(199, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(200, 'woocommerce_default_customer_address', 'base', 'yes'),
(201, 'woocommerce_calc_taxes', 'no', 'yes'),
(202, 'woocommerce_enable_coupons', 'yes', 'yes'),
(203, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(204, 'woocommerce_currency', 'USD', 'yes'),
(205, 'woocommerce_currency_pos', 'left', 'yes'),
(206, 'woocommerce_price_thousand_sep', ',', 'yes'),
(207, 'woocommerce_price_decimal_sep', '.', 'yes'),
(208, 'woocommerce_price_num_decimals', '2', 'yes'),
(209, 'woocommerce_shop_page_id', '31', 'yes'),
(210, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(211, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(212, 'woocommerce_placeholder_image', '30', 'yes'),
(213, 'woocommerce_weight_unit', 'kg', 'yes'),
(214, 'woocommerce_dimension_unit', 'cm', 'yes'),
(215, 'woocommerce_enable_reviews', 'yes', 'yes'),
(216, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(217, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(218, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(219, 'woocommerce_review_rating_required', 'yes', 'no'),
(220, 'woocommerce_manage_stock', 'yes', 'yes'),
(221, 'woocommerce_hold_stock_minutes', '60', 'no'),
(222, 'woocommerce_notify_low_stock', 'yes', 'no'),
(223, 'woocommerce_notify_no_stock', 'yes', 'no'),
(224, 'woocommerce_stock_email_recipient', 'anna@theatrummundi.co', 'no'),
(225, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(226, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(227, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(228, 'woocommerce_stock_format', '', 'yes'),
(229, 'woocommerce_file_download_method', 'force', 'no'),
(230, 'woocommerce_downloads_redirect_fallback_allowed', 'no', 'no'),
(231, 'woocommerce_downloads_require_login', 'no', 'no'),
(232, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(233, 'woocommerce_downloads_deliver_inline', '', 'no'),
(234, 'woocommerce_downloads_add_hash_to_filename', 'yes', 'yes'),
(235, 'woocommerce_attribute_lookup_enabled', 'no', 'yes'),
(236, 'woocommerce_attribute_lookup_direct_updates', 'no', 'yes'),
(237, 'woocommerce_product_match_featured_image_by_sku', 'no', 'yes'),
(238, 'woocommerce_prices_include_tax', 'no', 'yes'),
(239, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(240, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(241, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(242, 'woocommerce_tax_classes', '', 'yes'),
(243, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(244, 'woocommerce_tax_display_cart', 'excl', 'yes'),
(245, 'woocommerce_price_display_suffix', '', 'yes'),
(246, 'woocommerce_tax_total_display', 'itemized', 'no'),
(247, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(248, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(249, 'woocommerce_ship_to_destination', 'billing', 'no') ;
INSERT INTO `tu_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(250, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(251, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(252, 'woocommerce_enable_checkout_login_reminder', 'no', 'no'),
(253, 'woocommerce_enable_signup_and_login_from_checkout', 'no', 'no'),
(254, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(255, 'woocommerce_registration_generate_username', 'yes', 'no'),
(256, 'woocommerce_registration_generate_password', 'yes', 'no'),
(257, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(258, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(259, 'woocommerce_allow_bulk_remove_personal_data', 'no', 'no'),
(260, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'yes'),
(261, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'yes'),
(262, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(263, 'woocommerce_trash_pending_orders', '', 'no'),
(264, 'woocommerce_trash_failed_orders', '', 'no'),
(265, 'woocommerce_trash_cancelled_orders', '', 'no'),
(266, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(267, 'woocommerce_email_from_name', 'Theatrum Mundi', 'no'),
(268, 'woocommerce_email_from_address', 'anna@theatrummundi.co', 'no'),
(269, 'woocommerce_email_header_image', '', 'no'),
(270, 'woocommerce_email_footer_text', '{site_title} &mdash; Built with {WooCommerce}', 'no'),
(271, 'woocommerce_email_base_color', '#7f54b3', 'no'),
(272, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(273, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(274, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(275, 'woocommerce_merchant_email_notifications', 'no', 'no'),
(276, 'woocommerce_cart_page_id', '32', 'no'),
(277, 'woocommerce_checkout_page_id', '33', 'no'),
(278, 'woocommerce_myaccount_page_id', '34', 'no'),
(279, 'woocommerce_terms_page_id', '', 'no'),
(280, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(281, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(282, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(283, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(284, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(285, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(286, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(287, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(288, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(289, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(290, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(291, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(292, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(293, 'woocommerce_api_enabled', 'no', 'yes'),
(294, 'woocommerce_allow_tracking', 'yes', 'no'),
(295, 'woocommerce_show_marketplace_suggestions', 'yes', 'no'),
(296, 'woocommerce_custom_orders_table_enabled', 'yes', 'yes'),
(297, 'woocommerce_analytics_enabled', 'yes', 'yes'),
(298, 'woocommerce_navigation_enabled', 'no', 'yes'),
(299, 'woocommerce_feature_order_attribution_enabled', 'yes', 'yes'),
(300, 'woocommerce_feature_product_block_editor_enabled', 'yes', 'yes'),
(301, 'woocommerce_single_image_width', '600', 'yes'),
(302, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(303, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(304, 'woocommerce_demo_store', 'no', 'no'),
(305, 'wc_downloads_approved_directories_mode', 'enabled', 'yes'),
(306, 'woocommerce_permalinks', 'a:5:{s:12:"product_base";s:7:"product";s:13:"category_base";s:16:"product-category";s:8:"tag_base";s:11:"product-tag";s:14:"attribute_base";s:0:"";s:22:"use_verbose_page_rules";b:0;}', 'yes'),
(307, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(308, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(310, 'product_cat_children', 'a:0:{}', 'yes'),
(311, 'default_product_cat', '16', 'yes'),
(313, 'woocommerce_refund_returns_page_id', '35', 'yes'),
(316, 'woocommerce_paypal_settings', 'a:23:{s:7:"enabled";s:2:"no";s:5:"title";s:6:"PayPal";s:11:"description";s:85:"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.";s:5:"email";s:21:"anna@theatrummundi.co";s:8:"advanced";s:0:"";s:8:"testmode";s:2:"no";s:5:"debug";s:2:"no";s:16:"ipn_notification";s:3:"yes";s:14:"receiver_email";s:21:"anna@theatrummundi.co";s:14:"identity_token";s:0:"";s:14:"invoice_prefix";s:3:"WC-";s:13:"send_shipping";s:3:"yes";s:16:"address_override";s:2:"no";s:13:"paymentaction";s:4:"sale";s:9:"image_url";s:0:"";s:11:"api_details";s:0:"";s:12:"api_username";s:0:"";s:12:"api_password";s:0:"";s:13:"api_signature";s:0:"";s:20:"sandbox_api_username";s:0:"";s:20:"sandbox_api_password";s:0:"";s:21:"sandbox_api_signature";s:0:"";s:12:"_should_load";s:2:"no";}', 'yes'),
(317, 'woocommerce_version', '8.7.0', 'yes'),
(318, 'woocommerce_db_version', '8.6.1', 'yes'),
(319, 'woocommerce_store_id', 'f4d157ff-5e5b-4ec2-860c-a76d86f45752', 'yes'),
(320, 'woocommerce_admin_install_timestamp', '1711389979', 'yes'),
(321, 'woocommerce_inbox_variant_assignment', '10', 'yes'),
(325, 'wpdm_social_share_init', '1', 'yes'),
(326, 'wpdm_social_share_enable', '0', 'yes'),
(327, 'wpdm_social_share_channels', 'a:3:{i:0;a:3:{s:2:"id";s:8:"facebook";s:4:"name";s:8:"Facebook";s:10:"visibility";a:2:{s:7:"desktop";i:1;s:6:"mobile";i:1;}}i:1;a:3:{s:2:"id";s:7:"twitter";s:4:"name";s:7:"Twitter";s:10:"visibility";a:2:{s:7:"desktop";i:1;s:6:"mobile";i:1;}}i:2;a:3:{s:2:"id";s:4:"copy";s:4:"name";s:4:"Copy";s:10:"visibility";a:2:{s:7:"desktop";i:1;s:6:"mobile";i:1;}}}', 'yes'),
(328, 'wpdm_social_share_channel_visibility', '3', 'yes'),
(329, 'wpdm_social_share_button_template', '1', 'yes'),
(330, 'wpdm_social_share_share_via_label', 'Sharing is Caring:', 'yes'),
(331, 'wpdm_social_share_shares_label', 'Shares', 'yes'),
(332, 'wpdm_social_share_more_label', 'More', 'yes'),
(333, 'wpdm_social_share_button_position', 'below', 'yes'),
(334, 'wpdm_social_share_button_alignment', 'left', 'yes'),
(335, 'wpdm_social_share_button_shape', 'rounded', 'yes'),
(336, 'wpdm_social_share_button_size', '1.2', 'yes'),
(337, 'wpdm_social_share_button_label', 'both', 'yes'),
(338, 'wpdm_social_share_hide_button_on', 'a:2:{s:6:"mobile";i:0;s:7:"desktop";i:0;}', 'yes'),
(339, 'wpdm_social_share_post_types', 'a:2:{i:0;s:4:"post";i:1;s:4:"page";}', 'yes'),
(340, 'wpdm_social_share_button_spacing', '1', 'yes'),
(341, 'wpdm_social_share_show_total_share_count', '0', 'yes'),
(342, 'wpdm_social_share_minimum_share_count', '0', 'yes'),
(343, 'wpdm_social_share_maximum_click_count', '30', 'yes'),
(344, 'wpdm_social_share_saved', '0', 'yes'),
(345, 'wp_dark_mode_version', '5.0.3', 'yes'),
(352, 'wp_dark_mode_ultimate_version', '3.0.4', 'yes'),
(353, 'wp_dark_mode_ultimate_install_time', '1711389979', 'yes'),
(356, 'action_scheduler_lock_async-request-runner', '6601e692cb5f60.44984575|1711400654', 'yes'),
(357, 'aioseo_options_internal', '{"internal":{"validLicenseKey":null,"lastActiveVersion":"4.5.3","migratedVersion":"0.0","siteAnalysis":{"connectToken":null,"score":0,"results":null,"competitors":[]},"headlineAnalysis":{"headlines":[]},"wizard":null,"category":null,"categoryOther":null,"deprecatedOptions":[],"searchStatistics":{"profile":[],"trustToken":null,"rolling":"last28Days"}},"integrations":{"semrush":{"accessToken":null,"tokenType":null,"expires":null,"refreshToken":null}},"database":{"installedTables":"{\\"tu_aioseo_posts\\":[\\"id\\",\\"post_id\\",\\"title\\",\\"description\\",\\"keywords\\",\\"keyphrases\\",\\"page_analysis\\",\\"primary_term\\",\\"canonical_url\\",\\"og_title\\",\\"og_description\\",\\"og_object_type\\",\\"og_image_type\\",\\"og_image_url\\",\\"og_image_width\\",\\"og_image_height\\",\\"og_image_custom_url\\",\\"og_image_custom_fields\\",\\"og_video\\",\\"og_custom_url\\",\\"og_article_section\\",\\"og_article_tags\\",\\"twitter_use_og\\",\\"twitter_card\\",\\"twitter_image_type\\",\\"twitter_image_url\\",\\"twitter_image_custom_url\\",\\"twitter_image_custom_fields\\",\\"twitter_title\\",\\"twitter_description\\",\\"seo_score\\",\\"schema\\",\\"schema_type\\",\\"schema_type_options\\",\\"pillar_content\\",\\"robots_default\\",\\"robots_noindex\\",\\"robots_noarchive\\",\\"robots_nosnippet\\",\\"robots_nofollow\\",\\"robots_noimageindex\\",\\"robots_noodp\\",\\"robots_notranslate\\",\\"robots_max_snippet\\",\\"robots_max_videopreview\\",\\"robots_max_imagepreview\\",\\"images\\",\\"image_scan_date\\",\\"priority\\",\\"frequency\\",\\"videos\\",\\"video_thumbnail\\",\\"video_scan_date\\",\\"local_seo\\",\\"limit_modified_date\\",\\"options\\",\\"open_ai\\",\\"created\\",\\"updated\\"],\\"tu_actionscheduler_actions\\":[],\\"tu_actionscheduler_logs\\":[],\\"tu_actionscheduler_groups\\":[],\\"tu_actionscheduler_claims\\":[],\\"tu_aioseo_notifications\\":[]}"}}', 'yes'),
(358, 'aioseo_options_internal_pro', '{"internal":{"lastActiveProVersion":"4.5.3","activated":1711389970,"firstActivated":1711389970,"installed":0,"license":{"expires":0,"expired":false,"invalid":false,"disabled":false,"connectionError":false,"activationsError":false,"requestError":false,"lastChecked":0,"level":null,"addons":"","features":""},"schema":{"templates":[]}}}', 'yes'),
(360, 'woocommerce_admin_notices', 'a:1:{i:0;s:6:"update";}', 'yes'),
(361, 'litespeed.cloud._summary', '{"curr_request.ver":0,"last_request.ver":1711390013,"news.utime":1711390077,"curr_request.news":0,"last_request.news":1711390077}', 'yes'),
(362, 'litespeed.conf._version', '6.1', 'yes'),
(363, 'litespeed.conf.hash', 'EjzLYcxp5saztvy0J57W31K0jhYMcoT4', 'yes'),
(364, 'litespeed.conf.auto_upgrade', '', 'yes'),
(365, 'litespeed.conf.api_key', '', 'yes') ;
INSERT INTO `tu_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(366, 'litespeed.conf.server_ip', '', 'yes'),
(367, 'litespeed.conf.guest', '', 'yes'),
(368, 'litespeed.conf.guest_optm', '', 'yes'),
(369, 'litespeed.conf.news', '1', 'yes'),
(370, 'litespeed.conf.guest_uas', '["Lighthouse","GTmetrix","Google","Pingdom","bot","spider","PTST","HeadlessChrome"]', 'yes'),
(371, 'litespeed.conf.guest_ips', '["208.70.247.157","172.255.48.130","172.255.48.131","172.255.48.132","172.255.48.133","172.255.48.134","172.255.48.135","172.255.48.136","172.255.48.137","172.255.48.138","172.255.48.139","172.255.48.140","172.255.48.141","172.255.48.142","172.255.48.143","172.255.48.144","172.255.48.145","172.255.48.146","172.255.48.147","52.229.122.240","104.214.72.101","13.66.7.11","13.85.24.83","13.85.24.90","13.85.82.26","40.74.242.253","40.74.243.13","40.74.243.176","104.214.48.247","157.55.189.189","104.214.110.135","70.37.83.240","65.52.36.250","13.78.216.56","52.162.212.163","23.96.34.105","65.52.113.236","172.255.61.34","172.255.61.35","172.255.61.36","172.255.61.37","172.255.61.38","172.255.61.39","172.255.61.40","104.41.2.19","191.235.98.164","191.235.99.221","191.232.194.51","52.237.235.185","52.237.250.73","52.237.236.145","104.211.143.8","104.211.165.53","52.172.14.87","40.83.89.214","52.175.57.81","20.188.63.151","20.52.36.49","52.246.165.153","51.144.102.233","13.76.97.224","102.133.169.66","52.231.199.170","13.53.162.7","40.123.218.94"]', 'yes'),
(372, 'litespeed.conf.cache', '2', 'yes'),
(373, 'litespeed.conf.cache-priv', '1', 'yes'),
(374, 'litespeed.conf.cache-commenter', '1', 'yes'),
(375, 'litespeed.conf.cache-rest', '1', 'yes'),
(376, 'litespeed.conf.cache-page_login', '1', 'yes'),
(377, 'litespeed.conf.cache-favicon', '1', 'yes'),
(378, 'litespeed.conf.cache-resources', '1', 'yes'),
(379, 'litespeed.conf.cache-mobile', '', 'yes'),
(380, 'litespeed.conf.cache-mobile_rules', '["Mobile","Android","Silk\\/","Kindle","BlackBerry","Opera Mini","Opera Mobi"]', 'yes'),
(381, 'litespeed.conf.cache-browser', '', 'yes'),
(382, 'litespeed.conf.cache-exc_useragents', '[]', 'yes'),
(383, 'litespeed.conf.cache-exc_cookies', '[]', 'yes'),
(384, 'litespeed.conf.cache-exc_qs', '[]', 'yes'),
(385, 'litespeed.conf.cache-exc_cat', '[]', 'yes'),
(386, 'litespeed.conf.cache-exc_tag', '[]', 'yes'),
(387, 'litespeed.conf.cache-force_uri', '[]', 'yes'),
(388, 'litespeed.conf.cache-force_pub_uri', '[]', 'yes'),
(389, 'litespeed.conf.cache-priv_uri', '[]', 'yes'),
(390, 'litespeed.conf.cache-exc', '[]', 'yes'),
(391, 'litespeed.conf.cache-exc_roles', '[]', 'yes'),
(392, 'litespeed.conf.cache-drop_qs', '["fbclid","gclid","utm*","_ga"]', 'yes'),
(393, 'litespeed.conf.cache-ttl_pub', '604800', 'yes'),
(394, 'litespeed.conf.cache-ttl_priv', '1800', 'yes'),
(395, 'litespeed.conf.cache-ttl_frontpage', '604800', 'yes'),
(396, 'litespeed.conf.cache-ttl_feed', '604800', 'yes'),
(397, 'litespeed.conf.cache-ttl_rest', '604800', 'yes'),
(398, 'litespeed.conf.cache-ttl_browser', '31557600', 'yes'),
(399, 'litespeed.conf.cache-ttl_status', '["404 3600","500 600"]', 'yes'),
(400, 'litespeed.conf.cache-login_cookie', '', 'yes'),
(401, 'litespeed.conf.cache-vary_cookies', '[]', 'yes'),
(402, 'litespeed.conf.cache-vary_group', '[]', 'yes'),
(403, 'litespeed.conf.purge-upgrade', '1', 'yes'),
(404, 'litespeed.conf.purge-stale', '', 'yes'),
(405, 'litespeed.conf.purge-post_all', '', 'yes'),
(406, 'litespeed.conf.purge-post_f', '1', 'yes'),
(407, 'litespeed.conf.purge-post_h', '1', 'yes'),
(408, 'litespeed.conf.purge-post_p', '1', 'yes'),
(409, 'litespeed.conf.purge-post_pwrp', '1', 'yes'),
(410, 'litespeed.conf.purge-post_a', '1', 'yes'),
(411, 'litespeed.conf.purge-post_y', '', 'yes'),
(412, 'litespeed.conf.purge-post_m', '1', 'yes'),
(413, 'litespeed.conf.purge-post_d', '', 'yes'),
(414, 'litespeed.conf.purge-post_t', '1', 'yes'),
(415, 'litespeed.conf.purge-post_pt', '1', 'yes'),
(416, 'litespeed.conf.purge-timed_urls', '[]', 'yes'),
(417, 'litespeed.conf.purge-timed_urls_time', '', 'yes'),
(418, 'litespeed.conf.purge-hook_all', '["switch_theme","wp_create_nav_menu","wp_update_nav_menu","wp_delete_nav_menu","create_term","edit_terms","delete_term","add_link","edit_link","delete_link"]', 'yes'),
(419, 'litespeed.conf.esi', '', 'yes'),
(420, 'litespeed.conf.esi-cache_admbar', '1', 'yes'),
(421, 'litespeed.conf.esi-cache_commform', '1', 'yes'),
(422, 'litespeed.conf.esi-nonce', '["stats_nonce","subscribe_nonce"]', 'yes'),
(423, 'litespeed.conf.util-instant_click', '', 'yes'),
(424, 'litespeed.conf.util-no_https_vary', '', 'yes'),
(425, 'litespeed.conf.debug-disable_all', '', 'yes'),
(426, 'litespeed.conf.debug', '', 'yes'),
(427, 'litespeed.conf.debug-ips', '["127.0.0.1"]', 'yes'),
(428, 'litespeed.conf.debug-level', '', 'yes'),
(429, 'litespeed.conf.debug-filesize', '3', 'yes'),
(430, 'litespeed.conf.debug-cookie', '', 'yes'),
(431, 'litespeed.conf.debug-collaps_qs', '', 'yes'),
(432, 'litespeed.conf.debug-inc', '[]', 'yes'),
(433, 'litespeed.conf.debug-exc', '[]', 'yes'),
(434, 'litespeed.conf.debug-exc_strings', '[]', 'yes'),
(435, 'litespeed.conf.db_optm-revisions_max', '0', 'yes'),
(436, 'litespeed.conf.db_optm-revisions_age', '0', 'yes'),
(437, 'litespeed.conf.optm-css_min', '', 'yes'),
(438, 'litespeed.conf.optm-css_comb', '', 'yes'),
(439, 'litespeed.conf.optm-css_comb_ext_inl', '1', 'yes'),
(440, 'litespeed.conf.optm-ucss', '', 'yes'),
(441, 'litespeed.conf.optm-ucss_inline', '', 'yes'),
(442, 'litespeed.conf.optm-ucss_whitelist', '[]', 'yes'),
(443, 'litespeed.conf.optm-ucss_file_exc_inline', '[]', 'yes'),
(444, 'litespeed.conf.optm-ucss_exc', '[]', 'yes'),
(445, 'litespeed.conf.optm-css_exc', '[]', 'yes'),
(446, 'litespeed.conf.optm-js_min', '', 'yes'),
(447, 'litespeed.conf.optm-js_comb', '', 'yes'),
(448, 'litespeed.conf.optm-js_comb_ext_inl', '1', 'yes'),
(449, 'litespeed.conf.optm-js_delay_inc', '[]', 'yes'),
(450, 'litespeed.conf.optm-js_exc', '["jquery.js","jquery.min.js"]', 'yes'),
(451, 'litespeed.conf.optm-html_min', '', 'yes'),
(452, 'litespeed.conf.optm-html_lazy', '[]', 'yes'),
(453, 'litespeed.conf.optm-qs_rm', '', 'yes'),
(454, 'litespeed.conf.optm-ggfonts_rm', '', 'yes'),
(455, 'litespeed.conf.optm-css_async', '', 'yes'),
(456, 'litespeed.conf.optm-ccss_per_url', '', 'yes'),
(457, 'litespeed.conf.optm-ccss_sep_posttype', '["page"]', 'yes'),
(458, 'litespeed.conf.optm-ccss_sep_uri', '[]', 'yes'),
(459, 'litespeed.conf.optm-css_async_inline', '1', 'yes'),
(460, 'litespeed.conf.optm-css_font_display', '', 'yes'),
(461, 'litespeed.conf.optm-js_defer', '', 'yes'),
(462, 'litespeed.conf.optm-emoji_rm', '', 'yes'),
(463, 'litespeed.conf.optm-noscript_rm', '', 'yes'),
(464, 'litespeed.conf.optm-ggfonts_async', '', 'yes'),
(465, 'litespeed.conf.optm-exc_roles', '[]', 'yes') ;
INSERT INTO `tu_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(466, 'litespeed.conf.optm-ccss_con', '', 'yes'),
(467, 'litespeed.conf.optm-js_defer_exc', '["jquery.js","jquery.min.js","gtm.js","analytics.js"]', 'yes'),
(468, 'litespeed.conf.optm-gm_js_exc', '[]', 'yes'),
(469, 'litespeed.conf.optm-dns_prefetch', '[]', 'yes'),
(470, 'litespeed.conf.optm-dns_prefetch_ctrl', '', 'yes'),
(471, 'litespeed.conf.optm-dns_preconnect', '[]', 'yes'),
(472, 'litespeed.conf.optm-exc', '[]', 'yes'),
(473, 'litespeed.conf.optm-guest_only', '1', 'yes'),
(474, 'litespeed.conf.object', '', 'yes'),
(475, 'litespeed.conf.object-kind', '', 'yes'),
(476, 'litespeed.conf.object-host', 'localhost', 'yes'),
(477, 'litespeed.conf.object-port', '11211', 'yes'),
(478, 'litespeed.conf.object-life', '360', 'yes'),
(479, 'litespeed.conf.object-persistent', '1', 'yes'),
(480, 'litespeed.conf.object-admin', '1', 'yes'),
(481, 'litespeed.conf.object-transients', '1', 'yes'),
(482, 'litespeed.conf.object-db_id', '0', 'yes'),
(483, 'litespeed.conf.object-user', '', 'yes'),
(484, 'litespeed.conf.object-pswd', '', 'yes'),
(485, 'litespeed.conf.object-global_groups', '["users","userlogins","useremail","userslugs","usermeta","user_meta","site-transient","site-options","site-lookup","site-details","blog-lookup","blog-details","blog-id-cache","rss","global-posts","global-cache-test"]', 'yes'),
(486, 'litespeed.conf.object-non_persistent_groups', '["comment","counts","plugins","wc_session_id"]', 'yes'),
(487, 'litespeed.conf.discuss-avatar_cache', '', 'yes'),
(488, 'litespeed.conf.discuss-avatar_cron', '', 'yes'),
(489, 'litespeed.conf.discuss-avatar_cache_ttl', '604800', 'yes'),
(490, 'litespeed.conf.optm-localize', '', 'yes'),
(491, 'litespeed.conf.optm-localize_domains', '["### Popular scripts ###","https:\\/\\/platform.twitter.com\\/widgets.js","https:\\/\\/connect.facebook.net\\/en_US\\/fbevents.js"]', 'yes'),
(492, 'litespeed.conf.media-preload_featured', '', 'yes'),
(493, 'litespeed.conf.media-lazy', '', 'yes'),
(494, 'litespeed.conf.media-lazy_placeholder', '', 'yes'),
(495, 'litespeed.conf.media-placeholder_resp', '', 'yes'),
(496, 'litespeed.conf.media-placeholder_resp_color', '#cfd4db', 'yes'),
(497, 'litespeed.conf.media-placeholder_resp_svg', '<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}"><rect width="100%" height="100%" style="fill:{color};fill-opacity: 0.1;"/></svg>', 'yes'),
(498, 'litespeed.conf.media-lqip', '', 'yes'),
(499, 'litespeed.conf.media-lqip_qual', '4', 'yes'),
(500, 'litespeed.conf.media-lqip_min_w', '150', 'yes'),
(501, 'litespeed.conf.media-lqip_min_h', '150', 'yes'),
(502, 'litespeed.conf.media-placeholder_resp_async', '1', 'yes'),
(503, 'litespeed.conf.media-iframe_lazy', '', 'yes'),
(504, 'litespeed.conf.media-add_missing_sizes', '', 'yes'),
(505, 'litespeed.conf.media-lazy_exc', '[]', 'yes'),
(506, 'litespeed.conf.media-lazy_cls_exc', '["wmu-preview-img"]', 'yes'),
(507, 'litespeed.conf.media-lazy_parent_cls_exc', '[]', 'yes'),
(508, 'litespeed.conf.media-iframe_lazy_cls_exc', '[]', 'yes'),
(509, 'litespeed.conf.media-iframe_lazy_parent_cls_exc', '[]', 'yes'),
(510, 'litespeed.conf.media-lazy_uri_exc', '[]', 'yes'),
(511, 'litespeed.conf.media-lqip_exc', '[]', 'yes'),
(512, 'litespeed.conf.media-vpi', '', 'yes'),
(513, 'litespeed.conf.media-vpi_cron', '', 'yes'),
(514, 'litespeed.conf.img_optm-auto', '', 'yes'),
(515, 'litespeed.conf.img_optm-cron', '1', 'yes'),
(516, 'litespeed.conf.img_optm-ori', '1', 'yes'),
(517, 'litespeed.conf.img_optm-rm_bkup', '', 'yes'),
(518, 'litespeed.conf.img_optm-webp', '', 'yes'),
(519, 'litespeed.conf.img_optm-lossless', '', 'yes'),
(520, 'litespeed.conf.img_optm-exif', '1', 'yes'),
(521, 'litespeed.conf.img_optm-webp_attr', '["img.src","div.data-thumb","img.data-src","img.data-lazyload","div.data-large_image","img.retina_logo_url","div.data-parallax-image","div.data-vc-parallax-image","video.poster"]', 'yes'),
(522, 'litespeed.conf.img_optm-webp_replace_srcset', '', 'yes'),
(523, 'litespeed.conf.img_optm-jpg_quality', '82', 'yes'),
(524, 'litespeed.conf.crawler', '', 'yes'),
(525, 'litespeed.conf.crawler-usleep', '500', 'yes'),
(526, 'litespeed.conf.crawler-run_duration', '400', 'yes'),
(527, 'litespeed.conf.crawler-run_interval', '600', 'yes'),
(528, 'litespeed.conf.crawler-crawl_interval', '302400', 'yes'),
(529, 'litespeed.conf.crawler-threads', '3', 'yes'),
(530, 'litespeed.conf.crawler-timeout', '30', 'yes'),
(531, 'litespeed.conf.crawler-load_limit', '1', 'yes'),
(532, 'litespeed.conf.crawler-sitemap', '', 'yes'),
(533, 'litespeed.conf.crawler-drop_domain', '1', 'yes'),
(534, 'litespeed.conf.crawler-map_timeout', '120', 'yes'),
(535, 'litespeed.conf.crawler-roles', '[]', 'yes'),
(536, 'litespeed.conf.crawler-cookies', '[]', 'yes'),
(537, 'litespeed.conf.misc-heartbeat_front', '', 'yes'),
(538, 'litespeed.conf.misc-heartbeat_front_ttl', '60', 'yes'),
(539, 'litespeed.conf.misc-heartbeat_back', '', 'yes'),
(540, 'litespeed.conf.misc-heartbeat_back_ttl', '60', 'yes'),
(541, 'litespeed.conf.misc-heartbeat_editor', '', 'yes'),
(542, 'litespeed.conf.misc-heartbeat_editor_ttl', '15', 'yes'),
(543, 'litespeed.conf.cdn', '', 'yes'),
(544, 'litespeed.conf.cdn-ori', '[]', 'yes'),
(545, 'litespeed.conf.cdn-ori_dir', '["wp-content","wp-includes"]', 'yes'),
(546, 'litespeed.conf.cdn-exc', '[]', 'yes'),
(547, 'litespeed.conf.cdn-quic', '', 'yes'),
(548, 'litespeed.conf.cdn-cloudflare', '', 'yes'),
(549, 'litespeed.conf.cdn-cloudflare_email', '', 'yes'),
(550, 'litespeed.conf.cdn-cloudflare_key', '', 'yes'),
(551, 'litespeed.conf.cdn-cloudflare_name', '', 'yes'),
(552, 'litespeed.conf.cdn-cloudflare_zone', '', 'yes'),
(553, 'litespeed.conf.cdn-mapping', '[{"url":"","inc_img":"1","inc_css":"1","inc_js":"1","filetype":[".aac",".css",".eot",".gif",".jpeg",".jpg",".js",".less",".mp3",".mp4",".ogg",".otf",".pdf",".png",".svg",".ttf",".webp",".woff",".woff2"]}]', 'yes'),
(554, 'litespeed.conf.cdn-attr', '[".src",".data-src",".href",".poster","source.srcset"]', 'yes'),
(555, 'litespeed.conf.qc-token', '', 'yes'),
(556, 'litespeed.conf.qc-nameservers', '', 'yes'),
(557, 'code_snippets_version', '3.6.4', 'yes'),
(558, 'aDBc_settings', 'a:4:{s:9:"left_menu";s:1:"1";s:16:"menu_under_tools";s:1:"1";s:14:"plugin_version";s:5:"3.2.3";s:12:"installed_on";s:10:"2024/03/25";}', 'no'),
(559, 'aDBc_security_folder_code', '3k54nx2r4qb7', 'no'),
(560, 'aiowpsec_firewall_version', '1.0.6', 'yes'),
(561, 'code_snippets_cloud_settings', 'a:6:{s:11:"cloud_token";s:0:"";s:11:"local_token";s:30:"b7A49ZlTu7VVTQ7XLI6Y43mDUGr7jN";s:14:"token_verified";b:0;s:13:"code_verifier";s:128:"febvmAQDfh2Dy9Lne3EPQJW86IBMc4r0KdxVtroO3bxx7QDMQUC2ZY5j64HqsssvUZYQildBZuQjG2SvR4klM2KHXGuAdP4p46i4F3D70GHdCiKi18o8XKrjl0T8mTyQ";s:14:"code_challenge";s:43:"rrVoQ7FTZ6IFNDVwQUUFbIQEs1kvma10NoiMyFn-Sxk";s:5:"state";s:15:"HminE7ADQHTOpql";}', 'yes'),
(562, 'wpmc_options', 'a:27:{s:6:"method";s:5:"media";s:7:"content";b:1;s:18:"filesystem_content";b:0;s:13:"media_library";b:1;s:12:"live_content";b:0;s:9:"debuglogs";b:0;s:11:"images_only";b:0;s:13:"attach_is_use";b:0;s:15:"thumbnails_only";b:0;s:11:"dirs_filter";s:0:"";s:12:"files_filter";s:0:"";s:15:"hide_thumbnails";b:0;s:12:"hide_warning";b:0;s:10:"skip_trash";b:0;s:13:"medias_buffer";i:100;s:12:"posts_buffer";i:5;s:15:"analysis_buffer";i:100;s:14:"file_op_buffer";i:20;s:5:"delay";i:100;s:19:"shortcodes_disabled";b:0;s:31:"output_buffer_cleaning_disabled";b:0;s:14:"php_error_logs";b:0;s:14:"posts_per_page";i:10;s:15:"clean_uninstall";b:0;s:11:"repair_mode";b:0;s:11:"expert_mode";b:0;s:9:"logs_path";N;}', 'yes'),
(563, 'wpmc_rating_date', '1712734992', 'no'),
(564, 'wc_blocks_version', '11.8.0-dev', 'yes'),
(565, 'jetpack_connection_active_plugins', 'a:1:{s:11:"woocommerce";a:1:{s:4:"name";s:11:"WooCommerce";}}', 'yes') ;
INSERT INTO `tu_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(566, 'woocommerce_maxmind_geolocation_settings', 'a:1:{s:15:"database_prefix";s:32:"DFJnDhnM0bujg4Gh8pjV9oGyIUi6F9YF";}', 'yes'),
(568, 'widget_mla-text-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(569, 'widget_woocommerce_widget_cart', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(570, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(571, 'widget_woocommerce_layered_nav', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(572, 'widget_woocommerce_price_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(573, 'widget_woocommerce_product_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(574, 'widget_woocommerce_product_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(575, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(576, 'widget_woocommerce_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(577, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(578, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(579, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(580, 'widget_woocommerce_rating_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(586, 'has_migrated_cart', 'success', 'yes'),
(589, 'has_migrated_checkout', 'success', 'yes'),
(592, 'aioseo_options_dynamic_localized', 'a:12:{s:42:"searchAppearance_taxonomies_category_title";s:41:"#taxonomy_title #separator_sa #site_title";s:52:"searchAppearance_taxonomies_category_metaDescription";s:21:"#taxonomy_description";s:42:"searchAppearance_taxonomies_post_tag_title";s:41:"#taxonomy_title #separator_sa #site_title";s:52:"searchAppearance_taxonomies_post_tag_metaDescription";s:21:"#taxonomy_description";s:53:"searchAppearance_taxonomies_attachment_category_title";s:41:"#taxonomy_title #separator_sa #site_title";s:63:"searchAppearance_taxonomies_attachment_category_metaDescription";s:21:"#taxonomy_description";s:48:"searchAppearance_taxonomies_attachment_tag_title";s:41:"#taxonomy_title #separator_sa #site_title";s:58:"searchAppearance_taxonomies_attachment_tag_metaDescription";s:21:"#taxonomy_description";s:45:"searchAppearance_taxonomies_product_cat_title";s:41:"#taxonomy_title #separator_sa #site_title";s:55:"searchAppearance_taxonomies_product_cat_metaDescription";s:21:"#taxonomy_description";s:45:"searchAppearance_taxonomies_product_tag_title";s:41:"#taxonomy_title #separator_sa #site_title";s:55:"searchAppearance_taxonomies_product_tag_metaDescription";s:21:"#taxonomy_description";}', 'yes'),
(595, 'aioseo_options_localized', 'a:2:{s:18:"image_title_format";s:38:"#image_title #separator_sa #site_title";s:19:"image_altTag_format";s:8:"#alt_tag";}', 'yes'),
(598, 'mla_custom_field_mapping', 'a:0:{}', 'yes'),
(599, 'mla_iptc_exif_mapping', 'a:3:{s:8:"standard";a:6:{s:10:"post_title";a:5:{s:4:"name";s:5:"Title";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:9:"post_name";a:5:{s:4:"name";s:9:"Name/Slug";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:9:"image_alt";a:5:{s:4:"name";s:8:"ALT Text";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:12:"post_excerpt";a:5:{s:4:"name";s:7:"Caption";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:12:"post_content";a:5:{s:4:"name";s:11:"Description";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:1;}s:9:"post_date";a:5:{s:4:"name";s:11:"Uploaded on";s:10:"iptc_value";s:4:"none";s:10:"exif_value";s:0:"";s:10:"iptc_first";b:1;s:13:"keep_existing";b:0;}}s:8:"taxonomy";a:0:{}s:6:"custom";a:0:{}}', 'yes'),
(600, 'mla_upload_mimes', 'a:4:{s:6:"custom";a:0:{}s:8:"disabled";a:52:{s:3:"ac3";b:1;s:2:"ai";b:1;s:3:"aif";b:1;s:4:"aifc";b:1;s:4:"aiff";b:1;s:2:"au";b:1;s:3:"bin";b:1;s:3:"cat";b:1;s:3:"cdf";b:1;s:3:"cgm";b:1;s:3:"clp";b:1;s:3:"crd";b:1;s:3:"dat";b:1;s:3:"dll";b:1;s:3:"dot";b:1;s:3:"dtd";b:1;s:3:"eps";b:1;s:4:"gtar";b:1;s:3:"ief";b:1;s:3:"ifb";b:1;s:3:"m13";b:1;s:3:"m14";b:1;s:3:"mml";b:1;s:3:"mny";b:1;s:5:"movie";b:1;s:3:"mp2";b:1;s:3:"mpa";b:1;s:3:"msg";b:1;s:3:"mvb";b:1;s:3:"otf";b:1;s:3:"pic";b:1;s:4:"pict";b:1;s:2:"ps";b:1;s:3:"pub";b:1;s:3:"rgb";b:1;s:3:"scd";b:1;s:3:"snd";b:1;s:3:"sql";b:1;s:3:"sst";b:1;s:3:"stl";b:1;s:3:"svg";b:1;s:3:"trm";b:1;s:3:"ttf";b:1;s:3:"w6w";b:1;s:3:"wmf";b:1;s:4:"woff";b:1;s:4:"word";b:1;s:3:"xlc";b:1;s:3:"xlm";b:1;s:3:"xml";b:1;s:3:"xsl";b:1;s:4:"xslt";b:1;}s:11:"description";a:0:{}s:9:"icon_type";a:82:{s:2:"ai";s:10:"postscript";s:4:"aifc";s:5:"audio";s:3:"asx";s:5:"video";s:2:"au";s:5:"audio";s:3:"bin";s:6:"binary";s:1:"c";s:8:"source_c";s:2:"cc";s:10:"source_cpp";s:3:"cgm";s:5:"image";s:5:"class";s:11:"source_java";s:3:"clp";s:6:"knotes";s:3:"crd";s:6:"knotes";s:3:"css";s:10:"stylesheet";s:3:"dat";s:6:"binary";s:3:"dll";s:9:"exec_wine";s:3:"dot";s:8:"document";s:4:"dotx";s:8:"document";s:3:"dtd";s:4:"code";s:3:"eps";s:10:"postscript";s:3:"exe";s:9:"exec_wine";s:4:"gtar";s:7:"archive";s:4:"gzip";s:7:"archive";s:1:"h";s:8:"source_h";s:3:"ics";s:8:"calendar";s:3:"ief";s:5:"image";s:3:"ifb";s:8:"calendar";s:2:"js";s:11:"source_java";s:3:"mdb";s:8:"database";s:3:"mid";s:5:"audio";s:4:"midi";s:5:"audio";s:3:"mml";s:8:"kformula";s:5:"movie";s:5:"video";s:3:"mpa";s:5:"audio";s:3:"mpe";s:5:"video";s:3:"msg";s:7:"message";s:3:"odb";s:8:"database";s:3:"odc";s:3:"log";s:3:"odf";s:8:"kformula";s:3:"odg";s:2:"3d";s:6:"onepkg";s:6:"knotes";s:6:"onetmp";s:6:"knotes";s:6:"onetoc";s:6:"knotes";s:7:"onetoc2";s:6:"knotes";s:3:"otf";s:4:"font";s:3:"pdf";s:3:"pdf";s:3:"pic";s:5:"image";s:4:"pict";s:5:"image";s:3:"pot";s:11:"interactive";s:4:"potm";s:11:"interactive";s:4:"potx";s:11:"interactive";s:4:"ppam";s:11:"interactive";s:2:"ps";s:10:"postscript";s:3:"psd";s:5:"image";s:3:"pub";s:8:"document";s:2:"qt";s:9:"quicktime";s:2:"ra";s:5:"audio";s:3:"rgb";s:5:"image";s:3:"rtx";s:4:"text";s:3:"snd";s:5:"audio";s:3:"sql";s:8:"database";s:3:"svg";s:9:"vectorgfx";s:3:"trm";s:11:"interactive";s:3:"ttf";s:13:"font_truetype";s:3:"w6w";s:8:"document";s:3:"wax";s:5:"audio";s:4:"webm";s:5:"video";s:2:"wm";s:5:"video";s:3:"wmf";s:9:"vectorgfx";s:3:"wmx";s:5:"video";s:4:"woff";s:4:"font";s:4:"word";s:8:"document";s:3:"wri";s:8:"document";s:3:"xla";s:11:"spreadsheet";s:4:"xlam";s:11:"spreadsheet";s:3:"xlc";s:11:"spreadsheet";s:3:"xlm";s:11:"spreadsheet";s:3:"xlt";s:11:"spreadsheet";s:4:"xltm";s:11:"spreadsheet";s:4:"xltx";s:11:"spreadsheet";s:3:"xlw";s:11:"spreadsheet";s:3:"xml";s:4:"code";s:3:"xsl";s:5:"style";s:4:"xslt";s:4:"code";}}', 'yes'),
(601, 'mla_current_version', '3.14', 'yes'),
(605, 'aioseo_dynamic_settings_backup', '[]', 'yes'),
(606, 'acf_version', '6.2.6.1', 'yes'),
(614, 'wcpay_was_in_use', 'no', 'yes'),
(617, 'updraft_lock_aios_15_minutes_cron_event', '0', 'no'),
(618, 'edd_sl_0ae1d23df4b7ffd123c4f7d601aa6104', 'a:2:{s:7:"timeout";i:1711400827;s:5:"value";s:14035:"{"new_version":"2.2.0","stable_version":"2.2.0","name":"Notion WP Sync Pro","slug":"notion-wp-sync","url":"https:\\/\\/wpconnect.co\\/downloads\\/notion-wp-sync-pro\\/?changelog=1","last_updated":"2024-02-23 11:10:47","homepage":"https:\\/\\/wpconnect.co\\/notion-wordpress-integration\\/","package":"","download_link":"","sections":{"description":"<p>With our Notion to WordPress integration, Notion WP Sync Pro, you\\u2019ll be able to create beautiful websites and manage content directly from Notion, the best digital workplace no code tool! Our plugin can export and sync any Notion database, page and content to your website, without Zapier or Make.\\nCreate databases and pages with structured data into Notion: Notion WP Sync Pro will push and sync data to WordPress, swiftly!<\\/p>\\n<h3>Features<\\/h3>\\n<h4> Connect Notion databases and pages <\\/h4>\\n<p>Connect WordPress to Notion databases &amp; pages (Databases only available in Pro Version)<\\/p>\\n<p>Set up and publish unlimited connections (Pro Version)\\n= Display Notion data in any post type =<\\/p>\\n<p>Display Notion data in WordPress in any post type ; Article, Page, Custom Post Types, with Post Status and Author<\\/p>\\n<p>Map Notion database properties to WordPress fields : title, date, category, excerpt\\u2026 and Custom Fields<\\/p>\\n<h4> Display your content as it is in Notion or customize it <\\/h4>\\n<p>Support of major Notion blocks for pages (Paragraph, Title, List, Table, Separator, Image...) but also columns and internal Properties of Notion pages (cover, icon, ...)<\\/p>\\n<p>Integrate easily your content with our CPT \\u201cNotion Content\\u201d<\\/p>\\n<p>Display it by using our dedicated Gutenberg block or use shortcodes for Divi, Elementor or any Page Builder<\\/p>\\n<h4> Customize synchronization of your data <\\/h4>\\n<p>Trigger data sync automatically or manually<\\/p>\\n<p>Select update frequency or instantly via a webhook<\\/p>\\n<p>Set up synchronization method (add, update, delete)<h3>How to unleash your plugin\'s full potential?<\\/h3>\\nGo to the Notion WP Sync Pro plugin page, click on \\u201cAdd New\\u201d next to \\u201cConnections\\u201d.<\\/p>\\n<p>Choose a name for your new connection.<\\/p>\\n<p>Enter your Internal integration token (Available in your Notion\'s integrations here).<\\/p>\\n<p>Choose the source of your data. From one or more pages. You also have the possibility to include children\'s pages.<\\/p>\\n<p>Select the destination of your content.<\\/p>\\n<p>Link the Notion fields with WordPress fields.<\\/p>\\n<p>Choose the Sync Settings (Strategy and Trigger).<\\/p>\\n<p>Publish the connection, and you\\u2019re done!<\\/p>\\n<p>Tip: By pressing the &quot;Sync Now&quot; button, you can synchronize your contents for the first time (even if you didn\\u2019t choose \\u201cManual only\\u201d trigger).<h3>Support<\\/h3>If you need some assistance, open a ticket on the <a href=\\"https:\\/\\/support.wpconnect.co\\/\\">Support<\\/a>.<h3>Troubleshooting<\\/h3>If you don\'t see your pages, make sure you have shared it with your integration.\\nIf needed, you can access to logs from a FTP server in this folder: \\/wp-content\\/uploads\\/notionwpsync-logs<\\/p>","installation":"<p>From your WordPress Dashboard, go to &quot;Plugins &gt; Add New&quot;.<\\/p>\\n<p>Look for our plugin into the search bar: Notion WP Sync.<\\/p>\\n<p>Click on the \'Install Now\' button of the plugin, and wait a few seconds.<\\/p>\\n<p>Click on the &quot;Activate&quot; button (also available in &quot;Plugins &gt; Installed Plugins&quot;).<\\/p>\\n<p>That\'s it, Notion WP Sync Pro is ready to use, find it in the sidebar!<\\/p>","changelog":"<p>= 2.2.0 =\\nAdded: support for Notion toggle block\\nImprove plugin license management\\nFix 404 error when retrieving Notion users\\nFix can\'t select more than one page\\nFix swapped condition for checkboxes in filters<\\/p>\\n<p>= 2.1.0 =\\nNew branding\\nWP Compatibility 6.4<\\/p>\\n<p>= 2.0.1 =\\nFix issue with hierarchical CPTs introduced with 2.0.0<\\/p>\\n<p>= 2.0.0 =\\nFeature: Import Notion content as users\\nFeature: Added Post Status and Post Author options when importing posts\\nFeature: Added formula field 1.0 support<\\/p>\\n<p>= 1.2.0 =\\nImprove support for ut8 database and emoji\\nAdded support for text background color in rich text<\\/p>\\n<p>= 1.1.0 =\\nFix nested lists not imported.\\nFix imported images renamed\\nImprove synchronization loading indicator accuracy<\\/p>\\n<p>= 1.0.1 =\\nFix sub-pages not imported with the option &quot;Include children\\u2019s pages&quot; set to yes.<\\/p>\\n<p>= 1.0.0 =\\nInitial release<\\/p>","faq":"<h4>What is Notion?<\\/h4>\\n<p>Claiming 20 million users worldwide, Notion.so is an all-in-one digital workplace. It combines various collaborative tools for note-taking, task management, project management (around a kanban board) or even storage and exchange of documents.<\\/p>\\n<h4>Why do I need a Notion account?<\\/h4>\\n<p>Notion WP Sync Pro uses Notion\\u2019s API to send data. Creating an account on Notion is free. Once logged in your contact, you can create and get the Internal Integration Token from this page (don\\u2019t forget to share it with your pages).<\\/p>\\n<h4>Can I use the plugin with a free Notion plan?<\\/h4>\\n<p>Yes, Notion.so offers a free plan, called Notion Individual. It targets small teams of up to 6 people. Allowing the creation of an unlimited number of pages and blocks, Notion Individual gives access to the platform\'s API.\\nDepending on your needs, several paid subscriptions allow you to unlock these limitations while giving access to more advanced features (see prices).<\\/p>\\n<h4>How are my pages synchronized?<\\/h4>\\n<p>Once you have defined the synchronization frequency and published your connection, relax: everything is automatic. It is also possible to manually synchronize the connection - whenever you want - using the \'Sync Now\' button.<\\/p>\\n<h4>Can I synchronize my data with ACF fields?<\\/h4>\\n<p>ACF Support is available in the Pro+ Version. You will be able to synchronize your data from Notion with the following ACF fields: Text, Text area, Number, Range, Email, URL, Password, Image, File, Wisiwyg Editor, Select, Checkbox, Radio Button, Button Group, True \\/ False, Link, Google Map, Date picker, Date Time picker, Time picker, Message for now. More fields support is coming soon.<\\/p>\\n<h4>I can\'t see my pages<\\/h4>\\n<p>To access your data, be sure to share your integration with your pages. To make sure you have shared the connection, follow these instructions.<\\/p>\\n<h4>How can I get support?<\\/h4>\\n<p>If you need some assistance, open a ticket on the Support.<\\/p>\\n"},"banners":{"high":"https:\\/\\/wpconnect.co\\/wp-content\\/uploads\\/edd\\/2023\\/10\\/1544x500-notion-wp-sync-wordpress-org-.png","low":"https:\\/\\/wpconnect.co\\/wp-content\\/uploads\\/edd\\/2023\\/10\\/772x250-notion-wp-sync-wordpress-org-.png"},"icons":{"1x":"https:\\/\\/wpconnect.co\\/wp-content\\/uploads\\/edd\\/2023\\/10\\/1024x439-notion-wp-sync-1-128x128.png","2x":"https:\\/\\/wpconnect.co\\/wp-content\\/uploads\\/edd\\/2023\\/10\\/1024x439-notion-wp-sync-1-256x256.png"},"msg":"No license key has been provided.","tags":["wpconnect","notion","api","automation","nocode"],"requires":"","tested":"6.4.3","requires_php":"7.0","contributors":{"wpconnectco":{"display_name":"wpconnectco","profile":"\\/\\/profiles.wordpress.org\\/wpconnectco","avatar":"https:\\/\\/wordpress.org\\/grav-redirect.php?user=wpconnectco"},"staurand":{"display_name":"staurand","profile":"\\/\\/profiles.wordpress.org\\/staurand","avatar":"https:\\/\\/wordpress.org\\/grav-redirect.php?user=staurand"}},"stable_tag":"2.2.0","short_description":"Connect Notion and send data to WordPress with the Notion WP Sync plugin!","license":"GPLv2 or later","upgrade_notice":"","screenshots":[],"faq":["<h4>What is Notion?<\\/h4>\\n<p>Claiming 20 million users worldwide, Notion.so is an all-in-one digital workplace. It combines various collaborative tools for note-taking, task management, project management (around a kanban board) or even storage and exchange of documents.<\\/p>\\n<h4>Why do I need a Notion account?<\\/h4>\\n<p>Notion WP Sync Pro uses Notion\\u2019s API to send data. Creating an account on Notion is free. Once logged in your contact, you can create and get the Internal Integration Token from this page (don\\u2019t forget to share it with your pages).<\\/p>\\n<h4>Can I use the plugin with a free Notion plan?<\\/h4>\\n<p>Yes, Notion.so offers a free plan, called Notion Individual. It targets small teams of up to 6 people. Allowing the creation of an unlimited number of pages and blocks, Notion Individual gives access to the platform\'s API.\\nDepending on your needs, several paid subscriptions allow you to unlock these limitations while giving access to more advanced features (see prices).<\\/p>\\n<h4>How are my pages synchronized?<\\/h4>\\n<p>Once you have defined the synchronization frequency and published your connection, relax: everything is automatic. It is also possible to manually synchronize the connection - whenever you want - using the \'Sync Now\' button.<\\/p>\\n<h4>Can I synchronize my data with ACF fields?<\\/h4>\\n<p>ACF Support is available in the Pro+ Version. You will be able to synchronize your data from Notion with the following ACF fields: Text, Text area, Number, Range, Email, URL, Password, Image, File, Wisiwyg Editor, Select, Checkbox, Radio Button, Button Group, True \\/ False, Link, Google Map, Date picker, Date Time picker, Time picker, Message for now. More fields support is coming soon.<\\/p>\\n<h4>I can\'t see my pages<\\/h4>\\n<p>To access your data, be sure to share your integration with your pages. To make sure you have shared the connection, follow these instructions.<\\/p>\\n<h4>How can I get support?<\\/h4>\\n<p>If you need some assistance, open a ticket on the Support.<\\/p>\\n"],"warnings":[],"added":"2023-04-07","description":["<p>With our Notion to WordPress integration, Notion WP Sync Pro, you\\u2019ll be able to create beautiful websites and manage content directly from Notion, the best digital workplace no code tool! Our plugin can export and sync any Notion database, page and content to your website, without Zapier or Make.\\nCreate databases and pages with structured data into Notion: Notion WP Sync Pro will push and sync data to WordPress, swiftly!<\\/p>\\n<h3>Features<\\/h3>\\n<h4> Connect Notion databases and pages <\\/h4>\\n<p>Connect WordPress to Notion databases &amp; pages (Databases only available in Pro Version)<\\/p>\\n<p>Set up and publish unlimited connections (Pro Version)\\n= Display Notion data in any post type =<\\/p>\\n<p>Display Notion data in WordPress in any post type ; Article, Page, Custom Post Types, with Post Status and Author<\\/p>\\n<p>Map Notion database properties to WordPress fields : title, date, category, excerpt\\u2026 and Custom Fields<\\/p>\\n<h4> Display your content as it is in Notion or customize it <\\/h4>\\n<p>Support of major Notion blocks for pages (Paragraph, Title, List, Table, Separator, Image...) but also columns and internal Properties of Notion pages (cover, icon, ...)<\\/p>\\n<p>Integrate easily your content with our CPT \\u201cNotion Content\\u201d<\\/p>\\n<p>Display it by using our dedicated Gutenberg block or use shortcodes for Divi, Elementor or any Page Builder<\\/p>\\n<h4> Customize synchronization of your data <\\/h4>\\n<p>Trigger data sync automatically or manually<\\/p>\\n<p>Select update frequency or instantly via a webhook<\\/p>\\n<p>Set up synchronization method (add, update, delete)<h3>How to unleash your plugin\'s full potential?<\\/h3>\\nGo to the Notion WP Sync Pro plugin page, click on \\u201cAdd New\\u201d next to \\u201cConnections\\u201d.<\\/p>\\n<p>Choose a name for your new connection.<\\/p>\\n<p>Enter your Internal integration token (Available in your Notion\'s integrations here).<\\/p>\\n<p>Choose the source of your data. From one or more pages. You also have the possibility to include children\'s pages.<\\/p>\\n<p>Select the destination of your content.<\\/p>\\n<p>Link the Notion fields with WordPress fields.<\\/p>\\n<p>Choose the Sync Settings (Strategy and Trigger).<\\/p>\\n<p>Publish the connection, and you\\u2019re done!<\\/p>\\n<p>Tip: By pressing the &quot;Sync Now&quot; button, you can synchronize your contents for the first time (even if you didn\\u2019t choose \\u201cManual only\\u201d trigger).<h3>Support<\\/h3>If you need some assistance, open a ticket on the <a href=\\"https:\\/\\/support.wpconnect.co\\/\\">Support<\\/a>.<h3>Troubleshooting<\\/h3>If you don\'t see your pages, make sure you have shared it with your integration.\\nIf needed, you can access to logs from a FTP server in this folder: \\/wp-content\\/uploads\\/notionwpsync-logs<\\/p>"],"installation":["<p>From your WordPress Dashboard, go to &quot;Plugins &gt; Add New&quot;.<\\/p>\\n<p>Look for our plugin into the search bar: Notion WP Sync.<\\/p>\\n<p>Click on the \'Install Now\' button of the plugin, and wait a few seconds.<\\/p>\\n<p>Click on the &quot;Activate&quot; button (also available in &quot;Plugins &gt; Installed Plugins&quot;).<\\/p>\\n<p>That\'s it, Notion WP Sync Pro is ready to use, find it in the sidebar!<\\/p>"],"changelog":["<p>= 2.2.0 =\\nAdded: support for Notion toggle block\\nImprove plugin license management\\nFix 404 error when retrieving Notion users\\nFix can\'t select more than one page\\nFix swapped condition for checkboxes in filters<\\/p>\\n<p>= 2.1.0 =\\nNew branding\\nWP Compatibility 6.4<\\/p>\\n<p>= 2.0.1 =\\nFix issue with hierarchical CPTs introduced with 2.0.0<\\/p>\\n<p>= 2.0.0 =\\nFeature: Import Notion content as users\\nFeature: Added Post Status and Post Author options when importing posts\\nFeature: Added formula field 1.0 support<\\/p>\\n<p>= 1.2.0 =\\nImprove support for ut8 database and emoji\\nAdded support for text background color in rich text<\\/p>\\n<p>= 1.1.0 =\\nFix nested lists not imported.\\nFix imported images renamed\\nImprove synchronization loading indicator accuracy<\\/p>\\n<p>= 1.0.1 =\\nFix sub-pages not imported with the option &quot;Include children\\u2019s pages&quot; set to yes.<\\/p>\\n<p>= 1.0.0 =\\nInitial release<\\/p>"],"plugin":"notion-wp-sync-pro\\/notion-wp-sync.php","id":"notion-wp-sync-pro\\/notion-wp-sync.php"}";}', 'no'),
(628, 'wc_remote_inbox_notifications_stored_state', 'O:8:"stdClass":2:{s:22:"there_were_no_products";b:1;s:22:"there_are_now_products";b:0;}', 'no'),
(631, 'jetpack_options', 'a:1:{s:14:"last_heartbeat";i:1711390027;}', 'yes'),
(638, 'aioseo_options', '{"internal":[],"webmasterTools":{"google":null,"bing":null,"yandex":null,"baidu":null,"pinterest":null,"microsoftClarityProjectId":null,"norton":null,"miscellaneousVerification":null},"breadcrumbs":{"enable":true,"separator":"&raquo;","homepageLink":true,"homepageLabel":"Home","breadcrumbPrefix":"","archiveFormat":"Archives for #breadcrumb_archive_post_type_name","searchResultFormat":"Search Results for \'#breadcrumb_search_string\'","errorFormat404":"404 - Page Not Found","showCurrentItem":true,"linkCurrentItem":false,"categoryFullHierarchy":false,"showBlogHome":false},"rssContent":{"before":null,"after":"&lt;p&gt;The post #post_link first appeared on #site_link.&lt;\\/p&gt;"},"advanced":{"truSeo":true,"headlineAnalyzer":true,"seoAnalysis":true,"dashboardWidgets":["seoSetup","seoOverview","seoNews"],"announcements":true,"postTypes":{"all":true,"included":["post","page","product"]},"taxonomies":{"all":true,"included":["category","post_tag","product_cat","product_tag"]},"uninstall":false},"sitemap":{"general":{"enable":true,"filename":"sitemap","indexes":true,"linksPerIndex":1000,"postTypes":{"all":true,"included":["post","page","attachment","product"]},"taxonomies":{"all":true,"included":["category","post_tag","product_cat","product_tag"]},"author":false,"date":false,"additionalPages":{"enable":false,"pages":[]},"advancedSettings":{"enable":false,"excludeImages":false,"excludePosts":[],"excludeTerms":[],"priority":{"homePage":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"postTypes":{"grouped":true,"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"taxonomies":{"grouped":true,"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"archive":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"author":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"}}}},"rss":{"enable":true,"linksPerIndex":50,"postTypes":{"all":true,"included":["post","page","product"]}},"html":{"enable":true,"pageUrl":"","postTypes":{"all":true,"included":["post","page","product"]},"taxonomies":{"all":true,"included":["category","post_tag","product_cat","product_tag"]},"sortOrder":"publish_date","sortDirection":"asc","publicationDate":true,"compactArchives":false,"advancedSettings":{"enable":false,"nofollowLinks":false,"excludePosts":[],"excludeTerms":[]}}},"social":{"profiles":{"sameUsername":{"enable":false,"username":null,"included":["facebookPageUrl","twitterUrl","tiktokUrl","pinterestUrl","instagramUrl","youtubeUrl","linkedinUrl"]},"urls":{"facebookPageUrl":null,"twitterUrl":null,"instagramUrl":null,"tiktokUrl":null,"pinterestUrl":null,"youtubeUrl":null,"linkedinUrl":null,"tumblrUrl":null,"yelpPageUrl":null,"soundCloudUrl":null,"wikipediaUrl":null,"myspaceUrl":null,"googlePlacesUrl":null},"additionalUrls":null},"facebook":{"general":{"enable":true,"defaultImageSourcePosts":"default","customFieldImagePosts":null,"defaultImagePosts":"","defaultImagePostsWidth":"","defaultImagePostsHeight":"","showAuthor":true,"siteName":"#site_title #separator_sa #tagline"},"homePage":{"image":"","title":"","description":"","imageWidth":"","imageHeight":"","objectType":"website"},"advanced":{"enable":false,"adminId":"","appId":"","authorUrl":"","generateArticleTags":false,"useKeywordsInTags":true,"useCategoriesInTags":true,"usePostTagsInTags":true}},"twitter":{"general":{"enable":true,"useOgData":false,"defaultCardType":"summary_large_image","defaultImageSourcePosts":"default","customFieldImagePosts":null,"defaultImagePosts":"","showAuthor":true,"additionalData":false},"homePage":{"image":"","title":"","description":"","cardType":"summary"}}},"searchAppearance":{"global":{"separator":"&#45;","siteTitle":"#site_title #separator_sa #tagline","metaDescription":"#tagline","keywords":null,"schema":{"websiteName":"Theatrum Mundi","websiteAlternateName":null,"siteRepresents":"organization","person":null,"organizationName":"Theatrum Mundi","organizationLogo":"","personName":null,"personLogo":null,"phone":null,"contactType":null,"contactTypeManual":null}},"advanced":{"globalRobotsMeta":{"default":true,"noindex":false,"nofollow":false,"noindexPaginated":true,"nofollowPaginated":true,"noindexFeed":true,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"sitelinks":true,"noIndexEmptyCat":true,"removeStopWords":false,"noPaginationForCanonical":true,"useKeywords":false,"keywordsLooking":true,"useCategoriesForMetaKeywords":false,"useTagsForMetaKeywords":false,"dynamicallyGenerateKeywords":false,"pagedFormat":"#separator_sa Page #page_number","runShortcodes":false,"crawlCleanup":{"enable":false,"feeds":{"global":true,"globalComments":false,"staticBlogPage":true,"authors":true,"postComments":false,"search":false,"attachments":false,"archives":{"all":false,"included":[]},"taxonomies":{"all":false,"included":["category"]},"atom":false,"rdf":false,"paginated":false},"removeUnrecognizedQueryArgs":true,"allowedQueryArgs":"\\/^utm_*\\/"}},"archives":{"author":{"show":true,"title":"#author_name #separator_sa #site_title","metaDescription":"#author_bio","advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"keywords":null}},"date":{"show":true,"title":"#archive_date #separator_sa #site_title","metaDescription":"","advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"keywords":null}},"search":{"show":false,"title":"#search_term #separator_sa #site_title","metaDescription":"","advanced":{"robotsMeta":{"default":false,"noindex":true,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"keywords":null}}}},"searchStatistics":{"postTypes":{"all":true,"included":["post","page"]}},"tools":{"robots":{"enable":false,"rules":[],"robotsDetected":true},"importExport":{"backup":{"lastTime":null,"data":null}}},"deprecated":{"searchAppearance":{"global":{"descriptionFormat":null,"schema":{"enableSchemaMarkup":true}},"advanced":{"autogenerateDescriptions":true,"runShortcodesInDescription":true,"useContentForAutogeneratedDescriptions":false,"excludePosts":[],"excludeTerms":[]}},"sitemap":{"general":{"advancedSettings":{"dynamic":true}}},"tools":{"blocker":{"blockBots":null,"blockReferer":null,"track":null,"custom":{"enable":null,"bots":"Abonti\\naggregator\\nAhrefsBot\\nasterias\\nBDCbot\\nBLEXBot\\nBuiltBotTough\\nBullseye\\nBunnySlippers\\nca-crawler\\nCCBot\\nCegbfeieh\\nCheeseBot\\nCherryPicker\\nCopyRightCheck\\ncosmos\\nCrescent\\ndiscobot\\nDittoSpyder\\nDotBot\\nDownload Ninja\\nEasouSpider\\nEmailCollector\\nEmailSiphon\\nEmailWolf\\nEroCrawler\\nExtractorPro\\nFasterfox\\nFeedBooster\\nFoobot\\nGenieo\\ngrub-client\\nHarvest\\nhloader\\nhttplib\\nHTTrack\\nhumanlinks\\nieautodiscovery\\nInfoNaviRobot\\nIstellaBot\\nJava\\/1.\\nJennyBot\\nk2spider\\nKenjin Spider\\nKeyword Density\\/0.9\\nlarbin\\nLexiBot\\nlibWeb\\nlibwww\\nLinkextractorPro\\nlinko\\nLinkScan\\/8.1a Unix\\nLinkWalker\\nLNSpiderguy\\nlwp-trivial\\nmagpie\\nMata Hari\\nMaxPointCrawler\\nMegaIndex\\nMicrosoft URL Control\\nMIIxpc\\nMippin\\nMissigua Locator\\nMister PiX\\nMJ12bot\\nmoget\\nMSIECrawler\\nNetAnts\\nNICErsPRO\\nNiki-Bot\\nNPBot\\nNutch\\nOffline Explorer\\nOpenfind\\npanscient.com\\nPHP\\/5.{\\nProPowerBot\\/2.14\\nProWebWalker\\nPython-urllib\\nQueryN Metasearch\\nRepoMonkey\\nSISTRIX\\nsitecheck.Internetseer.com\\nSiteSnagger\\nSnapPreviewBot\\nSogou\\nSpankBot\\nspanner\\nspbot\\nSpinn3r\\nsuzuran\\nSzukacz\\/1.4\\nTeleport\\nTelesoft\\nThe Intraformant\\nTheNomad\\nTightTwatBot\\nTitan\\ntoCrawl\\/UrlDispatcher\\nTrue_Robot\\nturingos\\nTurnitinBot\\nUbiCrawler\\nUnisterBot\\nURLy Warning\\nVCI\\nWBSearchBot\\nWeb Downloader\\/6.9\\nWeb Image Collector\\nWebAuto\\nWebBandit\\nWebCopier\\nWebEnhancer\\nWebmasterWorldForumBot\\nWebReaper\\nWebSauger\\nWebsite Quester\\nWebster Pro\\nWebStripper\\nWebZip\\nWotbox\\nwsr-agent\\nWWW-Collector-E\\nXenu\\nZao\\nZeus\\nZyBORG\\ncoccoc\\nIncutio\\nlmspider\\nmemoryBot\\nserf\\nUnknown\\nuptime files","referer":"semalt.com\\nkambasoft.com\\nsavetubevideo.com\\nbuttons-for-website.com\\nsharebutton.net\\nsoundfrost.org\\nsrecorder.com\\nsoftomix.com\\nsoftomix.net\\nmyprintscreen.com\\njoinandplay.me\\nfbfreegifts.com\\nopenmediasoft.com\\nzazagames.org\\nextener.org\\nopenfrost.com\\nopenfrost.net\\ngooglsucks.com\\nbest-seo-offer.com\\nbuttons-for-your-website.com\\nwww.Get-Free-Traffic-Now.com\\nbest-seo-solution.com\\nbuy-cheap-online.info\\nsite3.free-share-buttons.com\\nwebmaster-traffic.com"}}}}}', 'yes'),
(640, 'aioseo_options_pro', '{"internal":[],"breadcrumbs":{"advanced":{"taxonomySkipUnselected":false,"showPaged":true,"pagedFormat":"Page #breadcrumb_format_page_number"}},"advanced":{"adminBarMenu":true,"usageTracking":true,"autoUpdates":"all","openAiKey":""},"sitemap":{"video":{"enable":true,"filename":"video-sitemap","indexes":true,"linksPerIndex":1000,"postTypes":{"all":true,"included":["post","page","attachment"]},"taxonomies":{"all":true,"included":["product_cat","product_tag"]},"additionalPages":{"enable":false,"pages":[]},"advancedSettings":{"enable":false,"excludePosts":[],"excludeTerms":[],"dynamic":true,"customFields":false}},"news":{"enable":true,"publicationName":"Theatrum Mundi","genre":null,"postTypes":{"all":false,"included":["post"]},"additionalPages":{"enable":false,"pages":[]},"advancedSettings":{"enable":false,"excludePosts":[],"priority":{"homePage":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"postTypes":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"taxonomies":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"}}}}},"social":{"facebook":{"general":{"defaultImageSourceTerms":"default","customFieldImageTerms":null,"defaultImageTerms":"","defaultImageTermsWidth":"","defaultImageTermsHeight":""}},"twitter":{"general":{"defaultImageSourceTerms":"default","customFieldImageTerms":null,"defaultImageTerms":""}}},"searchAppearance":{"advanced":{"removeCatBase":false}},"deprecated":{"sitemap":{"video":{"advancedSettings":{"dynamic":false}}},"webmasterTools":{"googleAnalytics":{"gtmContainerId":null}}},"general":{"licenseKey":null},"accessControl":{"administrator":{"useDefault":true,"dashboard":true,"generalSettings":true,"searchAppearanceSettings":true,"socialNetworksSettings":true,"sitemapSettings":true,"redirectsManage":true,"pageRedirectsManage":true,"redirectsSettings":true,"seoAnalysisSettings":true,"toolsSettings":true,"featureManagerSettings":true,"pageAnalysis":true,"searchStatisticsSettings":true,"pageGeneralSettings":true,"pageAdvancedSettings":true,"pageSchemaSettings":true,"pageSocialSettings":true,"localSeoSettings":true,"pageLocalSeoSettings":true,"linkAssistantSettings":true,"pageLinkAssistantSettings":true,"setupWizard":true,"pageSeoRevisionsSettings":true},"editor":{"useDefault":true,"dashboard":false,"generalSettings":true,"searchAppearanceSettings":true,"socialNetworksSettings":true,"sitemapSettings":false,"redirectsManage":true,"pageRedirectsManage":true,"redirectsSettings":false,"seoAnalysisSettings":false,"toolsSettings":false,"featureManagerSettings":false,"pageAnalysis":true,"searchStatisticsSettings":false,"pageGeneralSettings":true,"pageAdvancedSettings":true,"pageSchemaSettings":true,"pageSocialSettings":true,"localSeoSettings":false,"pageLocalSeoSettings":false,"linkAssistantSettings":false,"pageLinkAssistantSettings":false,"setupWizard":false,"pageSeoRevisionsSettings":true},"author":{"useDefault":true,"dashboard":false,"generalSettings":false,"searchAppearanceSettings":false,"socialNetworksSettings":false,"sitemapSettings":false,"redirectsManage":false,"pageRedirectsManage":false,"redirectsSettings":false,"seoAnalysisSettings":false,"toolsSettings":false,"featureManagerSettings":false,"pageAnalysis":true,"searchStatisticsSettings":false,"pageGeneralSettings":true,"pageAdvancedSettings":true,"pageSchemaSettings":true,"pageSocialSettings":true,"localSeoSettings":false,"pageLocalSeoSettings":false,"linkAssistantSettings":false,"pageLinkAssistantSettings":false,"setupWizard":false,"pageSeoRevisionsSettings":false},"contributor":{"useDefault":true,"dashboard":false,"generalSettings":false,"searchAppearanceSettings":false,"socialNetworksSettings":false,"sitemapSettings":false,"redirectsManage":false,"pageRedirectsManage":false,"redirectsSettings":false,"seoAnalysisSettings":false,"toolsSettings":false,"featureManagerSettings":false,"pageAnalysis":true,"searchStatisticsSettings":false,"pageGeneralSettings":true,"pageAdvancedSettings":true,"pageSchemaSettings":true,"pageSocialSettings":true,"localSeoSettings":false,"pageLocalSeoSettings":false,"linkAssistantSettings":false,"pageLinkAssistantSettings":false,"setupWizard":false,"pageSeoRevisionsSettings":false},"seoManager":{"useDefault":true,"dashboard":true,"generalSettings":true,"searchAppearanceSettings":false,"socialNetworksSettings":false,"sitemapSettings":true,"redirectsManage":true,"pageRedirectsManage":true,"redirectsSettings":true,"seoAnalysisSettings":false,"toolsSettings":false,"featureManagerSettings":false,"pageAnalysis":true,"searchStatisticsSettings":true,"pageGeneralSettings":true,"pageAdvancedSettings":true,"pageSchemaSettings":true,"pageSocialSettings":true,"localSeoSettings":true,"pageLocalSeoSettings":true,"linkAssistantSettings":true,"pageLinkAssistantSettings":true,"setupWizard":true,"pageSeoRevisionsSettings":true},"seoEditor":{"useDefault":true,"dashboard":false,"generalSettings":false,"searchAppearanceSettings":false,"socialNetworksSettings":false,"sitemapSettings":false,"redirectsManage":false,"pageRedirectsManage":true,"redirectsSettings":false,"seoAnalysisSettings":false,"toolsSettings":false,"featureManagerSettings":false,"pageAnalysis":true,"searchStatisticsSettings":false,"pageGeneralSettings":true,"pageAdvancedSettings":true,"pageSchemaSettings":true,"pageSocialSettings":true,"localSeoSettings":false,"pageLocalSeoSettings":true,"linkAssistantSettings":false,"pageLinkAssistantSettings":true,"setupWizard":false,"pageSeoRevisionsSettings":true}},"image":{"format":{"title":"#image_title #separator_sa #site_title","altTag":"#alt_tag"},"stripPunctuation":{"title":false,"altTag":false},"title":{"format":"#image_title #separator_sa #site_title","stripPunctuation":false,"charactersToKeep":{"dashes":false,"underscores":false,"numbers":true,"plus":true,"apostrophe":false,"pound":false,"ampersand":false},"charactersToConvert":{"dashes":false,"underscores":false},"casing":"","advancedSettings":{"excludePosts":[],"excludeTerms":[]}},"altTag":{"format":"#alt_tag","stripPunctuation":false,"charactersToKeep":{"dashes":false,"underscores":false,"numbers":true,"plus":true,"apostrophe":false,"pound":false,"ampersand":false},"charactersToConvert":{"dashes":true,"underscores":true},"casing":"","advancedSettings":{"excludePosts":[],"excludeTerms":[]}},"caption":{"autogenerate":true,"format":"#image_title","stripPunctuation":true,"charactersToKeep":{"dashes":false,"underscores":false,"numbers":true,"plus":true,"apostrophe":false,"pound":false,"ampersand":false},"charactersToConvert":{"dashes":true,"underscores":true},"casing":""},"description":{"autogenerate":true,"format":"#image_title","stripPunctuation":true,"charactersToKeep":{"dashes":false,"underscores":false,"numbers":true,"plus":true,"apostrophe":false,"pound":false,"ampersand":false},"charactersToConvert":{"dashes":true,"underscores":true},"casing":""},"filename":{"stripPunctuation":true,"charactersToKeep":{"dashes":true,"underscores":true,"numbers":true,"plus":true,"apostrophe":false,"pound":false,"ampersand":false},"casing":"","wordsToStrip":""}},"localBusiness":{"locations":{"general":{"multiple":false,"display":null,"singleLabel":null,"pluralLabel":null,"permalink":null,"categoryPermalink":null,"useCustomSlug":false,"customSlug":null,"useCustomCategorySlug":false,"customCategorySlug":null,"enhancedSearch":false,"enhancedSearchExcerpt":false},"business":{"name":null,"businessType":"LocalBusiness","image":null,"areaServed":null,"urls":{"website":"https:\\/\\/theatrum.ssl","aboutPage":null,"contactPage":null},"address":{"streetLine1":null,"streetLine2":null,"zipCode":null,"city":null,"state":null,"country":null,"addressFormat":null},"contact":{"email":null,"phone":null,"phoneFormatted":null,"fax":null,"faxFormatted":null},"ids":{"vat":null,"tax":null,"chamberOfCommerce":null},"payment":{"priceRange":null,"currenciesAccepted":null,"methods":null}}},"openingHours":{"show":true,"display":null,"alwaysOpen":false,"use24hFormat":false,"timezone":null,"labels":{"closed":null,"alwaysOpen":null},"days":{"monday":{"open24h":false,"closed":false,"openTime":"09:00","closeTime":"17:00"},"tuesday":{"open24h":false,"closed":false,"openTime":"09:00","closeTime":"17:00"},"wednesday":{"open24h":false,"closed":false,"openTime":"09:00","closeTime":"17:00"},"thursday":{"open24h":false,"closed":false,"openTime":"09:00","closeTime":"17:00"},"friday":{"open24h":false,"closed":false,"openTime":"09:00","closeTime":"17:00"},"saturday":{"open24h":false,"closed":false,"openTime":"09:00","closeTime":"17:00"},"sunday":{"open24h":false,"closed":false,"openTime":"09:00","closeTime":"17:00"}}},"maps":{"apiKey":null,"apiKeyValid":null,"mapsEmbedApiEnabled":false,"mapOptions":{"center":{"lat":47.6205063000000023976099328137934207916259765625,"lng":-122.3492774000000054002157412469387054443359375},"zoom":16,"mapTypeId":"roadmap","streetViewControl":false},"customMarker":null,"placeId":null}}}', 'yes'),
(642, 'aioseo_options_dynamic', '{"sitemap":{"priority":{"postTypes":{"post":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"page":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"attachment":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"product":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"}},"taxonomies":{"category":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"post_tag":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"attachment_category":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"attachment_tag":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"product_cat":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"product_tag":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"}}}},"social":{"facebook":{"general":{"postTypes":{"post":{"objectType":"article"},"page":{"objectType":"article"},"attachment":{"objectType":"article"},"product":{"objectType":"article"}},"taxonomies":{"category":{"objectType":"article"},"post_tag":{"objectType":"article"},"attachment_category":{"objectType":"article"},"attachment_tag":{"objectType":"article"},"product_cat":{"objectType":"article"},"product_tag":{"objectType":"article"}}}}},"searchAppearance":{"postTypes":{"post":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"bulkEditing":"enabled"},"title":"#post_title #separator_sa #site_title","metaDescription":"#post_excerpt","schemaType":"Article","webPageType":"WebPage","articleType":"BlogPosting","customFields":null},"page":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"bulkEditing":"enabled"},"title":"#post_title #separator_sa #site_title","metaDescription":"#post_content","schemaType":"WebPage","webPageType":"WebPage","articleType":"BlogPosting","customFields":null},"attachment":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"bulkEditing":"enabled"},"title":"#post_title #separator_sa #site_title","metaDescription":"#attachment_caption","schemaType":"ItemPage","webPageType":"ItemPage","articleType":"BlogPosting","customFields":null,"redirectAttachmentUrls":"attachment"},"product":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"bulkEditing":"enabled"},"title":"#post_title #separator_sa #site_title","metaDescription":"#post_excerpt","schemaType":"Product","webPageType":"ItemPage","articleType":"BlogPosting","customFields":null}},"taxonomies":{"category":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true},"title":"#taxonomy_title #separator_sa #site_title","metaDescription":"#taxonomy_description"},"post_tag":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true},"title":"#taxonomy_title #separator_sa #site_title","metaDescription":"#taxonomy_description"},"attachment_category":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true},"title":"#taxonomy_title #separator_sa #site_title","metaDescription":"#taxonomy_description"},"attachment_tag":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true},"title":"#taxonomy_title #separator_sa #site_title","metaDescription":"#taxonomy_description"},"product_cat":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true},"title":"#taxonomy_title #separator_sa #site_title","metaDescription":"#taxonomy_description"},"product_tag":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true},"title":"#taxonomy_title #separator_sa #site_title","metaDescription":"#taxonomy_description"}},"archives":[]}}', 'yes') ;
INSERT INTO `tu_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(644, 'aioseo_options_dynamic_pro', '{"social":{"facebook":{"general":{"taxonomies":[]}}},"breadcrumbs":{"postTypes":{"post":{"useDefaultTemplate":true,"taxonomy":"","showArchiveCrumb":true,"showTaxonomyCrumbs":true,"showHomeCrumb":true,"showPrefixCrumb":true,"showParentCrumbs":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_post_title&quot;&gt;#breadcrumb_post_title&lt;\\/a&gt;\\n&lt;\\/span&gt;"},"page":{"useDefaultTemplate":true,"taxonomy":"","showArchiveCrumb":true,"showTaxonomyCrumbs":true,"showHomeCrumb":true,"showPrefixCrumb":true,"showParentCrumbs":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_post_title&quot;&gt;#breadcrumb_post_title&lt;\\/a&gt;\\n&lt;\\/span&gt;","parentTemplate":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_post_title&quot;&gt;#breadcrumb_post_title&lt;\\/a&gt;\\n&lt;\\/span&gt;"},"attachment":{"useDefaultTemplate":true,"taxonomy":"","showArchiveCrumb":true,"showTaxonomyCrumbs":true,"showHomeCrumb":true,"showPrefixCrumb":true,"showParentCrumbs":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_post_title&quot;&gt;#breadcrumb_post_title&lt;\\/a&gt;\\n&lt;\\/span&gt;"},"product":{"useDefaultTemplate":true,"taxonomy":"","showArchiveCrumb":true,"showTaxonomyCrumbs":true,"showHomeCrumb":true,"showPrefixCrumb":true,"showParentCrumbs":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_post_title&quot;&gt;#breadcrumb_post_title&lt;\\/a&gt;\\n&lt;\\/span&gt;"}},"taxonomies":{"category":{"useDefaultTemplate":true,"showHomeCrumb":true,"showPrefixCrumb":true,"showParentCrumbs":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_taxonomy_title&quot;&gt;#breadcrumb_taxonomy_title&lt;\\/a&gt;\\n&lt;\\/span&gt;","parentTemplate":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_taxonomy_title&quot;&gt;#breadcrumb_taxonomy_title&lt;\\/a&gt;\\n&lt;\\/span&gt;"},"post_tag":{"useDefaultTemplate":true,"showHomeCrumb":true,"showPrefixCrumb":true,"showParentCrumbs":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_taxonomy_title&quot;&gt;#breadcrumb_taxonomy_title&lt;\\/a&gt;\\n&lt;\\/span&gt;"},"attachment_category":{"useDefaultTemplate":true,"showHomeCrumb":true,"showPrefixCrumb":true,"showParentCrumbs":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_taxonomy_title&quot;&gt;#breadcrumb_taxonomy_title&lt;\\/a&gt;\\n&lt;\\/span&gt;","parentTemplate":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_taxonomy_title&quot;&gt;#breadcrumb_taxonomy_title&lt;\\/a&gt;\\n&lt;\\/span&gt;"},"attachment_tag":{"useDefaultTemplate":true,"showHomeCrumb":true,"showPrefixCrumb":true,"showParentCrumbs":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_taxonomy_title&quot;&gt;#breadcrumb_taxonomy_title&lt;\\/a&gt;\\n&lt;\\/span&gt;"},"product_cat":{"useDefaultTemplate":true,"showHomeCrumb":true,"showPrefixCrumb":true,"showParentCrumbs":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_taxonomy_title&quot;&gt;#breadcrumb_taxonomy_title&lt;\\/a&gt;\\n&lt;\\/span&gt;","parentTemplate":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_taxonomy_title&quot;&gt;#breadcrumb_taxonomy_title&lt;\\/a&gt;\\n&lt;\\/span&gt;"},"product_tag":{"useDefaultTemplate":true,"showHomeCrumb":true,"showPrefixCrumb":true,"showParentCrumbs":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_taxonomy_title&quot;&gt;#breadcrumb_taxonomy_title&lt;\\/a&gt;\\n&lt;\\/span&gt;"}},"archives":{"postTypes":[],"date":{"useDefaultTemplate":true,"template":{"year":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_date_archive_year&quot;&gt;#breadcrumb_date_archive_year&lt;\\/a&gt;\\n&lt;\\/span&gt;","month":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_date_archive_month&quot;&gt;#breadcrumb_date_archive_month&lt;\\/a&gt;\\n&lt;\\/span&gt;","day":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_date_archive_day&quot;&gt;#breadcrumb_date_archive_day&lt;\\/a&gt;\\n&lt;\\/span&gt;"},"showHomeCrumb":true,"showPrefixCrumb":true},"search":{"useDefaultTemplate":true,"showHomeCrumb":true,"showPrefixCrumb":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_search_result_format&quot;&gt;#breadcrumb_search_result_format&lt;\\/a&gt;\\n&lt;\\/span&gt;"},"notFound":{"useDefaultTemplate":true,"showHomeCrumb":true,"showPrefixCrumb":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_404_error_format&quot;&gt;#breadcrumb_404_error_format&lt;\\/a&gt;\\n&lt;\\/span&gt;"},"author":{"useDefaultTemplate":true,"showHomeCrumb":true,"showPrefixCrumb":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_author_display_name&quot;&gt;#breadcrumb_author_display_name&lt;\\/a&gt;\\n&lt;\\/span&gt;"},"blog":{"useDefaultTemplate":true,"showHomeCrumb":true,"showPrefixCrumb":true,"template":"&lt;span class=&quot;aioseo-breadcrumb&quot;&gt;\\n\\t&lt;a href=&quot;#breadcrumb_link&quot; title=&quot;#breadcrumb_blog_page_title&quot;&gt;#breadcrumb_blog_page_title&lt;\\/a&gt;\\n&lt;\\/span&gt;"}}},"accessControl":{"customer":{"useDefault":true,"dashboard":false,"generalSettings":false,"searchAppearanceSettings":false,"socialNetworksSettings":false,"sitemapSettings":false,"redirectsManage":false,"pageRedirectsManage":false,"redirectsSettings":false,"seoAnalysisSettings":false,"toolsSettings":false,"featureManagerSettings":false,"pageAnalysis":false,"searchStatisticsSettings":false,"pageGeneralSettings":false,"pageAdvancedSettings":false,"pageSchemaSettings":false,"pageSocialSettings":false,"localSeoSettings":false,"pageLocalSeoSettings":false,"linkAssistantSettings":false,"pageLinkAssistantSettings":false,"setupWizard":false,"pageSeoRevisionsSettings":false},"shop_manager":{"useDefault":true,"dashboard":false,"generalSettings":false,"searchAppearanceSettings":false,"socialNetworksSettings":false,"sitemapSettings":false,"redirectsManage":false,"pageRedirectsManage":false,"redirectsSettings":false,"seoAnalysisSettings":false,"toolsSettings":false,"featureManagerSettings":false,"pageAnalysis":false,"searchStatisticsSettings":false,"pageGeneralSettings":false,"pageAdvancedSettings":false,"pageSchemaSettings":false,"pageSocialSettings":false,"localSeoSettings":false,"pageLocalSeoSettings":false,"linkAssistantSettings":false,"pageLinkAssistantSettings":false,"setupWizard":false,"pageSeoRevisionsSettings":false}}}', 'yes'),
(651, 'wc_admin_show_legacy_coupon_menu', '0', 'yes'),
(652, 'woocommerce_custom_orders_table_created', 'yes', 'yes'),
(656, 'wp_dark_mode_activated', '1', 'yes'),
(657, 'wp_dark_mode_floating_switch_position', 'right', 'yes'),
(658, 'wp_dark_mode_floating_switch_position_side', 'right', 'yes'),
(659, 'wp_dark_mode_floating_switch_position_side_value', '10', 'yes'),
(660, 'wp_dark_mode_floating_switch_position_bottom_value', '10', 'yes'),
(661, 'wp_dark_mode_upgraded_version', '5.0.3', 'yes'),
(662, 'wc_blocks_db_schema_version', '260', 'yes'),
(663, 'litespeed.gui.lscwp_whm_install', '-1', 'yes'),
(664, 'litespeed.gui.dismiss', '-1', 'yes'),
(665, 'litespeed.gui._summary', '{"new_version":1711994829,"score":1712599629}', 'yes'),
(666, 'fs_accounts', 'a:2:{s:9:"unique_id";s:32:"2f7c020db35a7511ba0f43813f357197";s:5:"sites";a:1:{s:13:"code-snippets";O:7:"FS_Site":26:{s:2:"id";s:8:"14660112";s:7:"updated";s:19:"2024-03-25 18:07:36";s:7:"created";s:19:"2024-03-25 18:07:36";s:22:"\0FS_Entity\0_is_updated";b:0;s:10:"public_key";s:32:"pk_8361624f53705c0205f921e774970";s:10:"secret_key";s:32:"sk_DJuVxrJ_[[$t4#;0q]sL1r8n&D[Ou";s:7:"site_id";s:9:"222855152";s:9:"plugin_id";s:5:"10565";s:7:"user_id";s:7:"6928503";s:5:"title";s:14:"Theatrum Mundi";s:3:"url";s:20:"https://theatrum.ssl";s:7:"version";s:5:"3.6.4";s:8:"language";s:5:"en-US";s:16:"platform_version";s:5:"6.4.3";s:11:"sdk_version";s:6:"2.5.12";s:28:"programming_language_version";s:5:"8.2.2";s:7:"plan_id";s:5:"17873";s:10:"license_id";s:7:"1222111";s:13:"trial_plan_id";N;s:10:"trial_ends";N;s:10:"is_premium";b:1;s:15:"is_disconnected";b:0;s:9:"is_active";b:1;s:14:"is_uninstalled";b:0;s:7:"is_beta";N;s:11:"_is_updated";b:0;}}}', 'yes'),
(675, 'litespeed.data.upgrading', '-1', 'yes'),
(676, 'litespeed.admin_display.messages', '-1', 'yes'),
(677, 'ai1wm_updater', 'a:0:{}', 'yes'),
(688, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiTkRrNU56ZGxORGRqTkdJeU4yVm1ZemxqTkRBd05UUm1OMlJsWldSbE1tSTRZalF4WkRBeE0ySTVNR1pqT1Rjek9UZ3hPV0k0IjtzOjM6InVybCI7czoyMDoiaHR0cHM6Ly90aGVhdHJ1bS5zc2wiO30=', 'yes'),
(689, 'acf_pro_license_status', 'a:11:{s:6:"status";s:6:"active";s:7:"created";i:1689827824;s:6:"expiry";i:1721439424;s:4:"name";s:10:"Freelancer";s:8:"lifetime";b:0;s:8:"refunded";b:0;s:17:"view_licenses_url";s:62:"https://www.advancedcustomfields.com/my-account/view-licenses/";s:23:"manage_subscription_url";s:73:"https://www.advancedcustomfields.com/my-account/view-subscription/413898/";s:9:"error_msg";s:0:"";s:10:"next_check";i:1711476686;s:16:"legacy_multisite";b:1;}', 'yes'),
(693, 'action_scheduler_migration_status', 'complete', 'yes'),
(718, 'mla_post_mime_types', 'a:3:{s:385:"application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-word.document.macroEnabled.12,application/vnd.ms-word.template.macroEnabled.12,application/vnd.oasis.opendocument.text,application/vnd.apple.pages,application/pdf,application/vnd.ms-xpsdocument,application/oxps,application/rtf,application/wordperfect,application/octet-stream";a:7:{s:8:"singular";s:8:"Document";s:6:"plural";s:9:"Documents";s:13:"specification";s:0:"";s:14:"post_mime_type";b:1;s:10:"table_view";b:1;s:10:"menu_order";i:0;s:11:"description";s:34:"Copied from previous filter/plugin";}s:268:"application/vnd.apple.numbers,application/vnd.oasis.opendocument.spreadsheet,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel.sheet.macroEnabled.12,application/vnd.ms-excel.sheet.binary.macroEnabled.12";a:7:{s:8:"singular";s:11:"Spreadsheet";s:6:"plural";s:12:"Spreadsheets";s:13:"specification";s:0:"";s:14:"post_mime_type";b:1;s:10:"table_view";b:1;s:10:"menu_order";i:0;s:11:"description";s:34:"Copied from previous filter/plugin";}s:96:"application/x-gzip,application/rar,application/x-tar,application/zip,application/x-7z-compressed";a:7:{s:8:"singular";s:7:"Archive";s:6:"plural";s:8:"Archives";s:13:"specification";s:0:"";s:14:"post_mime_type";b:1;s:10:"table_view";b:1;s:10:"menu_order";i:0;s:11:"description";s:34:"Copied from previous filter/plugin";}}', 'yes'),
(755, 'theme_mods_twentytwentyfour', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1711392392;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(756, 'current_theme', 'Theatrum Fundamentum', 'yes'),
(757, 'theme_mods_theatrum-fundamentum', 'a:4:{i:0;b:0;s:19:"wp_classic_sidebars";a:0:{}s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(758, 'theme_switched', '', 'yes'),
(775, 'woocommerce_remote_variant_assignment', '56', 'yes'),
(785, 'wc_has_tracked_default_theme', '1', 'yes'),
(787, 'woocommerce_onboarding_profile', 'a:9:{s:15:"business_choice";s:28:"im_just_starting_my_business";s:21:"selling_online_answer";N;s:17:"selling_platforms";N;s:20:"is_store_country_set";b:1;s:8:"industry";a:1:{i:0;s:5:"other";}s:18:"is_agree_marketing";b:0;s:11:"store_email";s:21:"anna@theatrummundi.co";s:9:"completed";b:1;s:23:"is_plugins_page_skipped";b:1;}', 'yes'),
(788, 'woocommerce_tracker_last_send', '1711392710', 'yes'),
(794, 'woocommerce_free_shipping_1_settings', 'a:4:{s:5:"title";s:13:"Free shipping";s:8:"requires";s:0:"";s:10:"min_amount";s:1:"0";s:16:"ignore_discounts";s:2:"no";}', 'yes'),
(795, 'woocommerce_admin_created_default_shipping_zones', 'yes', 'yes'),
(797, 'woocommerce_task_list_tracked_completed_tasks', 'a:2:{i:0;s:8:"shipping";i:1;s:8:"products";}', 'yes'),
(798, 'woocommerce_task_list_prompt_shown', '1', 'yes'),
(812, 'woocommerce_marketplace_suggestions', 'a:2:{s:11:"suggestions";a:28:{i:0;a:4:{s:4:"slug";s:28:"product-edit-meta-tab-header";s:7:"context";s:28:"product-edit-meta-tab-header";s:5:"title";s:22:"Recommended extensions";s:13:"allow-dismiss";b:0;}i:1;a:6:{s:4:"slug";s:39:"product-edit-meta-tab-footer-browse-all";s:7:"context";s:28:"product-edit-meta-tab-footer";s:9:"link-text";s:21:"Browse all extensions";s:3:"url";s:56:"https://woo.com/product-category/woocommerce-extensions/";s:8:"promoted";s:31:"category-woocommerce-extensions";s:13:"allow-dismiss";b:0;}i:2;a:9:{s:4:"slug";s:46:"product-edit-mailchimp-woocommerce-memberships";s:7:"product";s:33:"woocommerce-memberships-mailchimp";s:14:"show-if-active";a:1:{i:0;s:23:"woocommerce-memberships";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:108:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/mailchimp-for-memberships.svg";s:5:"title";s:25:"Mailchimp for Memberships";s:4:"copy";s:79:"Completely automate your email lists by syncing membership changes to Mailchimp";s:11:"button-text";s:10:"Learn More";s:3:"url";s:59:"https://woo.com/products/mailchimp-woocommerce-memberships/";}i:3;a:9:{s:4:"slug";s:19:"product-edit-addons";s:7:"product";s:26:"woocommerce-product-addons";s:14:"show-if-active";a:2:{i:0;s:25:"woocommerce-subscriptions";i:1;s:20:"woocommerce-bookings";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:98:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-add-ons.svg";s:5:"title";s:15:"Product Add-Ons";s:4:"copy";s:93:"Offer add-ons like gift wrapping, special messages or other special options for your products";s:11:"button-text";s:10:"Learn More";s:3:"url";s:41:"https://woo.com/products/product-add-ons/";}i:4;a:9:{s:4:"slug";s:46:"product-edit-woocommerce-subscriptions-gifting";s:7:"product";s:33:"woocommerce-subscriptions-gifting";s:14:"show-if-active";a:1:{i:0;s:25:"woocommerce-subscriptions";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:108:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/gifting-for-subscriptions.svg";s:5:"title";s:25:"Gifting for Subscriptions";s:4:"copy";s:70:"Let customers buy subscriptions for others - they\'re the ultimate gift";s:11:"button-text";s:10:"Learn More";s:3:"url";s:59:"https://woo.com/products/woocommerce-subscriptions-gifting/";}i:5;a:9:{s:4:"slug";s:42:"product-edit-teams-woocommerce-memberships";s:7:"product";s:33:"woocommerce-memberships-for-teams";s:14:"show-if-active";a:1:{i:0;s:23:"woocommerce-memberships";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:104:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/teams-for-memberships.svg";s:5:"title";s:21:"Teams for Memberships";s:4:"copy";s:123:"Adds B2B functionality to WooCommerce Memberships, allowing sites to sell team, group, corporate, or family member accounts";s:11:"button-text";s:10:"Learn More";s:3:"url";s:55:"https://woo.com/products/teams-woocommerce-memberships/";}i:6;a:8:{s:4:"slug";s:29:"product-edit-variation-images";s:7:"product";s:39:"woocommerce-additional-variation-images";s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:110:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/additional-variation-images.svg";s:5:"title";s:27:"Additional Variation Images";s:4:"copy";s:72:"Showcase your products in the best light with a image for each variation";s:11:"button-text";s:10:"Learn More";s:3:"url";s:65:"https://woo.com/products/woocommerce-additional-variation-images/";}i:7;a:9:{s:4:"slug";s:47:"product-edit-woocommerce-subscription-downloads";s:7:"product";s:34:"woocommerce-subscription-downloads";s:14:"show-if-active";a:1:{i:0;s:25:"woocommerce-subscriptions";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:105:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscription-downloads.svg";s:5:"title";s:22:"Subscription Downloads";s:4:"copy";s:57:"Give customers special downloads with their subscriptions";s:11:"button-text";s:10:"Learn More";s:3:"url";s:60:"https://woo.com/products/woocommerce-subscription-downloads/";}i:8;a:8:{s:4:"slug";s:31:"product-edit-min-max-quantities";s:7:"product";s:30:"woocommerce-min-max-quantities";s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:101:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/min-max-quantities.svg";s:5:"title";s:18:"Min/Max Quantities";s:4:"copy";s:81:"Specify minimum and maximum allowed product quantities for orders to be completed";s:11:"button-text";s:10:"Learn More";s:3:"url";s:44:"https://woo.com/products/min-max-quantities/";}i:9;a:8:{s:4:"slug";s:28:"product-edit-name-your-price";s:7:"product";s:27:"woocommerce-name-your-price";s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:98:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/name-your-price.svg";s:5:"title";s:15:"Name Your Price";s:4:"copy";s:70:"Let customers pay what they want - useful for donations, tips and more";s:11:"button-text";s:10:"Learn More";s:3:"url";s:41:"https://woo.com/products/name-your-price/";}i:10;a:8:{s:4:"slug";s:42:"product-edit-woocommerce-one-page-checkout";s:7:"product";s:29:"woocommerce-one-page-checkout";s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:100:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/one-page-checkout.svg";s:5:"title";s:17:"One Page Checkout";s:4:"copy";s:92:"Don\'t make customers click around - let them choose products, checkout & pay all on one page";s:11:"button-text";s:10:"Learn More";s:3:"url";s:55:"https://woo.com/products/woocommerce-one-page-checkout/";}i:11;a:9:{s:4:"slug";s:24:"product-edit-automatewoo";s:7:"product";s:11:"automatewoo";s:14:"show-if-active";a:1:{i:0;s:25:"woocommerce-subscriptions";}s:7:"context";a:1:{i:0;s:26:"product-edit-meta-tab-body";}s:4:"icon";s:96:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscriptions.svg";s:5:"title";s:23:"Automate your marketing";s:4:"copy";s:89:"Win customers and keep them coming back with a nearly endless range of powerful workflows";s:11:"button-text";s:10:"Learn More";s:3:"url";s:37:"https://woo.com/products/automatewoo/";}i:12;a:4:{s:4:"slug";s:19:"orders-empty-header";s:7:"context";s:24:"orders-list-empty-header";s:5:"title";s:20:"Tools for your store";s:13:"allow-dismiss";b:0;}i:13;a:6:{s:4:"slug";s:30:"orders-empty-footer-browse-all";s:7:"context";s:24:"orders-list-empty-footer";s:9:"link-text";s:21:"Browse all extensions";s:3:"url";s:56:"https://woo.com/product-category/woocommerce-extensions/";s:8:"promoted";s:31:"category-woocommerce-extensions";s:13:"allow-dismiss";b:0;}i:14;a:8:{s:4:"slug";s:19:"orders-empty-wc-pay";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:20:"woocommerce-payments";s:4:"icon";s:103:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/woocommerce-payments.svg";s:5:"title";s:11:"WooPayments";s:4:"copy";s:125:"Securely accept payments and manage transactions directly from your WooCommerce dashboard – no setup costs or monthly fees.";s:11:"button-text";s:10:"Learn More";s:3:"url";s:37:"https://woo.com/products/woopayments/";}i:15;a:8:{s:4:"slug";s:19:"orders-empty-zapier";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:18:"woocommerce-zapier";s:4:"icon";s:89:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/zapier.svg";s:5:"title";s:6:"Zapier";s:4:"copy";s:88:"Save time and increase productivity by connecting your store to more than 1000+ services";s:11:"button-text";s:10:"Learn More";s:3:"url";s:44:"https://woo.com/products/woocommerce-zapier/";}i:16;a:8:{s:4:"slug";s:30:"orders-empty-shipment-tracking";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:29:"woocommerce-shipment-tracking";s:4:"icon";s:100:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/shipment-tracking.svg";s:5:"title";s:17:"Shipment Tracking";s:4:"copy";s:86:"Let customers know when their orders will arrive by adding shipment tracking to emails";s:11:"button-text";s:10:"Learn More";s:3:"url";s:43:"https://woo.com/products/shipment-tracking/";}i:17;a:8:{s:4:"slug";s:32:"orders-empty-table-rate-shipping";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:31:"woocommerce-table-rate-shipping";s:4:"icon";s:102:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/table-rate-shipping.svg";s:5:"title";s:19:"Table Rate Shipping";s:4:"copy";s:122:"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count";s:11:"button-text";s:10:"Learn More";s:3:"url";s:45:"https://woo.com/products/table-rate-shipping/";}i:18;a:8:{s:4:"slug";s:40:"orders-empty-shipping-carrier-extensions";s:7:"context";s:22:"orders-list-empty-body";s:4:"icon";s:110:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/shipping-carrier-extensions.svg";s:5:"title";s:27:"Shipping Carrier Extensions";s:4:"copy";s:116:"Show live rates from FedEx, UPS, USPS and more directly on your store - never under or overcharge for shipping again";s:11:"button-text";s:13:"Find Carriers";s:8:"promoted";s:26:"category-shipping-carriers";s:3:"url";s:91:"https://woo.com/product-category/woocommerce-extensions/shipping-methods/shipping-carriers/";}i:19;a:8:{s:4:"slug";s:32:"orders-empty-google-product-feed";s:7:"context";s:22:"orders-list-empty-body";s:7:"product";s:25:"woocommerce-product-feeds";s:4:"icon";s:102:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/google-product-feed.svg";s:5:"title";s:19:"Google Product Feed";s:4:"copy";s:76:"Increase sales by letting customers find you when they\'re shopping on Google";s:11:"button-text";s:10:"Learn More";s:3:"url";s:45:"https://woo.com/products/google-product-feed/";}i:20;a:4:{s:4:"slug";s:35:"products-empty-header-product-types";s:7:"context";s:26:"products-list-empty-header";s:5:"title";s:23:"Other types of products";s:13:"allow-dismiss";b:0;}i:21;a:6:{s:4:"slug";s:32:"products-empty-footer-browse-all";s:7:"context";s:26:"products-list-empty-footer";s:9:"link-text";s:21:"Browse all extensions";s:3:"url";s:56:"https://woo.com/product-category/woocommerce-extensions/";s:8:"promoted";s:31:"category-woocommerce-extensions";s:13:"allow-dismiss";b:0;}i:22;a:8:{s:4:"slug";s:30:"products-empty-product-vendors";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:27:"woocommerce-product-vendors";s:4:"icon";s:98:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-vendors.svg";s:5:"title";s:15:"Product Vendors";s:4:"copy";s:47:"Turn your store into a multi-vendor marketplace";s:11:"button-text";s:10:"Learn More";s:3:"url";s:41:"https://woo.com/products/product-vendors/";}i:23;a:8:{s:4:"slug";s:26:"products-empty-memberships";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:23:"woocommerce-memberships";s:4:"icon";s:94:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/memberships.svg";s:5:"title";s:11:"Memberships";s:4:"copy";s:76:"Give members access to restricted content or products, for a fee or for free";s:11:"button-text";s:10:"Learn More";s:3:"url";s:49:"https://woo.com/products/woocommerce-memberships/";}i:24;a:9:{s:4:"slug";s:35:"products-empty-woocommerce-deposits";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:20:"woocommerce-deposits";s:14:"show-if-active";a:1:{i:0;s:20:"woocommerce-bookings";}s:4:"icon";s:91:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/deposits.svg";s:5:"title";s:8:"Deposits";s:4:"copy";s:75:"Make it easier for customers to pay by offering a deposit or a payment plan";s:11:"button-text";s:10:"Learn More";s:3:"url";s:46:"https://woo.com/products/woocommerce-deposits/";}i:25;a:8:{s:4:"slug";s:40:"products-empty-woocommerce-subscriptions";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:25:"woocommerce-subscriptions";s:4:"icon";s:96:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscriptions.svg";s:5:"title";s:13:"Subscriptions";s:4:"copy";s:97:"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis";s:11:"button-text";s:10:"Learn More";s:3:"url";s:51:"https://woo.com/products/woocommerce-subscriptions/";}i:26;a:8:{s:4:"slug";s:35:"products-empty-woocommerce-bookings";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:20:"woocommerce-bookings";s:4:"icon";s:91:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/bookings.svg";s:5:"title";s:8:"Bookings";s:4:"copy";s:99:"Allow customers to book appointments, make reservations or rent equipment without leaving your site";s:11:"button-text";s:10:"Learn More";s:3:"url";s:46:"https://woo.com/products/woocommerce-bookings/";}i:27;a:8:{s:4:"slug";s:30:"products-empty-product-bundles";s:7:"context";s:24:"products-list-empty-body";s:7:"product";s:27:"woocommerce-product-bundles";s:4:"icon";s:98:"https://woo.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-bundles.svg";s:5:"title";s:15:"Product Bundles";s:4:"copy";s:49:"Offer customizable bundles and assembled products";s:11:"button-text";s:10:"Learn More";s:3:"url";s:41:"https://woo.com/products/product-bundles/";}}s:7:"updated";i:1711392764;}', 'no'),
(824, 'woocommerce_product_editor_show_feedback_bar', 'yes', 'yes'),
(825, 'woocommerce_block_product_tour_shown', 'yes', 'yes'),
(923, 'woocommerce_tracker_ua', 'a:1:{i:0;s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36";}', 'no'),
(1014, 'edd_sl_failed_http_9af2aaf30bbabc71f6a4a4829809b2a1', '1711403431', 'yes'),
(1017, 'wp_migrate_addon_schema', '1', 'yes') ;

#
# End of data contents of table `tu_options`
# --------------------------------------------------------



#
# Delete any existing table `tu_postmeta`
#

DROP TABLE IF EXISTS `tu_postmeta`;


#
# Table structure of table `tu_postmeta`
#

CREATE TABLE `tu_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=339 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_postmeta`
#
INSERT INTO `tu_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 2, '_wp_trash_meta_status', 'publish'),
(4, 2, '_wp_trash_meta_time', '1711344839'),
(5, 2, '_wp_desired_post_slug', 'sample-page'),
(6, 6, '_edit_lock', '1711344710:1'),
(7, 8, '_edit_lock', '1711344710:1'),
(8, 9, '_edit_lock', '1711344711:1'),
(9, 10, '_edit_lock', '1711344711:1'),
(10, 11, '_edit_lock', '1711392566:1'),
(11, 12, '_edit_lock', '1711392553:1'),
(12, 13, '_edit_lock', '1711392567:1'),
(13, 14, '_edit_lock', '1711392566:1'),
(14, 15, '_edit_lock', '1711392567:1'),
(15, 16, '_edit_lock', '1711392554:1'),
(16, 14, '_oembed_24c48aaf7c709cd18e2b1c56c86ce840', '{{unknown}}'),
(17, 26, '_wp_attached_file', '2024/03/placeholder.png'),
(18, 26, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2024/03/placeholder.png";s:8:"filesize";i:6146;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:23:"placeholder-300x200.png";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3887;}s:5:"large";a:5:{s:4:"file";s:24:"placeholder-1024x683.png";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:18469;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"placeholder-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2227;}s:12:"medium_large";a:5:{s:4:"file";s:23:"placeholder-768x512.png";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12559;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(19, 30, '_wp_attached_file', 'woocommerce-placeholder.png'),
(20, 30, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1200;s:6:"height";i:1200;s:4:"file";s:27:"woocommerce-placeholder.png";s:8:"filesize";i:102644;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:35:"woocommerce-placeholder-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12475;}s:5:"large";a:5:{s:4:"file";s:37:"woocommerce-placeholder-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:98202;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"woocommerce-placeholder-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4204;}s:12:"medium_large";a:5:{s:4:"file";s:35:"woocommerce-placeholder-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:60014;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(21, 36, 'origin', 'plugin'),
(22, 37, 'origin', 'plugin'),
(23, 38, 'origin', 'plugin'),
(24, 39, 'origin', 'plugin'),
(25, 40, '_edit_lock', '1711391841:1'),
(26, 40, '_edit_last', '1'),
(27, 41, '_edit_lock', '1711391700:1'),
(28, 41, '_edit_last', '1'),
(29, 50, '_edit_lock', '1711391988:1'),
(30, 51, '_edit_lock', '1711391772:1'),
(31, 52, '_edit_lock', '1711391952:1'),
(35, 50, '_edit_last', '1'),
(36, 50, '_', 'field_6601c277846a2'),
(37, 50, 'challenges_0_', 'Integrate external software'),
(38, 50, '_challenges_0_', 'field_6601c249c6ba1'),
(39, 50, 'challenges_1_', 'Advanced security due to past breaches'),
(40, 50, '_challenges_1_', 'field_6601c249c6ba1'),
(41, 50, 'challenges_2_', 'Reflect LAX Coastal’s Welcoming and Supporting atmosphere visually'),
(42, 50, '_challenges_2_', 'field_6601c249c6ba1'),
(43, 50, 'challenges', '3'),
(44, 50, '_challenges', 'field_6601c234c6ba0'),
(45, 50, 'features_0_', 'Integration with ChamberMaster'),
(46, 50, '_features_0_', 'field_6601c256c6ba3'),
(47, 50, 'features_1_', 'Customized Admin dashboards '),
(48, 50, '_features_1_', 'field_6601c256c6ba3'),
(49, 50, 'features_2_', 'Simplified update process'),
(50, 50, '_features_2_', 'field_6601c256c6ba3'),
(51, 50, 'features_3_', 'Website Manual for staff'),
(52, 50, '_features_3_', 'field_6601c256c6ba3'),
(53, 50, 'features', '4'),
(54, 50, '_features', 'field_6601c256c6ba2'),
(55, 50, 'results_0_', 'Improved member experience'),
(56, 50, '_results_0_', 'field_6601c263c6ba5'),
(57, 50, 'results_1_', 'Improved security with malware removal guarantee within 24 hours.'),
(58, 50, '_results_1_', 'field_6601c263c6ba5'),
(59, 50, 'results', '2'),
(60, 50, '_results', 'field_6601c263c6ba4'),
(61, 50, 'project_link', 'https://laxcoastal.com/'),
(62, 50, '_project_link', 'field_6601c28974d57'),
(63, 53, 'challenges_0_', 'Integrate external software'),
(64, 53, '_challenges_0_', 'field_6601c249c6ba1'),
(65, 53, 'challenges_1_', 'Advanced security due to past breaches'),
(66, 53, '_challenges_1_', 'field_6601c249c6ba1'),
(67, 53, 'challenges_2_', 'Reflect LAX Coastal’s Welcoming and Supporting atmosphere visually'),
(68, 53, '_challenges_2_', 'field_6601c249c6ba1'),
(69, 53, 'challenges', '3'),
(70, 53, '_challenges', 'field_6601c234c6ba0'),
(71, 53, 'features_0_', 'Integration with ChamberMaster'),
(72, 53, '_features_0_', 'field_6601c256c6ba3'),
(73, 53, 'features_1_', 'Customized Admin dashboards '),
(74, 53, '_features_1_', 'field_6601c256c6ba3'),
(75, 53, 'features_2_', 'Simplified update process'),
(76, 53, '_features_2_', 'field_6601c256c6ba3'),
(77, 53, 'features_3_', 'Website Manual for staff'),
(78, 53, '_features_3_', 'field_6601c256c6ba3'),
(79, 53, 'features', '4'),
(80, 53, '_features', 'field_6601c256c6ba2'),
(81, 53, 'results_0_', 'Improved member experience'),
(82, 53, '_results_0_', 'field_6601c263c6ba5'),
(83, 53, 'results_1_', 'Improved security with malware removal guarantee within 24 hours.'),
(84, 53, '_results_1_', 'field_6601c263c6ba5'),
(85, 53, 'results', '2'),
(86, 53, '_results', 'field_6601c263c6ba4'),
(87, 53, 'project_link', 'https://laxcoastal.com/'),
(88, 53, '_project_link', 'field_6601c28974d57'),
(92, 51, '_edit_last', '1'),
(93, 51, '_', 'field_6601c277846a2'),
(94, 51, 'challenges_0_', 'Client/Owner portals to assist website owner in day-to-day work with clients.'),
(95, 51, '_challenges_0_', 'field_6601c249c6ba1'),
(96, 51, 'challenges', '1'),
(97, 51, '_challenges', 'field_6601c234c6ba0'),
(98, 51, 'features_0_', 'Notion integration'),
(99, 51, '_features_0_', 'field_6601c256c6ba3'),
(100, 51, 'features_1_', 'Customized dashboard'),
(101, 51, '_features_1_', 'field_6601c256c6ba3'),
(102, 51, 'features_2_', 'Clean, calming design'),
(103, 51, '_features_2_', 'field_6601c256c6ba3'),
(104, 51, 'features', '3'),
(105, 51, '_features', 'field_6601c256c6ba2'),
(106, 51, 'results_0_', 'To be released…') ;
INSERT INTO `tu_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(107, 51, '_results_0_', 'field_6601c263c6ba5'),
(108, 51, 'results', '1'),
(109, 51, '_results', 'field_6601c263c6ba4'),
(110, 51, 'project_link', 'https://fullcirclefinancialplanning.com/'),
(111, 51, '_project_link', 'field_6601c28974d57'),
(112, 54, 'challenges_0_', 'Client/Owner portals to assist website owner in day-to-day work with clients.'),
(113, 54, '_challenges_0_', 'field_6601c249c6ba1'),
(114, 54, 'challenges', '1'),
(115, 54, '_challenges', 'field_6601c234c6ba0'),
(116, 54, 'features_0_', 'Notion integration'),
(117, 54, '_features_0_', 'field_6601c256c6ba3'),
(118, 54, 'features_1_', 'Customized dashboard'),
(119, 54, '_features_1_', 'field_6601c256c6ba3'),
(120, 54, 'features_2_', 'Clean, calming design'),
(121, 54, '_features_2_', 'field_6601c256c6ba3'),
(122, 54, 'features', '3'),
(123, 54, '_features', 'field_6601c256c6ba2'),
(124, 54, 'results_0_', 'To be released…'),
(125, 54, '_results_0_', 'field_6601c263c6ba5'),
(126, 54, 'results', '1'),
(127, 54, '_results', 'field_6601c263c6ba4'),
(128, 54, 'project_link', 'https://fullcirclefinancialplanning.com/'),
(129, 54, '_project_link', 'field_6601c28974d57'),
(133, 52, '_edit_last', '1'),
(134, 52, '_', 'field_6601c277846a2'),
(135, 52, 'challenges_0_', 'Create an artistic blog'),
(136, 52, '_challenges_0_', 'field_6601c249c6ba1'),
(137, 52, 'challenges_1_', 'Make static content dynamic'),
(138, 52, '_challenges_1_', 'field_6601c249c6ba1'),
(139, 52, 'challenges_2_', 'Create complex taxonomy of categories and tag'),
(140, 52, '_challenges_2_', 'field_6601c249c6ba1'),
(141, 52, 'challenges', '3'),
(142, 52, '_challenges', 'field_6601c234c6ba0'),
(143, 52, 'features_0_', 'Animated intro'),
(144, 52, '_features_0_', 'field_6601c256c6ba3'),
(145, 52, 'features_1_', 'Photos and videos'),
(146, 52, '_features_1_', 'field_6601c256c6ba3'),
(147, 52, 'features_2_', 'Responsive, mobile-friendly design'),
(148, 52, '_features_2_', 'field_6601c256c6ba3'),
(149, 52, 'features', '3'),
(150, 52, '_features', 'field_6601c256c6ba2'),
(151, 52, 'results_0_', 'Engaging content'),
(152, 52, '_results_0_', 'field_6601c263c6ba5'),
(153, 52, 'results_1_', 'SEO-driven content'),
(154, 52, '_results_1_', 'field_6601c263c6ba5'),
(155, 52, 'results_2_', 'Flexibility for future change'),
(156, 52, '_results_2_', 'field_6601c263c6ba5'),
(157, 52, 'results', '3'),
(158, 52, '_results', 'field_6601c263c6ba4'),
(159, 52, 'project_link', 'https://abstractdepressionism.blog/'),
(160, 52, '_project_link', 'field_6601c28974d57'),
(161, 55, 'challenges_0_', 'Create an artistic blog'),
(162, 55, '_challenges_0_', 'field_6601c249c6ba1'),
(163, 55, 'challenges_1_', 'Make static content dynamic'),
(164, 55, '_challenges_1_', 'field_6601c249c6ba1'),
(165, 55, 'challenges_2_', 'Create complex taxonomy of categories and tag'),
(166, 55, '_challenges_2_', 'field_6601c249c6ba1'),
(167, 55, 'challenges', '3'),
(168, 55, '_challenges', 'field_6601c234c6ba0'),
(169, 55, 'features_0_', 'Animated intro'),
(170, 55, '_features_0_', 'field_6601c256c6ba3'),
(171, 55, 'features_1_', 'Photos and videos'),
(172, 55, '_features_1_', 'field_6601c256c6ba3'),
(173, 55, 'features_2_', 'Responsive, mobile-friendly design'),
(174, 55, '_features_2_', 'field_6601c256c6ba3'),
(175, 55, 'features', '3'),
(176, 55, '_features', 'field_6601c256c6ba2'),
(177, 55, 'results_0_', 'Engaging content'),
(178, 55, '_results_0_', 'field_6601c263c6ba5'),
(179, 55, 'results_1_', 'SEO-driven content'),
(180, 55, '_results_1_', 'field_6601c263c6ba5'),
(181, 55, 'results_2_', 'Flexibility for future change'),
(182, 55, '_results_2_', 'field_6601c263c6ba5'),
(183, 55, 'results', '3'),
(184, 55, '_results', 'field_6601c263c6ba4'),
(185, 55, 'project_link', 'https://abstractdepressionism.blog/'),
(186, 55, '_project_link', 'field_6601c28974d57'),
(192, 12, '_edit_last', '1'),
(193, 16, '_edit_last', '1'),
(194, 32, '_edit_last', '1'),
(195, 33, '_edit_last', '1'),
(196, 14, '_edit_last', '1'),
(197, 11, '_edit_last', '1'),
(198, 34, '_edit_last', '1'),
(199, 3, '_edit_last', '1'),
(200, 15, '_edit_last', '1'),
(201, 35, '_edit_last', '1'),
(202, 13, '_edit_last', '1'),
(203, 31, '_edit_last', '1'),
(204, 31, '_edit_lock', '1711392561:1'),
(205, 32, '_wp_page_template', 'default'),
(206, 32, '_edit_lock', '1711397039:1'),
(207, 33, '_wp_page_template', 'default'),
(208, 33, '_edit_lock', '1711397043:1'),
(209, 34, '_wp_page_template', 'default'),
(210, 34, '_edit_lock', '1711397131:1'),
(211, 3, '_edit_lock', '1711392521:1'),
(212, 35, '_edit_lock', '1711392537:1'),
(213, 35, '_wp_page_template', 'default'),
(214, 31, '_wp_page_template', 'default') ;
INSERT INTO `tu_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(215, 65, '_edit_lock', '1711392735:1'),
(216, 65, '_edit_last', '1'),
(217, 65, '_wp_page_template', 'default'),
(218, 69, 'total_sales', '0'),
(219, 69, '_tax_status', 'taxable'),
(220, 69, '_tax_class', ''),
(221, 69, '_manage_stock', 'no'),
(222, 69, '_backorders', 'no'),
(223, 69, '_sold_individually', 'no'),
(224, 69, '_virtual', 'no'),
(225, 69, '_downloadable', 'no'),
(226, 69, '_download_limit', '-1'),
(227, 69, '_download_expiry', '-1'),
(228, 69, '_stock', NULL),
(229, 69, '_stock_status', 'instock'),
(230, 69, '_wc_average_rating', '0'),
(231, 69, '_wc_review_count', '0'),
(232, 69, '_product_version', '8.7.0'),
(233, 69, '_sku', 'unus'),
(234, 69, '_regular_price', '1000'),
(235, 69, '_price', '1000'),
(236, 70, 'total_sales', '0'),
(237, 70, '_tax_status', 'taxable'),
(238, 70, '_tax_class', ''),
(239, 70, '_manage_stock', 'no'),
(240, 70, '_backorders', 'no'),
(241, 70, '_sold_individually', 'no'),
(242, 70, '_virtual', 'no'),
(243, 70, '_downloadable', 'no'),
(244, 70, '_download_limit', '-1'),
(245, 70, '_download_expiry', '-1'),
(246, 70, '_stock', NULL),
(247, 70, '_stock_status', 'instock'),
(248, 70, '_wc_average_rating', '0'),
(249, 70, '_wc_review_count', '0'),
(250, 70, '_product_version', '8.7.0'),
(251, 71, 'total_sales', '0'),
(252, 71, '_tax_status', 'taxable'),
(253, 71, '_tax_class', ''),
(254, 71, '_manage_stock', 'no'),
(255, 71, '_backorders', 'no'),
(256, 71, '_sold_individually', 'no'),
(257, 71, '_virtual', 'no'),
(258, 71, '_downloadable', 'no'),
(259, 71, '_download_limit', '-1'),
(260, 71, '_download_expiry', '-1'),
(261, 71, '_stock', NULL),
(262, 71, '_stock_status', 'instock'),
(263, 71, '_wc_average_rating', '0'),
(264, 71, '_wc_review_count', '0'),
(265, 71, '_product_version', '8.7.0'),
(266, 70, '_sku', 'opus'),
(267, 70, '_regular_price', '3000'),
(268, 70, '_price', '3000'),
(269, 71, '_sku', 'ordinatio'),
(270, 71, '_regular_price', '5000'),
(271, 71, '_price', '5000'),
(272, 72, '_edit_lock', '1711395324:1'),
(273, 72, '_edit_last', '1'),
(276, 78, 'origin', 'theme'),
(277, 80, 'origin', 'theme'),
(278, 81, '_edit_last', '1'),
(279, 81, '_edit_lock', '1711396945:1'),
(280, 83, 'origin', 'theme'),
(281, 85, '_edit_lock', '1711397273:1'),
(282, 85, '_edit_last', '1'),
(301, 97, '_wp_attached_file', '2024/03/fcfp-cover.png'),
(302, 97, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:3811;s:6:"height";i:1874;s:4:"file";s:22:"2024/03/fcfp-cover.png";s:8:"filesize";i:5686387;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:22:"fcfp-cover-300x148.png";s:5:"width";i:300;s:6:"height";i:148;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:72176;}s:5:"large";a:5:{s:4:"file";s:23:"fcfp-cover-1024x504.png";s:5:"width";i:1024;s:6:"height";i:504;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:594291;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"fcfp-cover-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:39629;}s:12:"medium_large";a:5:{s:4:"file";s:22:"fcfp-cover-768x378.png";s:5:"width";i:768;s:6:"height";i:378;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:365707;}s:9:"1536x1536";a:5:{s:4:"file";s:23:"fcfp-cover-1536x755.png";s:5:"width";i:1536;s:6:"height";i:755;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1160918;}s:9:"2048x2048";a:5:{s:4:"file";s:24:"fcfp-cover-2048x1007.png";s:5:"width";i:2048;s:6:"height";i:1007;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1849521;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"fcfp-cover-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:134361;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"fcfp-cover-600x295.png";s:5:"width";i:600;s:6:"height";i:295;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:240640;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"fcfp-cover-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:19165;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(303, 98, '_wp_attached_file', '2024/03/fullmoonroad.jpg'),
(304, 98, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1890;s:6:"height";i:2048;s:4:"file";s:24:"2024/03/fullmoonroad.jpg";s:8:"filesize";i:1127167;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:24:"fullmoonroad-277x300.jpg";s:5:"width";i:277;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9612;}s:5:"large";a:5:{s:4:"file";s:25:"fullmoonroad-945x1024.jpg";s:5:"width";i:945;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:127913;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"fullmoonroad-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3297;}s:12:"medium_large";a:5:{s:4:"file";s:24:"fullmoonroad-768x832.jpg";s:5:"width";i:768;s:6:"height";i:832;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:75601;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"fullmoonroad-1418x1536.jpg";s:5:"width";i:1418;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:294310;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:24:"fullmoonroad-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10720;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:24:"fullmoonroad-600x650.jpg";s:5:"width";i:600;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:45292;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:24:"fullmoonroad-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2028;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(305, 99, '_wp_attached_file', '2024/03/laxcover.png'),
(306, 99, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:3808;s:6:"height";i:1878;s:4:"file";s:20:"2024/03/laxcover.png";s:8:"filesize";i:4005982;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:20:"laxcover-300x148.png";s:5:"width";i:300;s:6:"height";i:148;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:49260;}s:5:"large";a:5:{s:4:"file";s:21:"laxcover-1024x505.png";s:5:"width";i:1024;s:6:"height";i:505;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:435849;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"laxcover-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:26968;}s:12:"medium_large";a:5:{s:4:"file";s:20:"laxcover-768x379.png";s:5:"width";i:768;s:6:"height";i:379;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:262333;}s:9:"1536x1536";a:5:{s:4:"file";s:21:"laxcover-1536x758.png";s:5:"width";i:1536;s:6:"height";i:758;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:876323;}s:9:"2048x2048";a:5:{s:4:"file";s:22:"laxcover-2048x1010.png";s:5:"width";i:2048;s:6:"height";i:1010;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1414516;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:20:"laxcover-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:90743;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:20:"laxcover-600x296.png";s:5:"width";i:600;s:6:"height";i:296;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:169807;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:20:"laxcover-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:13331;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(307, 100, '_wp_attached_file', '2024/03/mask@2x.png'),
(308, 100, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:348;s:6:"height";i:348;s:4:"file";s:19:"2024/03/mask@2x.png";s:8:"filesize";i:4443;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:19:"mask@2x-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:5377;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"mask@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2323;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:19:"mask@2x-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:5377;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:19:"mask@2x-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1459;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(309, 101, '_wp_attached_file', '2024/03/laxcover-1.png'),
(310, 101, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:3808;s:6:"height";i:1878;s:4:"file";s:22:"2024/03/laxcover-1.png";s:8:"filesize";i:4005982;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:22:"laxcover-1-300x148.png";s:5:"width";i:300;s:6:"height";i:148;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:49260;}s:5:"large";a:5:{s:4:"file";s:23:"laxcover-1-1024x505.png";s:5:"width";i:1024;s:6:"height";i:505;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:435849;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"laxcover-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:26968;}s:12:"medium_large";a:5:{s:4:"file";s:22:"laxcover-1-768x379.png";s:5:"width";i:768;s:6:"height";i:379;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:262333;}s:9:"1536x1536";a:5:{s:4:"file";s:23:"laxcover-1-1536x758.png";s:5:"width";i:1536;s:6:"height";i:758;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:876323;}s:9:"2048x2048";a:5:{s:4:"file";s:24:"laxcover-1-2048x1010.png";s:5:"width";i:2048;s:6:"height";i:1010;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1414516;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"laxcover-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:90743;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"laxcover-1-600x296.png";s:5:"width";i:600;s:6:"height";i:296;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:169807;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"laxcover-1-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:13331;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(311, 102, '_wp_attached_file', '2024/03/masks-scaled.jpg'),
(312, 102, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1654;s:4:"file";s:24:"2024/03/masks-scaled.jpg";s:8:"filesize";i:765038;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:17:"masks-300x194.jpg";s:5:"width";i:300;s:6:"height";i:194;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17882;}s:5:"large";a:5:{s:4:"file";s:18:"masks-1024x662.jpg";s:5:"width";i:1024;s:6:"height";i:662;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:159021;}s:9:"thumbnail";a:5:{s:4:"file";s:17:"masks-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8028;}s:12:"medium_large";a:5:{s:4:"file";s:17:"masks-768x496.jpg";s:5:"width";i:768;s:6:"height";i:496;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:94996;}s:9:"1536x1536";a:5:{s:4:"file";s:18:"masks-1536x992.jpg";s:5:"width";i:1536;s:6:"height";i:992;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:321252;}s:9:"2048x2048";a:5:{s:4:"file";s:19:"masks-2048x1323.jpg";s:5:"width";i:2048;s:6:"height";i:1323;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:527063;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:17:"masks-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28081;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:17:"masks-600x388.jpg";s:5:"width";i:600;s:6:"height";i:388;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:61738;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:17:"masks-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4266;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:9:"masks.jpg";}'),
(313, 103, '_wp_attached_file', '2024/03/onstage-scaled.jpg'),
(314, 103, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:26:"2024/03/onstage-scaled.jpg";s:8:"filesize";i:355629;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:19:"onstage-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3526;}s:5:"large";a:5:{s:4:"file";s:20:"onstage-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:32544;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"onstage-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2221;}s:12:"medium_large";a:5:{s:4:"file";s:19:"onstage-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17116;}s:9:"1536x1536";a:5:{s:4:"file";s:21:"onstage-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:89962;}s:9:"2048x2048";a:5:{s:4:"file";s:21:"onstage-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:194857;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:19:"onstage-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5496;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:19:"onstage-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10596;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:19:"onstage-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1520;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:11:"onstage.jpg";}'),
(315, 104, '_wp_attached_file', '2024/03/stage-view-scaled.jpg'),
(316, 104, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:29:"2024/03/stage-view-scaled.jpg";s:8:"filesize";i:519672;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:22:"stage-view-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6160;}s:5:"large";a:5:{s:4:"file";s:23:"stage-view-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:50091;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"stage-view-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3706;}s:12:"medium_large";a:5:{s:4:"file";s:22:"stage-view-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:27321;}s:9:"1536x1536";a:5:{s:4:"file";s:24:"stage-view-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:131782;}s:9:"2048x2048";a:5:{s:4:"file";s:24:"stage-view-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:286125;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"stage-view-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9423;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"stage-view-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17474;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"stage-view-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2374;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:14:"stage-view.jpg";}'),
(317, 105, '_wp_attached_file', '2024/03/statues-scaled.jpg'),
(318, 105, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:26:"2024/03/statues-scaled.jpg";s:8:"filesize";i:667558;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:19:"statues-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16140;}s:5:"large";a:5:{s:4:"file";s:20:"statues-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:140477;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"statues-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7718;}s:12:"medium_large";a:5:{s:4:"file";s:19:"statues-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:83834;}s:9:"1536x1536";a:5:{s:4:"file";s:21:"statues-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:282199;}s:9:"2048x2048";a:5:{s:4:"file";s:21:"statues-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:460173;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:19:"statues-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:25481;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:19:"statues-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:54215;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:19:"statues-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4125;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:11:"statues.jpg";}'),
(319, 106, '_wp_attached_file', '2024/03/theatrum2.jpg'),
(320, 106, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:325;s:6:"height";i:488;s:4:"file";s:21:"2024/03/theatrum2.jpg";s:8:"filesize";i:76632;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:21:"theatrum2-200x300.jpg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:30514;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"theatrum2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12099;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:21:"theatrum2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:45604;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:21:"theatrum2-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5804;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(321, 107, '_wp_attached_file', '2024/03/theatrum3.jpg'),
(322, 107, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:423;s:6:"height";i:480;s:4:"file";s:21:"2024/03/theatrum3.jpg";s:8:"filesize";i:53919;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:21:"theatrum3-264x300.jpg";s:5:"width";i:264;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21256;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"theatrum3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7407;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:21:"theatrum3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:23201;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:21:"theatrum3-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4017;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(323, 108, '_wp_attached_file', '2024/03/Theatrvm-orbis-terrarvm.png'),
(324, 108, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1716;s:6:"height";i:1401;s:4:"file";s:35:"2024/03/Theatrvm-orbis-terrarvm.png";s:8:"filesize";i:1950768;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:35:"Theatrvm-orbis-terrarvm-300x245.png";s:5:"width";i:300;s:6:"height";i:245;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:74482;}s:5:"large";a:5:{s:4:"file";s:36:"Theatrvm-orbis-terrarvm-1024x836.png";s:5:"width";i:1024;s:6:"height";i:836;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:743022;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"Theatrvm-orbis-terrarvm-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:29124;}s:12:"medium_large";a:5:{s:4:"file";s:35:"Theatrvm-orbis-terrarvm-768x627.png";s:5:"width";i:768;s:6:"height";i:627;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:438972;}s:9:"1536x1536";a:5:{s:4:"file";s:37:"Theatrvm-orbis-terrarvm-1536x1254.png";s:5:"width";i:1536;s:6:"height";i:1254;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1509221;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:35:"Theatrvm-orbis-terrarvm-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:107467;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:35:"Theatrvm-orbis-terrarvm-600x490.png";s:5:"width";i:600;s:6:"height";i:490;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:275215;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:35:"Theatrvm-orbis-terrarvm-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:13846;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(325, 109, '_wp_attached_file', '2024/03/Typvs-orbis-terrarvm.png'),
(326, 109, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1716;s:6:"height";i:1465;s:4:"file";s:32:"2024/03/Typvs-orbis-terrarvm.png";s:8:"filesize";i:3532070;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:32:"Typvs-orbis-terrarvm-300x256.png";s:5:"width";i:300;s:6:"height";i:256;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:149830;}s:5:"large";a:5:{s:4:"file";s:33:"Typvs-orbis-terrarvm-1024x874.png";s:5:"width";i:1024;s:6:"height";i:874;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1412560;}s:9:"thumbnail";a:5:{s:4:"file";s:32:"Typvs-orbis-terrarvm-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:46273;}s:12:"medium_large";a:5:{s:4:"file";s:32:"Typvs-orbis-terrarvm-768x656.png";s:5:"width";i:768;s:6:"height";i:656;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:850436;}s:9:"1536x1536";a:5:{s:4:"file";s:34:"Typvs-orbis-terrarvm-1536x1311.png";s:5:"width";i:1536;s:6:"height";i:1311;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2805233;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:32:"Typvs-orbis-terrarvm-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:173744;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:32:"Typvs-orbis-terrarvm-600x512.png";s:5:"width";i:600;s:6:"height";i:512;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:544227;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:32:"Typvs-orbis-terrarvm-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:21113;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(327, 110, '_wp_attached_file', '2024/03/under-the-dock-scaled.jpg'),
(328, 110, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:33:"2024/03/under-the-dock-scaled.jpg";s:8:"filesize";i:673542;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:26:"under-the-dock-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10764;}s:5:"large";a:5:{s:4:"file";s:27:"under-the-dock-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:80673;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"under-the-dock-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4981;}s:12:"medium_large";a:5:{s:4:"file";s:26:"under-the-dock-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:45274;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"under-the-dock-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:199656;}s:9:"2048x2048";a:5:{s:4:"file";s:28:"under-the-dock-2048x1366.jpg";s:5:"width";i:2048;s:6:"height";i:1366;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:401526;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:26:"under-the-dock-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13926;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:26:"under-the-dock-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:29618;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:26:"under-the-dock-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2932;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:18:"under-the-dock.jpg";}'),
(329, 111, '_wp_attached_file', '2024/03/audiencehands.png'),
(330, 111, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:979;s:6:"height";i:565;s:4:"file";s:25:"2024/03/audiencehands.png";s:8:"filesize";i:255634;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:25:"audiencehands-300x173.png";s:5:"width";i:300;s:6:"height";i:173;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:42916;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"audiencehands-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:19388;}s:12:"medium_large";a:5:{s:4:"file";s:25:"audiencehands-768x443.png";s:5:"width";i:768;s:6:"height";i:443;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:166237;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:25:"audiencehands-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:53167;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:25:"audiencehands-600x346.png";s:5:"width";i:600;s:6:"height";i:346;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:118018;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:25:"audiencehands-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:10342;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(331, 112, '_wp_attached_file', '2024/03/greek-theatre-scaled.jpg'),
(332, 112, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:32:"2024/03/greek-theatre-scaled.jpg";s:8:"filesize";i:910396;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:25:"greek-theatre-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18579;}s:5:"large";a:5:{s:4:"file";s:26:"greek-theatre-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:183104;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"greek-theatre-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7521;}s:12:"medium_large";a:5:{s:4:"file";s:25:"greek-theatre-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:107140;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"greek-theatre-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:378226;}s:9:"2048x2048";a:5:{s:4:"file";s:27:"greek-theatre-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:625223;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:25:"greek-theatre-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:26364;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:25:"greek-theatre-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:67635;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:25:"greek-theatre-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3873;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:17:"greek-theatre.jpg";}'),
(333, 113, '_wp_attached_file', '2024/03/wp-migrate-db-pro.zip'),
(334, 113, '_wp_attachment_context', 'upgrader') ;
INSERT INTO `tu_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(335, 114, '_wp_attached_file', '2024/03/wp-migrate-db-pro-2.6.12.zip'),
(336, 114, '_wp_attachment_context', 'upgrader') ;

#
# End of data contents of table `tu_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `tu_posts`
#

DROP TABLE IF EXISTS `tu_posts`;


#
# Table structure of table `tu_posts`
#

CREATE TABLE `tu_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_posts`
#
INSERT INTO `tu_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2024-03-25 05:27:36', '2024-03-25 05:27:36', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2024-03-25 05:27:36', '2024-03-25 05:27:36', '', 0, 'https://theatrum.ssl/?p=1', 0, 'post', '', 1),
(2, 1, '2024-03-25 05:27:36', '2024-03-25 05:27:36', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="https://theatrum.ssl/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2024-03-25 05:33:59', '2024-03-25 05:33:59', '', 0, 'https://theatrum.ssl/?page_id=2', 0, 'page', '', 0),
(3, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: https://theatrum.ssl.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2024-03-25 18:48:41', '2024-03-25 18:48:41', '', 0, 'https://theatrum.ssl/?page_id=3', 10, 'page', '', 0),
(4, 1, '2024-03-25 05:28:10', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2024-03-25 05:28:10', '0000-00-00 00:00:00', '', 0, 'https://theatrum.ssl/?p=4', 0, 'post', '', 0),
(5, 1, '2024-03-25 05:33:59', '2024-03-25 05:33:59', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="https://theatrum.ssl/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2024-03-25 05:33:59', '2024-03-25 05:33:59', '', 2, 'https://theatrum.ssl/?p=5', 0, 'revision', '', 0),
(6, 1, '2024-03-25 05:34:08', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2024-03-25 05:34:08', '0000-00-00 00:00:00', '', 0, 'https://theatrum.ssl/?page_id=6', 0, 'page', '', 0),
(7, 1, '2024-03-25 05:34:08', '2024-03-25 05:34:08', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-twentytwentyfour', '', '', '2024-03-25 05:34:08', '2024-03-25 05:34:08', '', 0, 'https://theatrum.ssl/blog/2024/03/25/wp-global-styles-twentytwentyfour/', 0, 'wp_global_styles', '', 0),
(8, 1, '2024-03-25 05:34:09', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2024-03-25 05:34:09', '0000-00-00 00:00:00', '', 0, 'https://theatrum.ssl/?page_id=8', 0, 'page', '', 0),
(9, 1, '2024-03-25 05:34:10', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2024-03-25 05:34:10', '0000-00-00 00:00:00', '', 0, 'https://theatrum.ssl/?page_id=9', 0, 'page', '', 0),
(10, 1, '2024-03-25 05:34:10', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2024-03-25 05:34:10', '0000-00-00 00:00:00', '', 0, 'https://theatrum.ssl/?page_id=10', 0, 'page', '', 0),
(11, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '<!-- wp:heading -->\n<h2 class="wp-block-heading">All the world’s a stage…</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">…including your website</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Theatre and Web Design</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>A website is a stage to present a brand\'s aesthetics, personality, and values as part of the overall experience--but, it goes even deeper than what you see "onstage." The mechanics operating backstage can offer pragmatic solutions to every day business problems.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>About | Portfolio | Services | Contact | Blog</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons -->\n<div class="wp-block-buttons"><!-- wp:button -->\n<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">About</a></div>\n<!-- /wp:button -->\n\n<!-- wp:button -->\n<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Services</a></div>\n<!-- /wp:button -->\n\n<!-- wp:button -->\n<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Portfolio</a></div>\n<!-- /wp:button -->\n\n<!-- wp:button -->\n<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Contact</a></div>\n<!-- /wp:button -->\n\n<!-- wp:button -->\n<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Blog</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons -->\n\n<!-- wp:paragraph -->\n<p>Theatrum Mundi\'s approach to web design is an artistic process of holistic creative problem solving.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Subjective experience of your brand drives the front-facing visual design, while your objective business goals inform the behind the scenes structure and functionality.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Who\'s afraid of WordPress?</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Open-source, community-based.</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>WordPress combines simplicity for users and publishers with under-the-hood complexity for developers. Discover the features that come standard with WordPress, and extend what the platform can do with the thousands of plugins available.</p>\n<!-- /wp:paragraph -->', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2024-03-25 18:47:08', '2024-03-25 18:47:08', '', 0, 'https://theatrum.ssl/?page_id=11', 0, 'page', '', 0),
(12, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '<!-- wp:heading -->\n<h2 class="wp-block-heading">Mission</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Apply Dramaturgical practice to holistic web design</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Empower creative entrepreneurs with bespoke website that tells a story and solves problems.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Vision</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Balance form and function in the contemporary website.</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>We envision a website as an artistic object, living/breathing, and functional tool.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Values</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Curiosity</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Empathy</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Innovation</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Creativity</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Empiricism</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Data-driven</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Heuristic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Research-backed</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Informed</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Universality</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Comprehensive</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>All-inclusive</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>User-/human-centric design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Holistic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Flexibility</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Collaboration</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Open source</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Community-driven</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Communication</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Artisanship</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Elegant</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Sophisticated</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>High-quality</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Detail-oriented</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Durability</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Aesthetic</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">High-contrast</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Black &amp; White</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Film noir</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Bold</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Kinetic</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Animations</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Movement</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Responsive design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Dynamic</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Remix</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Retro</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Classic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Adaptation</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Abstract</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>evocative</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>innovative</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>impressionistic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Form</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Line</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Color to evoke emotional response</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Saturation</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Dense</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Immersive</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Colorful</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2024-03-25 18:47:49', '2024-03-25 18:47:49', '', 0, 'https://theatrum.ssl/?page_id=12', 1, 'page', '', 0),
(13, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Design</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Visual</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Typography, Color Palette, Animation, &amp; Design Systems</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Brand</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Experience</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Interface</h3>\n<!-- /wp:heading -->\n\n<!-- wp:separator -->\n<hr class="wp-block-separator has-alpha-channel-opacity"/>\n<!-- /wp:separator --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Development</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">WordPress</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>PHP, SQL</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Frontend</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>HTML, CSS, JavaScript</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Custom Functionality</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Integration</h3>\n<!-- /wp:heading -->\n\n<!-- wp:separator -->\n<hr class="wp-block-separator has-alpha-channel-opacity"/>\n<!-- /wp:separator --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Management</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Web hosting</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Technical support</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Maintenance</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Updates</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Backups</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Blog content creation</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:separator -->\n<hr class="wp-block-separator has-alpha-channel-opacity"/>\n<!-- /wp:separator --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Content</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Curation and generation of words and media that will tell your story.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Copywriting</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Photography</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Headshots, product photos, location photos, etc.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Blog</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Use a blog to tell more about your story or concept while driving traffic to your site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Curation</h3>\n<!-- /wp:heading -->\n\n<!-- wp:separator -->\n<hr class="wp-block-separator has-alpha-channel-opacity"/>\n<!-- /wp:separator --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">All sites include</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>domain &amp; email</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>customizable style guide</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>basic SEO &amp; security features, ready for further optimization</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>owner dashboard</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>ADA compliance &lt;/aside&gt;</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:separator -->\n<hr class="wp-block-separator has-alpha-channel-opacity"/>\n<!-- /wp:separator --></div>\n<!-- /wp:group -->', 'Services', '', 'publish', 'closed', 'closed', '', 'services', '', '', '2024-03-25 18:47:58', '2024-03-25 18:47:58', '', 0, 'https://theatrum.ssl/?page_id=13', 3, 'page', '', 0),
(14, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:paragraph -->\n<p>[Calendly]</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>[Contacts Form]</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:image {"id":26,"width":"246px","height":"auto","sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large is-resized"><img src="https://theatrum.ssl/wp-content/uploads/2024/03/placeholder-1024x683.png" alt="" class="wp-image-26" style="width:246px;height:auto"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading"><strong>Anna Jennings</strong></h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Founder &amp; Owner</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Anna is a director, dramaturg1, and producer and is obsessed with the mechanics and magic of live performance. Her primary artistic interests lie in spatial theory, immersive performance, and site-specific productions.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>She discovered the concept of&nbsp;<em>theatrum mundi</em>&nbsp;in her MFA research in theatrical use of city space in the Edinburgh Fringe Festival and the rhizomatic structure of arts festivals.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Anna also loves writing, puzzles, photography, and footnotes. You can check out her portfolio here:</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Footnotes</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list {"ordered":true} -->\n<ol><!-- wp:list-item -->\n<li>A dramaturg is a theatre artist who works with the playwright, director, designers, and actors in developing new or existing plays from the perspective of the audience. A dramaturg\'s least favorite thing is defining dramaturgy.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>In botany, a rhizome is an underground system of tangled roots that all connect to each other. In philosophy, rhizomatic theory allows for multiple, non-hierarchical entry and exit points in data representation and interpretation. It was set forth in the book&nbsp;<em>A Thousand Plateaus</em>&nbsp;by Félix&nbsp;Guattari and Gilles Louis René Deleuze.</li>\n<!-- /wp:list-item --></ol>\n<!-- /wp:list --></div>\n<!-- /wp:group -->', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2024-03-25 18:48:09', '2024-03-25 18:48:09', '', 0, 'https://theatrum.ssl/?page_id=14', 5, 'page', '', 0),
(15, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '<!-- wp:html /-->\n\n<!-- wp:query {"queryId":32,"query":{"perPage":3,"pages":0,"offset":"0","postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false},"layout":{"type":"constrained"}} -->\n<div class="wp-block-query"><!-- wp:query-no-results -->\n<!-- wp:paragraph -->\n<p>No posts were found.</p>\n<!-- /wp:paragraph -->\n<!-- /wp:query-no-results -->\n\n<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"default"}} -->\n<div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--50);padding-right:0;padding-bottom:var(--wp--preset--spacing--50);padding-left:0"><!-- wp:post-template {"align":"full","style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"default","columnCount":3}} -->\n<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"3/2","style":{"spacing":{"margin":{"bottom":"var:preset|spacing|20"}}}} /-->\n\n<!-- wp:group {"style":{"spacing":{"blockGap":"8px"}},"layout":{"type":"flex","orientation":"vertical","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:post-title {"isLink":true,"style":{"spacing":{"margin":{"bottom":"0"}}},"fontSize":"x-large"} /-->\n\n<!-- wp:template-part {"slug":"post-meta","theme":"twentytwentyfour"} /-->\n\n<!-- wp:post-excerpt {"fontSize":"small"} /-->\n\n<!-- wp:spacer {"height":"0px","style":{"layout":{"flexSize":"min(2.5rem, 3vw)","selfStretch":"fixed"}}} -->\n<div style="height:0px" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer --></div>\n<!-- /wp:group -->\n<!-- /wp:post-template -->\n\n<!-- wp:spacer {"height":"var:preset|spacing|50","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->\n<div style="margin-top:0;margin-bottom:0;height:var(--wp--preset--spacing--50)" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:query-pagination {"paginationArrow":"arrow","layout":{"type":"flex","justifyContent":"space-between"}} -->\n<!-- wp:query-pagination-previous /-->\n\n<!-- wp:query-pagination-next /-->\n<!-- /wp:query-pagination --></div>\n<!-- /wp:group --></div>\n<!-- /wp:query -->\n\n<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->\n<div class="wp-block-group alignfull" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"border":{"radius":"16px"}},"backgroundColor":"base-2","layout":{"type":"default"}} -->\n<div class="wp-block-group alignwide has-base-2-background-color has-background" style="border-radius:16px;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"align":"center"} -->\n<p class="has-text-align-center">We’ve worked with some of the best companies.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:spacer {"height":"var:preset|spacing|10"} -->\n<div style="height:var(--wp--preset--spacing--10)" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"var:preset|spacing|20","padding":{"right":"0","left":"0","top":"0","bottom":"0"}}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"center"}} -->\n<div class="wp-block-group alignwide" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"width":"150px","aspectRatio":"4/3","scale":"contain","linkDestination":"none"} -->\n<figure class="wp-block-image is-resized"><img alt="" style="aspect-ratio:4/3;object-fit:contain;width:150px"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {"width":"150px","aspectRatio":"4/3","scale":"contain","linkDestination":"none"} -->\n<figure class="wp-block-image is-resized"><img alt="" style="aspect-ratio:4/3;object-fit:contain;width:150px"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {"width":"150px","aspectRatio":"4/3","scale":"contain","linkDestination":"none"} -->\n<figure class="wp-block-image is-resized"><img alt="" style="aspect-ratio:4/3;object-fit:contain;width:150px"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->', 'Projects', '', 'publish', 'closed', 'closed', '', 'projects', '', '', '2024-03-25 18:48:05', '2024-03-25 18:48:05', '', 0, 'https://theatrum.ssl/?page_id=15', 4, 'page', '', 0),
(16, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '', 'Accessibility Statement', '', 'publish', 'closed', 'closed', '', 'accessibility-statement', '', '', '2024-03-25 18:48:18', '2024-03-25 18:48:18', '', 0, 'https://theatrum.ssl/?page_id=16', 11, 'page', '', 0),
(17, 1, '2024-03-25 17:23:06', '2024-03-25 17:23:06', '', 'Services', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2024-03-25 17:23:06', '2024-03-25 17:23:06', '', 13, 'https://theatrum.ssl/?p=17', 0, 'revision', '', 0),
(18, 1, '2024-03-25 17:23:08', '2024-03-25 17:23:08', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2024-03-25 17:23:08', '2024-03-25 17:23:08', '', 14, 'https://theatrum.ssl/?p=18', 0, 'revision', '', 0),
(19, 1, '2024-03-25 17:23:09', '2024-03-25 17:23:09', '', 'Projects', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2024-03-25 17:23:09', '2024-03-25 17:23:09', '', 15, 'https://theatrum.ssl/?p=19', 0, 'revision', '', 0),
(20, 1, '2024-03-25 17:23:11', '2024-03-25 17:23:11', '', 'Accessibility Statement', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2024-03-25 17:23:11', '2024-03-25 17:23:11', '', 16, 'https://theatrum.ssl/?p=20', 0, 'revision', '', 0),
(21, 1, '2024-03-25 17:24:35', '2024-03-25 17:24:35', '<!-- wp:navigation-link {"label":"Capability Statement","type":"page","id":72,"url":"https://theatrum.ssl/capability-statement/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Home","type":"page","id":11,"url":"https://theatrum.ssl/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"About","type":"page","id":12,"url":"https://theatrum.ssl/about/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Services","type":"page","id":13,"url":"https://theatrum.ssl/services/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Projects","type":"page","id":15,"url":"https://theatrum.ssl/projects/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Contact","type":"page","id":14,"url":"https://theatrum.ssl/contact/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Blog","type":"page","id":65,"url":"https://theatrum.ssl/blog/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Shop","type":"page","id":31,"url":"https://theatrum.ssl/shop/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Privacy Policy","type":"page","id":3,"url":"https://theatrum.ssl/privacy-policy/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Accessibility Statement","type":"page","id":16,"url":"https://theatrum.ssl/accessibility-statement/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Refund and Returns Policy","type":"page","id":35,"url":"https://theatrum.ssl/refund_returns/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Cart","type":"page","id":32,"url":"https://theatrum.ssl/cart/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Checkout","type":"page","id":33,"url":"https://theatrum.ssl/checkout/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"My account","type":"page","id":34,"url":"https://theatrum.ssl/my-account/","kind":"post-type"} /-->', 'Header Navigation', '', 'publish', 'closed', 'closed', '', 'navigation', '', '', '2024-03-25 20:01:05', '2024-03-25 20:01:05', '', 0, 'https://theatrum.ssl/blog/2024/03/25/navigation/', 0, 'wp_navigation', '', 0),
(22, 1, '2024-03-25 17:25:38', '2024-03-25 17:25:38', '<!-- wp:heading -->\n<h2 class="wp-block-heading">All the world’s a stage…</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">…including your website</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Theatre and Web Design</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>A website is a stage to present a brand\'s aesthetics, personality, and values as part of the overall experience--but, it goes even deeper than what you see "onstage." The mechanics operating backstage can offer pragmatic solutions to every day business problems.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>About | Portfolio | Services | Contact | Blog</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons -->\n<div class="wp-block-buttons"><!-- wp:button -->\n<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">About</a></div>\n<!-- /wp:button -->\n\n<!-- wp:button -->\n<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Services</a></div>\n<!-- /wp:button -->\n\n<!-- wp:button -->\n<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Portfolio</a></div>\n<!-- /wp:button -->\n\n<!-- wp:button -->\n<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Contact</a></div>\n<!-- /wp:button -->\n\n<!-- wp:button -->\n<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Blog</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons -->\n\n<!-- wp:paragraph -->\n<p>Theatrum Mundi\'s approach to web design is an artistic process of holistic creative problem solving.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Subjective experience of your brand drives the front-facing visual design, while your objective business goals inform the behind the scenes structure and functionality.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Who\'s afraid of WordPress?</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Open-source, community-based.</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>WordPress combines simplicity for users and publishers with under-the-hood complexity for developers. Discover the features that come standard with WordPress, and extend what the platform can do with the thousands of plugins available.</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2024-03-25 17:25:38', '2024-03-25 17:25:38', '', 11, 'https://theatrum.ssl/?p=22', 0, 'revision', '', 0),
(23, 1, '2024-03-25 17:28:02', '2024-03-25 17:28:02', '<!-- wp:heading -->\n<h2 class="wp-block-heading">Mission</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Apply Dramaturgical practice to holistic web design</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Empower creative entrepreneurs with bespoke website that tells a story and solves problems.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Vision</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Balance form and function in the contemporary website.</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>We envision a website as an artistic object, living/breathing, and functional tool.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Values</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Curiosity</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Empathy</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Innovation</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Creativity</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Empiricism</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Data-driven</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Heuristic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Research-backed</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Informed</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Universality</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Comprehensive</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>All-inclusive</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>User-/human-centric design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Holistic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Flexibility</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Collaboration</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Open source</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Community-driven</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Communication</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Artisanship</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Elegant</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Sophisticated</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>High-quality</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Detail-oriented</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Durability</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Aesthetic</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">High-contrast</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Black &amp; White</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Film noir</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Bold</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Kinetic</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Animations</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Movement</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Responsive design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Dynamic</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Remix</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Retro</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Classic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Adaptation</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Abstract</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>evocative</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>innovative</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>impressionistic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Form</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Line</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Color to evoke emotional response</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Saturation</h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Dense</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Immersive</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Colorful</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->', 'About', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2024-03-25 17:28:02', '2024-03-25 17:28:02', '', 12, 'https://theatrum.ssl/?p=23', 0, 'revision', '', 0),
(24, 1, '2024-03-25 17:30:39', '2024-03-25 17:30:39', '<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Design</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Visual</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Typography, Color Palette, Animation, &amp; Design Systems</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Brand</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Experience</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Interface</h3>\n<!-- /wp:heading --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Development</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">WordPress</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>PHP, SQL</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Frontend</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>HTML, CSS, JavaScript</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Custom Functionality</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Integration</h3>\n<!-- /wp:heading --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Management</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Web hosting</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Technical support</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Maintenance</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Updates</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Backups</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Blog content creation</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Content</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Curation and generation of words and media that will tell your story.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Copywriting</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Photography</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Headshots, product photos, location photos, etc.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Blog</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Use a blog to tell more about your story or concept while driving traffic to your site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Curation</h3>\n<!-- /wp:heading --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">All sites include</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>domain &amp; email</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>customizable style guide</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>basic SEO &amp; security features, ready for further optimization</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>owner dashboard</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>ADA compliance &lt;/aside&gt;</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->', 'Services', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2024-03-25 17:30:39', '2024-03-25 17:30:39', '', 13, 'https://theatrum.ssl/?p=24', 0, 'revision', '', 0) ;
INSERT INTO `tu_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(25, 1, '2024-03-25 17:34:49', '2024-03-25 17:34:49', '<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Design</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Visual</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Typography, Color Palette, Animation, &amp; Design Systems</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Brand</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Experience</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Interface</h3>\n<!-- /wp:heading -->\n\n<!-- wp:separator -->\n<hr class="wp-block-separator has-alpha-channel-opacity"/>\n<!-- /wp:separator --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Development</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">WordPress</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>PHP, SQL</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Frontend</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>HTML, CSS, JavaScript</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Custom Functionality</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Integration</h3>\n<!-- /wp:heading -->\n\n<!-- wp:separator -->\n<hr class="wp-block-separator has-alpha-channel-opacity"/>\n<!-- /wp:separator --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Management</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Web hosting</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Technical support</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Maintenance</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Updates</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Backups</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Blog content creation</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:separator -->\n<hr class="wp-block-separator has-alpha-channel-opacity"/>\n<!-- /wp:separator --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Content</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Curation and generation of words and media that will tell your story.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Copywriting</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Photography</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Headshots, product photos, location photos, etc.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Blog</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Use a blog to tell more about your story or concept while driving traffic to your site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Curation</h3>\n<!-- /wp:heading -->\n\n<!-- wp:separator -->\n<hr class="wp-block-separator has-alpha-channel-opacity"/>\n<!-- /wp:separator --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">All sites include</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>domain &amp; email</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>customizable style guide</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>basic SEO &amp; security features, ready for further optimization</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>owner dashboard</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>ADA compliance &lt;/aside&gt;</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:separator -->\n<hr class="wp-block-separator has-alpha-channel-opacity"/>\n<!-- /wp:separator --></div>\n<!-- /wp:group -->', 'Services', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2024-03-25 17:34:49', '2024-03-25 17:34:49', '', 13, 'https://theatrum.ssl/?p=25', 0, 'revision', '', 0),
(26, 1, '2024-03-25 17:36:28', '2024-03-25 17:36:28', '', 'placeholder', '', 'inherit', 'open', 'closed', '', 'placeholder', '', '', '2024-03-25 17:36:28', '2024-03-25 17:36:28', '', 14, 'https://theatrum.ssl/wp-content/uploads/2024/03/placeholder.png', 0, 'attachment', 'image/png', 0),
(27, 1, '2024-03-25 17:38:01', '2024-03-25 17:38:01', '<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:paragraph -->\n<p>[Calendly]</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>[Contacts Form]</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:image {"id":26,"width":"246px","height":"auto","sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large is-resized"><img src="https://theatrum.ssl/wp-content/uploads/2024/03/placeholder-1024x683.png" alt="" class="wp-image-26" style="width:246px;height:auto"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading"><strong>Anna Jennings</strong></h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Founder &amp; Owner</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Anna is a director, dramaturg1, and producer and is obsessed with the mechanics and magic of live performance. Her primary artistic interests lie in spatial theory, immersive performance, and site-specific productions.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>She discovered the concept of&nbsp;<em>theatrum mundi</em>&nbsp;in her MFA research in theatrical use of city space in the Edinburgh Fringe Festival and the rhizomatic structure of arts festivals.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Anna also loves writing, puzzles, photography, and footnotes. You can check out her portfolio here:</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Footnotes</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list {"ordered":true} -->\n<ol><!-- wp:list-item -->\n<li>A dramaturg is a theatre artist who works with the playwright, director, designers, and actors in developing new or existing plays from the perspective of the audience. A dramaturg\'s least favorite thing is defining dramaturgy.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>In botany, a rhizome is an underground system of tangled roots that all connect to each other. In philosophy, rhizomatic theory allows for multiple, non-hierarchical entry and exit points in data representation and interpretation. It was set forth in the book&nbsp;<em>A Thousand Plateaus</em>&nbsp;by Félix&nbsp;Guattari and Gilles Louis René Deleuze.</li>\n<!-- /wp:list-item --></ol>\n<!-- /wp:list --></div>\n<!-- /wp:group -->', 'Contact', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2024-03-25 17:38:01', '2024-03-25 17:38:01', '', 14, 'https://theatrum.ssl/?p=27', 0, 'revision', '', 0),
(28, 1, '2024-03-25 17:40:17', '2024-03-25 17:40:17', '<!-- wp:html /-->\n\n<!-- wp:page-list /-->\n\n<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->\n<div class="wp-block-group alignfull" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"border":{"radius":"16px"}},"backgroundColor":"base-2","layout":{"type":"default"}} -->\n<div class="wp-block-group alignwide has-base-2-background-color has-background" style="border-radius:16px;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"align":"center"} -->\n<p class="has-text-align-center">We’ve worked with some of the best companies.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:spacer {"height":"var:preset|spacing|10"} -->\n<div style="height:var(--wp--preset--spacing--10)" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"var:preset|spacing|20","padding":{"right":"0","left":"0","top":"0","bottom":"0"}}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"center"}} -->\n<div class="wp-block-group alignwide" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"width":"150px","aspectRatio":"4/3","scale":"contain","linkDestination":"none"} -->\n<figure class="wp-block-image is-resized"><img alt="" style="aspect-ratio:4/3;object-fit:contain;width:150px"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {"width":"150px","aspectRatio":"4/3","scale":"contain","linkDestination":"none"} -->\n<figure class="wp-block-image is-resized"><img alt="" style="aspect-ratio:4/3;object-fit:contain;width:150px"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {"width":"150px","aspectRatio":"4/3","scale":"contain","linkDestination":"none"} -->\n<figure class="wp-block-image is-resized"><img alt="" style="aspect-ratio:4/3;object-fit:contain;width:150px"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->', 'Projects', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2024-03-25 17:40:17', '2024-03-25 17:40:17', '', 15, 'https://theatrum.ssl/?p=28', 0, 'revision', '', 0),
(29, 1, '2024-03-25 17:48:26', '2024-03-25 17:48:26', '<!-- wp:html /-->\n\n<!-- wp:query {"queryId":32,"query":{"perPage":3,"pages":0,"offset":"0","postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false},"layout":{"type":"constrained"}} -->\n<div class="wp-block-query"><!-- wp:query-no-results -->\n<!-- wp:paragraph -->\n<p>No posts were found.</p>\n<!-- /wp:paragraph -->\n<!-- /wp:query-no-results -->\n\n<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"default"}} -->\n<div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--50);padding-right:0;padding-bottom:var(--wp--preset--spacing--50);padding-left:0"><!-- wp:post-template {"align":"full","style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"default","columnCount":3}} -->\n<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"3/2","style":{"spacing":{"margin":{"bottom":"var:preset|spacing|20"}}}} /-->\n\n<!-- wp:group {"style":{"spacing":{"blockGap":"8px"}},"layout":{"type":"flex","orientation":"vertical","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:post-title {"isLink":true,"style":{"spacing":{"margin":{"bottom":"0"}}},"fontSize":"x-large"} /-->\n\n<!-- wp:template-part {"slug":"post-meta","theme":"twentytwentyfour"} /-->\n\n<!-- wp:post-excerpt {"fontSize":"small"} /-->\n\n<!-- wp:spacer {"height":"0px","style":{"layout":{"flexSize":"min(2.5rem, 3vw)","selfStretch":"fixed"}}} -->\n<div style="height:0px" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer --></div>\n<!-- /wp:group -->\n<!-- /wp:post-template -->\n\n<!-- wp:spacer {"height":"var:preset|spacing|50","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->\n<div style="margin-top:0;margin-bottom:0;height:var(--wp--preset--spacing--50)" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:query-pagination {"paginationArrow":"arrow","layout":{"type":"flex","justifyContent":"space-between"}} -->\n<!-- wp:query-pagination-previous /-->\n\n<!-- wp:query-pagination-next /-->\n<!-- /wp:query-pagination --></div>\n<!-- /wp:group --></div>\n<!-- /wp:query -->\n\n<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->\n<div class="wp-block-group alignfull" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"border":{"radius":"16px"}},"backgroundColor":"base-2","layout":{"type":"default"}} -->\n<div class="wp-block-group alignwide has-base-2-background-color has-background" style="border-radius:16px;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:paragraph {"align":"center"} -->\n<p class="has-text-align-center">We’ve worked with some of the best companies.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:spacer {"height":"var:preset|spacing|10"} -->\n<div style="height:var(--wp--preset--spacing--10)" aria-hidden="true" class="wp-block-spacer"></div>\n<!-- /wp:spacer -->\n\n<!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"var:preset|spacing|20","padding":{"right":"0","left":"0","top":"0","bottom":"0"}}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"center"}} -->\n<div class="wp-block-group alignwide" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"width":"150px","aspectRatio":"4/3","scale":"contain","linkDestination":"none"} -->\n<figure class="wp-block-image is-resized"><img alt="" style="aspect-ratio:4/3;object-fit:contain;width:150px"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {"width":"150px","aspectRatio":"4/3","scale":"contain","linkDestination":"none"} -->\n<figure class="wp-block-image is-resized"><img alt="" style="aspect-ratio:4/3;object-fit:contain;width:150px"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {"width":"150px","aspectRatio":"4/3","scale":"contain","linkDestination":"none"} -->\n<figure class="wp-block-image is-resized"><img alt="" style="aspect-ratio:4/3;object-fit:contain;width:150px"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->', 'Projects', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2024-03-25 17:48:26', '2024-03-25 17:48:26', '', 15, 'https://theatrum.ssl/?p=29', 0, 'revision', '', 0),
(30, 1, '2024-03-25 18:06:18', '2024-03-25 18:06:18', '', 'woocommerce-placeholder', '', 'inherit', 'open', 'closed', '', 'woocommerce-placeholder', '', '', '2024-03-25 18:06:18', '2024-03-25 18:06:18', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/woocommerce-placeholder.png', 0, 'attachment', 'image/png', 0),
(31, 1, '2024-03-25 18:06:19', '2024-03-25 18:06:19', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2024-03-25 18:49:10', '2024-03-25 18:49:10', '', 0, 'https://theatrum.ssl/shop/', 8, 'page', '', 0),
(32, 1, '2024-03-25 18:06:19', '2024-03-25 18:06:19', '<!-- wp:woocommerce/cart -->\n<div class="wp-block-woocommerce-cart alignwide is-loading"><!-- wp:woocommerce/filled-cart-block -->\n<div class="wp-block-woocommerce-filled-cart-block"><!-- wp:woocommerce/cart-items-block -->\n<div class="wp-block-woocommerce-cart-items-block"><!-- wp:woocommerce/cart-line-items-block -->\n<div class="wp-block-woocommerce-cart-line-items-block"></div>\n<!-- /wp:woocommerce/cart-line-items-block -->\n\n<!-- wp:woocommerce/cart-cross-sells-block -->\n<div class="wp-block-woocommerce-cart-cross-sells-block"><!-- wp:heading {"fontSize":"large"} -->\n<h2 class="wp-block-heading has-large-font-size">You may be interested in…</h2>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/cart-cross-sells-products-block -->\n<div class="wp-block-woocommerce-cart-cross-sells-products-block"></div>\n<!-- /wp:woocommerce/cart-cross-sells-products-block --></div>\n<!-- /wp:woocommerce/cart-cross-sells-block --></div>\n<!-- /wp:woocommerce/cart-items-block -->\n\n<!-- wp:woocommerce/cart-totals-block -->\n<div class="wp-block-woocommerce-cart-totals-block"><!-- wp:woocommerce/cart-order-summary-block -->\n<div class="wp-block-woocommerce-cart-order-summary-block"><!-- wp:woocommerce/cart-order-summary-heading-block -->\n<div class="wp-block-woocommerce-cart-order-summary-heading-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-heading-block -->\n\n<!-- wp:woocommerce/cart-order-summary-coupon-form-block -->\n<div class="wp-block-woocommerce-cart-order-summary-coupon-form-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-coupon-form-block -->\n\n<!-- wp:woocommerce/cart-order-summary-subtotal-block -->\n<div class="wp-block-woocommerce-cart-order-summary-subtotal-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-subtotal-block -->\n\n<!-- wp:woocommerce/cart-order-summary-fee-block -->\n<div class="wp-block-woocommerce-cart-order-summary-fee-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-fee-block -->\n\n<!-- wp:woocommerce/cart-order-summary-discount-block -->\n<div class="wp-block-woocommerce-cart-order-summary-discount-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-discount-block -->\n\n<!-- wp:woocommerce/cart-order-summary-shipping-block -->\n<div class="wp-block-woocommerce-cart-order-summary-shipping-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-shipping-block -->\n\n<!-- wp:woocommerce/cart-order-summary-taxes-block -->\n<div class="wp-block-woocommerce-cart-order-summary-taxes-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-taxes-block --></div>\n<!-- /wp:woocommerce/cart-order-summary-block -->\n\n<!-- wp:woocommerce/cart-express-payment-block -->\n<div class="wp-block-woocommerce-cart-express-payment-block"></div>\n<!-- /wp:woocommerce/cart-express-payment-block -->\n\n<!-- wp:woocommerce/proceed-to-checkout-block -->\n<div class="wp-block-woocommerce-proceed-to-checkout-block"></div>\n<!-- /wp:woocommerce/proceed-to-checkout-block -->\n\n<!-- wp:woocommerce/cart-accepted-payment-methods-block -->\n<div class="wp-block-woocommerce-cart-accepted-payment-methods-block"></div>\n<!-- /wp:woocommerce/cart-accepted-payment-methods-block --></div>\n<!-- /wp:woocommerce/cart-totals-block --></div>\n<!-- /wp:woocommerce/filled-cart-block -->\n\n<!-- wp:woocommerce/empty-cart-block -->\n<div class="wp-block-woocommerce-empty-cart-block"><!-- wp:heading {"textAlign":"center","className":"with-empty-cart-icon wc-block-cart__empty-cart__title"} -->\n<h2 class="wp-block-heading has-text-align-center with-empty-cart-icon wc-block-cart__empty-cart__title">Your cart is currently empty!</h2>\n<!-- /wp:heading -->\n\n<!-- wp:separator {"className":"is-style-dots"} -->\n<hr class="wp-block-separator has-alpha-channel-opacity is-style-dots"/>\n<!-- /wp:separator -->\n\n<!-- wp:heading {"textAlign":"center"} -->\n<h2 class="wp-block-heading has-text-align-center">New in store</h2>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/product-new {"columns":4,"rows":1} /--></div>\n<!-- /wp:woocommerce/empty-cart-block --></div>\n<!-- /wp:woocommerce/cart -->', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2024-03-25 18:48:27', '2024-03-25 18:48:27', '', 0, 'https://theatrum.ssl/cart/', 20, 'page', '', 0),
(33, 1, '2024-03-25 18:06:19', '2024-03-25 18:06:19', '<!-- wp:woocommerce/checkout -->\n<div class="wp-block-woocommerce-checkout alignwide wc-block-checkout is-loading"><!-- wp:woocommerce/checkout-fields-block -->\n<div class="wp-block-woocommerce-checkout-fields-block"><!-- wp:woocommerce/checkout-express-payment-block -->\n<div class="wp-block-woocommerce-checkout-express-payment-block"></div>\n<!-- /wp:woocommerce/checkout-express-payment-block -->\n\n<!-- wp:woocommerce/checkout-contact-information-block -->\n<div class="wp-block-woocommerce-checkout-contact-information-block"></div>\n<!-- /wp:woocommerce/checkout-contact-information-block -->\n\n<!-- wp:woocommerce/checkout-shipping-method-block -->\n<div class="wp-block-woocommerce-checkout-shipping-method-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-method-block -->\n\n<!-- wp:woocommerce/checkout-pickup-options-block -->\n<div class="wp-block-woocommerce-checkout-pickup-options-block"></div>\n<!-- /wp:woocommerce/checkout-pickup-options-block -->\n\n<!-- wp:woocommerce/checkout-shipping-address-block -->\n<div class="wp-block-woocommerce-checkout-shipping-address-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-address-block -->\n\n<!-- wp:woocommerce/checkout-billing-address-block -->\n<div class="wp-block-woocommerce-checkout-billing-address-block"></div>\n<!-- /wp:woocommerce/checkout-billing-address-block -->\n\n<!-- wp:woocommerce/checkout-shipping-methods-block -->\n<div class="wp-block-woocommerce-checkout-shipping-methods-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-methods-block -->\n\n<!-- wp:woocommerce/checkout-payment-block -->\n<div class="wp-block-woocommerce-checkout-payment-block"></div>\n<!-- /wp:woocommerce/checkout-payment-block -->\n\n<!-- wp:woocommerce/checkout-additional-information-block -->\n<div class="wp-block-woocommerce-checkout-additional-information-block"></div>\n<!-- /wp:woocommerce/checkout-additional-information-block -->\n\n<!-- wp:woocommerce/checkout-order-note-block -->\n<div class="wp-block-woocommerce-checkout-order-note-block"></div>\n<!-- /wp:woocommerce/checkout-order-note-block -->\n\n<!-- wp:woocommerce/checkout-terms-block -->\n<div class="wp-block-woocommerce-checkout-terms-block"></div>\n<!-- /wp:woocommerce/checkout-terms-block -->\n\n<!-- wp:woocommerce/checkout-actions-block -->\n<div class="wp-block-woocommerce-checkout-actions-block"></div>\n<!-- /wp:woocommerce/checkout-actions-block --></div>\n<!-- /wp:woocommerce/checkout-fields-block -->\n\n<!-- wp:woocommerce/checkout-totals-block -->\n<div class="wp-block-woocommerce-checkout-totals-block"><!-- wp:woocommerce/checkout-order-summary-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-block"><!-- wp:woocommerce/checkout-order-summary-cart-items-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-cart-items-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-cart-items-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-coupon-form-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-coupon-form-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-coupon-form-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-subtotal-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-subtotal-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-subtotal-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-fee-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-fee-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-fee-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-discount-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-discount-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-discount-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-shipping-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-shipping-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-shipping-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-taxes-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-taxes-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-taxes-block --></div>\n<!-- /wp:woocommerce/checkout-order-summary-block --></div>\n<!-- /wp:woocommerce/checkout-totals-block --></div>\n<!-- /wp:woocommerce/checkout -->', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2024-03-25 18:48:32', '2024-03-25 18:48:32', '', 0, 'https://theatrum.ssl/checkout/', 21, 'page', '', 0),
(34, 1, '2024-03-25 18:06:19', '2024-03-25 18:06:19', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2024-03-25 18:48:36', '2024-03-25 18:48:36', '', 0, 'https://theatrum.ssl/my-account/', 22, 'page', '', 0),
(35, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '<!-- wp:paragraph -->\n<p><b>This is a sample page.</b></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h3>Overview</h3>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Several types of goods are exempt from being returned. Perishable goods such as food, flowers, newspapers or magazines cannot be returned. We also do not accept products that are intimate or sanitary goods, hazardous materials, or flammable liquids or gases.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Additional non-returnable items:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Gift cards</li>\n<li>Downloadable software products</li>\n<li>Some health and personal care items</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>To complete your return, we require a receipt or proof of purchase.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Please do not send your purchase back to the manufacturer.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>There are certain situations where only partial refunds are granted:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Book with obvious signs of use</li>\n<li>CD, DVD, VHS tape, software, video game, cassette tape, or vinyl record that has been opened.</li>\n<li>Any item not in its original condition, is damaged or missing parts for reasons not due to our error.</li>\n<li>Any item that is returned more than 30 days after delivery</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<h2>Refunds</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Late or missing refunds</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you haven’t received a refund yet, first check your bank account again.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Then contact your credit card company, it may take some time before your refund is officially posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Next contact your bank. There is often some processing time before a refund is posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you’ve done all of this and you still have not received your refund yet, please contact us at {email address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Sale items</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Only regular priced items may be refunded. Sale items cannot be refunded.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Exchanges</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at {email address} and send your item to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Gifts</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item was marked as a gift when purchased and shipped directly to you, you’ll receive a gift credit for the value of your return. Once the returned item is received, a gift certificate will be mailed to you.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item wasn’t marked as a gift when purchased, or the gift giver had the order shipped to themselves to give to you later, we will send a refund to the gift giver and they will find out about your return.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Shipping returns</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To return your product, you should mail your product to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Depending on where you live, the time it may take for your exchanged product to reach you may vary.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are returning more expensive items, you may consider using a trackable shipping service or purchasing shipping insurance. We don’t guarantee that we will receive your returned item.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Need help?</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Contact us at {email} for questions related to refunds and returns.</p>\n<!-- /wp:paragraph -->', 'Refund and Returns Policy', '', 'publish', 'closed', 'closed', '', 'refund_returns', '', '', '2024-03-25 18:48:57', '2024-03-25 18:48:57', '', 0, 'https://theatrum.ssl/?page_id=35', 12, 'page', '', 0),
(36, 1, '2024-03-25 18:07:02', '2024-03-25 18:07:02', '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"20px","bottom":"20px"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->\n<div class="wp-block-group alignwide has-base-background-color has-background"\n	style="padding-top:20px;padding-bottom:20px">\n	<!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->\n	<div class="wp-block-group alignwide">\n		<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex"}} -->\n		<div class="wp-block-group">\n			<!-- wp:site-logo {"width":60} /-->\n\n			<!-- wp:group {"style":{"spacing":{"blockGap":"0px"}}} -->\n			<div class="wp-block-group">\n				<!-- wp:site-title {"level":0} /-->\n			</div>\n			<!-- /wp:group -->\n		</div>\n		<!-- /wp:group -->\n\n		<!-- wp:navigation {"layout":{"type":"flex","justifyContent":"right","orientation":"horizontal"},"style":{"spacing":{"margin":{"top":"0"},"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}}} /--><!-- wp:woocommerce/mini-cart /-->\n	</div>\n	<!-- /wp:group -->\n</div>\n<!-- /wp:group -->\n			<!-- wp:group {"layout":{"inherit":true,"type":"constrained"}} -->\n				<div class="wp-block-group"><!-- wp:woocommerce/page-content-wrapper {"page":"cart"} -->\n				<!-- wp:post-title {"align":"wide", "level":1} /-->\n				<!-- wp:post-content {"align":"wide"} /-->\n				<!-- /wp:woocommerce/page-content-wrapper --></div>\n			<!-- /wp:group -->\n		<!-- wp:pattern {"slug":"twentytwentyfour/footer"} /-->\n', '', '', 'publish', 'closed', 'closed', '', 'page-cart', '', '', '2024-03-25 18:07:02', '2024-03-25 18:07:02', '', 0, 'https://theatrum.ssl/blog/2024/03/25/page-cart/', 0, 'wp_template', '', 0),
(37, 1, '2024-03-25 18:07:02', '2024-03-25 18:07:02', '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"20px","bottom":"20px"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->\n<div class="wp-block-group alignwide has-base-background-color has-background"\n	style="padding-top:20px;padding-bottom:20px">\n	<!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->\n	<div class="wp-block-group alignwide">\n		<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex"}} -->\n		<div class="wp-block-group">\n			<!-- wp:site-logo {"width":60} /-->\n\n			<!-- wp:group {"style":{"spacing":{"blockGap":"0px"}}} -->\n			<div class="wp-block-group">\n				<!-- wp:site-title {"level":0} /-->\n			</div>\n			<!-- /wp:group -->\n		</div>\n		<!-- /wp:group -->\n\n		<!-- wp:navigation {"layout":{"type":"flex","justifyContent":"right","orientation":"horizontal"},"style":{"spacing":{"margin":{"top":"0"},"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}}} /--><!-- wp:woocommerce/mini-cart /-->\n	</div>\n	<!-- /wp:group -->\n</div>\n<!-- /wp:group -->\n			<!-- wp:group {"layout":{"inherit":true,"type":"constrained"}} -->\n				<div class="wp-block-group"><!-- wp:woocommerce/page-content-wrapper {"page":"cart"} -->\n				<!-- wp:post-title {"align":"wide", "level":1} /-->\n				<!-- wp:post-content {"align":"wide"} /-->\n				<!-- /wp:woocommerce/page-content-wrapper --></div>\n			<!-- /wp:group -->\n		<!-- wp:pattern {"slug":"twentytwentyfour/footer"} /-->\n', '', '', 'publish', 'closed', 'closed', '', 'page-cart', '', '', '2024-03-25 18:07:02', '2024-03-25 18:07:02', '', 0, 'https://theatrum.ssl/blog/2024/03/25/page-cart/', 0, 'wp_template', '', 0),
(38, 1, '2024-03-25 18:07:02', '2024-03-25 18:07:02', '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"20px","bottom":"20px"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->\n<div class="wp-block-group alignwide has-base-background-color has-background"\n	style="padding-top:20px;padding-bottom:20px">\n	<!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->\n	<div class="wp-block-group alignwide">\n		<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex"}} -->\n		<div class="wp-block-group">\n			<!-- wp:site-logo {"width":60} /-->\n\n			<!-- wp:group {"style":{"spacing":{"blockGap":"0px"}}} -->\n			<div class="wp-block-group">\n				<!-- wp:site-title {"level":0} /-->\n			</div>\n			<!-- /wp:group -->\n		</div>\n		<!-- /wp:group -->\n\n		<!-- wp:navigation {"layout":{"type":"flex","justifyContent":"right","orientation":"horizontal"},"style":{"spacing":{"margin":{"top":"0"},"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}}} /--><!-- wp:woocommerce/mini-cart /-->\n	</div>\n	<!-- /wp:group -->\n</div>\n<!-- /wp:group -->\n			<!-- wp:group {"layout":{"inherit":true,"type":"constrained"}} -->\n				<div class="wp-block-group"><!-- wp:woocommerce/page-content-wrapper {"page":"checkout"} -->\n				<!-- wp:post-title {"align":"wide", "level":1} /-->\n				<!-- wp:post-content {"align":"wide"} /-->\n				<!-- /wp:woocommerce/page-content-wrapper --></div>\n			<!-- /wp:group -->\n		<!-- wp:pattern {"slug":"twentytwentyfour/footer"} /-->\n', '', '', 'publish', 'closed', 'closed', '', 'page-checkout', '', '', '2024-03-25 18:07:02', '2024-03-25 18:07:02', '', 0, 'https://theatrum.ssl/blog/2024/03/25/page-checkout/', 0, 'wp_template', '', 0),
(39, 1, '2024-03-25 18:07:02', '2024-03-25 18:07:02', '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"20px","bottom":"20px"}}},"backgroundColor":"base","layout":{"type":"constrained"}} -->\n<div class="wp-block-group alignwide has-base-background-color has-background"\n	style="padding-top:20px;padding-bottom:20px">\n	<!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->\n	<div class="wp-block-group alignwide">\n		<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex"}} -->\n		<div class="wp-block-group">\n			<!-- wp:site-logo {"width":60} /-->\n\n			<!-- wp:group {"style":{"spacing":{"blockGap":"0px"}}} -->\n			<div class="wp-block-group">\n				<!-- wp:site-title {"level":0} /-->\n			</div>\n			<!-- /wp:group -->\n		</div>\n		<!-- /wp:group -->\n\n		<!-- wp:navigation {"layout":{"type":"flex","justifyContent":"right","orientation":"horizontal"},"style":{"spacing":{"margin":{"top":"0"},"blockGap":"var:preset|spacing|20"},"layout":{"selfStretch":"fit","flexSize":null}}} /--><!-- wp:woocommerce/mini-cart /-->\n	</div>\n	<!-- /wp:group -->\n</div>\n<!-- /wp:group -->\n			<!-- wp:group {"layout":{"inherit":true,"type":"constrained"}} -->\n				<div class="wp-block-group"><!-- wp:woocommerce/page-content-wrapper {"page":"checkout"} -->\n				<!-- wp:post-title {"align":"wide", "level":1} /-->\n				<!-- wp:post-content {"align":"wide"} /-->\n				<!-- /wp:woocommerce/page-content-wrapper --></div>\n			<!-- /wp:group -->\n		<!-- wp:pattern {"slug":"twentytwentyfour/footer"} /-->\n', '', '', 'publish', 'closed', 'closed', '', 'page-checkout', '', '', '2024-03-25 18:07:02', '2024-03-25 18:07:02', '', 0, 'https://theatrum.ssl/blog/2024/03/25/page-checkout/', 0, 'wp_template', '', 0),
(40, 1, '2024-03-25 18:27:07', '2024-03-25 18:27:07', 'a:35:{s:9:"post_type";s:7:"project";s:22:"advanced_configuration";b:1;s:13:"import_source";s:0:"";s:11:"import_date";s:0:"";s:6:"labels";a:33:{s:4:"name";s:8:"Projects";s:13:"singular_name";s:7:"Project";s:9:"menu_name";s:8:"Projects";s:9:"all_items";s:12:"All Projects";s:9:"edit_item";s:12:"Edit Project";s:9:"view_item";s:12:"View Project";s:10:"view_items";s:13:"View Projects";s:12:"add_new_item";s:15:"Add New Project";s:7:"add_new";s:15:"Add New Project";s:8:"new_item";s:11:"New Project";s:17:"parent_item_colon";s:15:"Parent Project:";s:12:"search_items";s:15:"Search Projects";s:9:"not_found";s:17:"No projects found";s:18:"not_found_in_trash";s:26:"No projects found in Trash";s:8:"archives";s:16:"Project Archives";s:10:"attributes";s:18:"Project Attributes";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:16:"insert_into_item";s:19:"Insert into project";s:21:"uploaded_to_this_item";s:24:"Uploaded to this project";s:17:"filter_items_list";s:20:"Filter projects list";s:14:"filter_by_date";s:23:"Filter projects by date";s:21:"items_list_navigation";s:24:"Projects list navigation";s:10:"items_list";s:13:"Projects list";s:14:"item_published";s:18:"Project published.";s:24:"item_published_privately";s:28:"Project published privately.";s:22:"item_reverted_to_draft";s:26:"Project reverted to draft.";s:14:"item_scheduled";s:18:"Project scheduled.";s:12:"item_updated";s:16:"Project updated.";s:9:"item_link";s:12:"Project Link";s:21:"item_link_description";s:20:"A link to a project.";}s:11:"description";s:0:"";s:6:"public";b:1;s:12:"hierarchical";b:0;s:19:"exclude_from_search";b:0;s:18:"publicly_queryable";b:1;s:7:"show_ui";b:1;s:12:"show_in_menu";b:1;s:17:"admin_menu_parent";s:0:"";s:17:"show_in_admin_bar";b:1;s:17:"show_in_nav_menus";b:1;s:12:"show_in_rest";b:1;s:9:"rest_base";s:0:"";s:14:"rest_namespace";s:5:"wp/v2";s:21:"rest_controller_class";s:24:"WP_REST_Posts_Controller";s:13:"menu_position";s:0:"";s:9:"menu_icon";s:25:"dashicons-admin-site-alt3";s:19:"rename_capabilities";b:1;s:24:"singular_capability_name";s:4:"post";s:22:"plural_capability_name";s:5:"posts";s:8:"supports";a:10:{i:0;s:5:"title";i:1;s:6:"author";i:2;s:10:"trackbacks";i:3;s:6:"editor";i:4;s:7:"excerpt";i:5;s:9:"revisions";i:6;s:15:"page-attributes";i:7;s:9:"thumbnail";i:8;s:13:"custom-fields";i:9;s:12:"post-formats";}s:10:"taxonomies";s:0:"";s:11:"has_archive";b:0;s:16:"has_archive_slug";s:0:"";s:7:"rewrite";a:4:{s:17:"permalink_rewrite";s:13:"post_type_key";s:10:"with_front";s:1:"1";s:5:"feeds";s:1:"0";s:5:"pages";s:1:"1";}s:9:"query_var";s:13:"post_type_key";s:14:"query_var_name";s:0:"";s:10:"can_export";b:1;s:16:"delete_with_user";b:0;s:20:"register_meta_box_cb";s:0:"";s:16:"enter_title_here";s:0:"";}', 'Projects', 'projects', 'publish', 'closed', 'closed', '', 'post_type_6601c12472fc0', '', '', '2024-03-25 18:39:41', '2024-03-25 18:39:41', '', 0, 'https://theatrum.ssl/?post_type=acf-post-type&#038;p=40', 0, 'acf-post-type', '', 0),
(41, 1, '2024-03-25 18:29:06', '2024-03-25 18:29:06', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"project";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'projects', 'projects', 'publish', 'closed', 'closed', '', 'group_6601c2340e30f', '', '', '2024-03-25 18:29:49', '2024-03-25 18:29:49', '', 0, 'https://theatrum.ssl/?post_type=acf-field-group&#038;p=41', 0, 'acf-field-group', '', 0),
(42, 1, '2024-03-25 18:29:06', '2024-03-25 18:29:06', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:5:"table";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:0:"";s:12:"button_label";s:0:"";s:13:"rows_per_page";i:20;}', 'Challenges', 'challenges', 'publish', 'closed', 'closed', '', 'field_6601c234c6ba0', '', '', '2024-03-25 18:29:49', '2024-03-25 18:29:49', '', 41, 'https://theatrum.ssl/?post_type=acf-field&#038;p=42', 1, 'acf-field', '', 0),
(43, 1, '2024-03-25 18:29:06', '2024-03-25 18:29:06', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', '', '', 'publish', 'closed', 'closed', '', 'field_6601c249c6ba1', '', '', '2024-03-25 18:29:06', '2024-03-25 18:29:06', '', 42, 'https://theatrum.ssl/?post_type=acf-field&p=43', 0, 'acf-field', '', 0),
(44, 1, '2024-03-25 18:29:06', '2024-03-25 18:29:06', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:5:"table";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:0:"";s:12:"button_label";s:0:"";s:13:"rows_per_page";i:20;}', 'Features', 'features', 'publish', 'closed', 'closed', '', 'field_6601c256c6ba2', '', '', '2024-03-25 18:29:49', '2024-03-25 18:29:49', '', 41, 'https://theatrum.ssl/?post_type=acf-field&#038;p=44', 2, 'acf-field', '', 0),
(45, 1, '2024-03-25 18:29:06', '2024-03-25 18:29:06', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', '', '', 'publish', 'closed', 'closed', '', 'field_6601c256c6ba3', '', '', '2024-03-25 18:29:06', '2024-03-25 18:29:06', '', 44, 'https://theatrum.ssl/?post_type=acf-field&p=45', 0, 'acf-field', '', 0),
(46, 1, '2024-03-25 18:29:06', '2024-03-25 18:29:06', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:5:"table";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:0:"";s:12:"button_label";s:0:"";s:13:"rows_per_page";i:20;}', 'Results', 'results', 'publish', 'closed', 'closed', '', 'field_6601c263c6ba4', '', '', '2024-03-25 18:29:49', '2024-03-25 18:29:49', '', 41, 'https://theatrum.ssl/?post_type=acf-field&#038;p=46', 3, 'acf-field', '', 0),
(47, 1, '2024-03-25 18:29:06', '2024-03-25 18:29:06', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', '', '', 'publish', 'closed', 'closed', '', 'field_6601c263c6ba5', '', '', '2024-03-25 18:29:06', '2024-03-25 18:29:06', '', 46, 'https://theatrum.ssl/?post_type=acf-field&p=47', 0, 'acf-field', '', 0),
(48, 1, '2024-03-25 18:29:16', '2024-03-25 18:29:16', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Overview', '', 'publish', 'closed', 'closed', '', 'field_6601c277846a2', '', '', '2024-03-25 18:29:49', '2024-03-25 18:29:49', '', 41, 'https://theatrum.ssl/?post_type=acf-field&#038;p=48', 0, 'acf-field', '', 0),
(49, 1, '2024-03-25 18:29:49', '2024-03-25 18:29:49', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Project Link', 'project_link', 'publish', 'closed', 'closed', '', 'field_6601c28974d57', '', '', '2024-03-25 18:29:49', '2024-03-25 18:29:49', '', 41, 'https://theatrum.ssl/?post_type=acf-field&p=49', 4, 'acf-field', '', 0),
(50, 1, '2024-03-25 18:31:33', '2024-03-25 18:31:33', '', 'LAX Coastal Chamber of Commerce', '', 'publish', 'closed', 'closed', '', 'lax-coastal-chamber-of-commerce', '', '', '2024-03-25 18:31:33', '2024-03-25 18:31:33', '', 0, 'https://theatrum.ssl/?post_type=project&#038;p=50', 0, 'project', '', 0),
(51, 1, '2024-03-25 18:32:25', '2024-03-25 18:32:25', '', 'Full Circle Financial Planning', '', 'publish', 'closed', 'closed', '', 'full-circle-financial-planning', '', '', '2024-03-25 18:37:32', '2024-03-25 18:37:32', '', 0, 'https://theatrum.ssl/?post_type=project&#038;p=51', 0, 'project', '', 0),
(52, 1, '2024-03-25 18:34:02', '2024-03-25 18:34:02', '', 'Abstract Depressionism', '', 'publish', 'closed', 'closed', '', 'abstract-depressionism', '', '', '2024-03-25 18:35:22', '2024-03-25 18:35:22', '', 0, 'https://theatrum.ssl/?post_type=project&#038;p=52', 0, 'project', '', 0),
(53, 1, '2024-03-25 18:31:33', '2024-03-25 18:31:33', '', 'LAX Coastal Chamber of Commerce', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2024-03-25 18:31:33', '2024-03-25 18:31:33', '', 50, 'https://theatrum.ssl/?p=53', 0, 'revision', '', 0),
(54, 1, '2024-03-25 18:32:25', '2024-03-25 18:32:25', '', 'Full Circle Financial Planning', '', 'inherit', 'closed', 'closed', '', '51-revision-v1', '', '', '2024-03-25 18:32:25', '2024-03-25 18:32:25', '', 51, 'https://theatrum.ssl/?p=54', 0, 'revision', '', 0),
(55, 1, '2024-03-25 18:34:02', '2024-03-25 18:34:02', '', 'Abstract Depressionism', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2024-03-25 18:34:02', '2024-03-25 18:34:02', '', 52, 'https://theatrum.ssl/?p=55', 0, 'revision', '', 0) ;
INSERT INTO `tu_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(58, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '<!-- wp:woocommerce/cart -->\n<div class="wp-block-woocommerce-cart alignwide is-loading"><!-- wp:woocommerce/filled-cart-block -->\n<div class="wp-block-woocommerce-filled-cart-block"><!-- wp:woocommerce/cart-items-block -->\n<div class="wp-block-woocommerce-cart-items-block"><!-- wp:woocommerce/cart-line-items-block -->\n<div class="wp-block-woocommerce-cart-line-items-block"></div>\n<!-- /wp:woocommerce/cart-line-items-block -->\n\n<!-- wp:woocommerce/cart-cross-sells-block -->\n<div class="wp-block-woocommerce-cart-cross-sells-block"><!-- wp:heading {"fontSize":"large"} -->\n<h2 class="wp-block-heading has-large-font-size">You may be interested in…</h2>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/cart-cross-sells-products-block -->\n<div class="wp-block-woocommerce-cart-cross-sells-products-block"></div>\n<!-- /wp:woocommerce/cart-cross-sells-products-block --></div>\n<!-- /wp:woocommerce/cart-cross-sells-block --></div>\n<!-- /wp:woocommerce/cart-items-block -->\n\n<!-- wp:woocommerce/cart-totals-block -->\n<div class="wp-block-woocommerce-cart-totals-block"><!-- wp:woocommerce/cart-order-summary-block -->\n<div class="wp-block-woocommerce-cart-order-summary-block"><!-- wp:woocommerce/cart-order-summary-heading-block -->\n<div class="wp-block-woocommerce-cart-order-summary-heading-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-heading-block -->\n\n<!-- wp:woocommerce/cart-order-summary-coupon-form-block -->\n<div class="wp-block-woocommerce-cart-order-summary-coupon-form-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-coupon-form-block -->\n\n<!-- wp:woocommerce/cart-order-summary-subtotal-block -->\n<div class="wp-block-woocommerce-cart-order-summary-subtotal-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-subtotal-block -->\n\n<!-- wp:woocommerce/cart-order-summary-fee-block -->\n<div class="wp-block-woocommerce-cart-order-summary-fee-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-fee-block -->\n\n<!-- wp:woocommerce/cart-order-summary-discount-block -->\n<div class="wp-block-woocommerce-cart-order-summary-discount-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-discount-block -->\n\n<!-- wp:woocommerce/cart-order-summary-shipping-block -->\n<div class="wp-block-woocommerce-cart-order-summary-shipping-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-shipping-block -->\n\n<!-- wp:woocommerce/cart-order-summary-taxes-block -->\n<div class="wp-block-woocommerce-cart-order-summary-taxes-block"></div>\n<!-- /wp:woocommerce/cart-order-summary-taxes-block --></div>\n<!-- /wp:woocommerce/cart-order-summary-block -->\n\n<!-- wp:woocommerce/cart-express-payment-block -->\n<div class="wp-block-woocommerce-cart-express-payment-block"></div>\n<!-- /wp:woocommerce/cart-express-payment-block -->\n\n<!-- wp:woocommerce/proceed-to-checkout-block -->\n<div class="wp-block-woocommerce-proceed-to-checkout-block"></div>\n<!-- /wp:woocommerce/proceed-to-checkout-block -->\n\n<!-- wp:woocommerce/cart-accepted-payment-methods-block -->\n<div class="wp-block-woocommerce-cart-accepted-payment-methods-block"></div>\n<!-- /wp:woocommerce/cart-accepted-payment-methods-block --></div>\n<!-- /wp:woocommerce/cart-totals-block --></div>\n<!-- /wp:woocommerce/filled-cart-block -->\n\n<!-- wp:woocommerce/empty-cart-block -->\n<div class="wp-block-woocommerce-empty-cart-block"><!-- wp:heading {"textAlign":"center","className":"with-empty-cart-icon wc-block-cart__empty-cart__title"} -->\n<h2 class="wp-block-heading has-text-align-center with-empty-cart-icon wc-block-cart__empty-cart__title">Your cart is currently empty!</h2>\n<!-- /wp:heading -->\n\n<!-- wp:separator {"className":"is-style-dots"} -->\n<hr class="wp-block-separator has-alpha-channel-opacity is-style-dots"/>\n<!-- /wp:separator -->\n\n<!-- wp:heading {"textAlign":"center"} -->\n<h2 class="wp-block-heading has-text-align-center">New in store</h2>\n<!-- /wp:heading -->\n\n<!-- wp:woocommerce/product-new {"columns":4,"rows":1} /--></div>\n<!-- /wp:woocommerce/empty-cart-block --></div>\n<!-- /wp:woocommerce/cart -->', 'Cart', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2024-03-25 18:47:08', '2024-03-25 18:47:08', '', 32, 'https://theatrum.ssl/?p=58', 0, 'revision', '', 0),
(59, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '<!-- wp:woocommerce/checkout -->\n<div class="wp-block-woocommerce-checkout alignwide wc-block-checkout is-loading"><!-- wp:woocommerce/checkout-fields-block -->\n<div class="wp-block-woocommerce-checkout-fields-block"><!-- wp:woocommerce/checkout-express-payment-block -->\n<div class="wp-block-woocommerce-checkout-express-payment-block"></div>\n<!-- /wp:woocommerce/checkout-express-payment-block -->\n\n<!-- wp:woocommerce/checkout-contact-information-block -->\n<div class="wp-block-woocommerce-checkout-contact-information-block"></div>\n<!-- /wp:woocommerce/checkout-contact-information-block -->\n\n<!-- wp:woocommerce/checkout-shipping-method-block -->\n<div class="wp-block-woocommerce-checkout-shipping-method-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-method-block -->\n\n<!-- wp:woocommerce/checkout-pickup-options-block -->\n<div class="wp-block-woocommerce-checkout-pickup-options-block"></div>\n<!-- /wp:woocommerce/checkout-pickup-options-block -->\n\n<!-- wp:woocommerce/checkout-shipping-address-block -->\n<div class="wp-block-woocommerce-checkout-shipping-address-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-address-block -->\n\n<!-- wp:woocommerce/checkout-billing-address-block -->\n<div class="wp-block-woocommerce-checkout-billing-address-block"></div>\n<!-- /wp:woocommerce/checkout-billing-address-block -->\n\n<!-- wp:woocommerce/checkout-shipping-methods-block -->\n<div class="wp-block-woocommerce-checkout-shipping-methods-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-methods-block -->\n\n<!-- wp:woocommerce/checkout-payment-block -->\n<div class="wp-block-woocommerce-checkout-payment-block"></div>\n<!-- /wp:woocommerce/checkout-payment-block -->\n\n<!-- wp:woocommerce/checkout-additional-information-block -->\n<div class="wp-block-woocommerce-checkout-additional-information-block"></div>\n<!-- /wp:woocommerce/checkout-additional-information-block -->\n\n<!-- wp:woocommerce/checkout-order-note-block -->\n<div class="wp-block-woocommerce-checkout-order-note-block"></div>\n<!-- /wp:woocommerce/checkout-order-note-block -->\n\n<!-- wp:woocommerce/checkout-terms-block -->\n<div class="wp-block-woocommerce-checkout-terms-block"></div>\n<!-- /wp:woocommerce/checkout-terms-block -->\n\n<!-- wp:woocommerce/checkout-actions-block -->\n<div class="wp-block-woocommerce-checkout-actions-block"></div>\n<!-- /wp:woocommerce/checkout-actions-block --></div>\n<!-- /wp:woocommerce/checkout-fields-block -->\n\n<!-- wp:woocommerce/checkout-totals-block -->\n<div class="wp-block-woocommerce-checkout-totals-block"><!-- wp:woocommerce/checkout-order-summary-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-block"><!-- wp:woocommerce/checkout-order-summary-cart-items-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-cart-items-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-cart-items-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-coupon-form-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-coupon-form-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-coupon-form-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-subtotal-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-subtotal-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-subtotal-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-fee-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-fee-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-fee-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-discount-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-discount-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-discount-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-shipping-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-shipping-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-shipping-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-taxes-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-taxes-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-taxes-block --></div>\n<!-- /wp:woocommerce/checkout-order-summary-block --></div>\n<!-- /wp:woocommerce/checkout-totals-block --></div>\n<!-- /wp:woocommerce/checkout -->', 'Checkout', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2024-03-25 18:47:08', '2024-03-25 18:47:08', '', 33, 'https://theatrum.ssl/?p=59', 0, 'revision', '', 0),
(60, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'My account', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2024-03-25 18:47:08', '2024-03-25 18:47:08', '', 34, 'https://theatrum.ssl/?p=60', 0, 'revision', '', 0),
(61, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: https://theatrum.ssl.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2024-03-25 18:47:08', '2024-03-25 18:47:08', '', 3, 'https://theatrum.ssl/?p=61', 0, 'revision', '', 0),
(62, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '<!-- wp:paragraph -->\n<p><b>This is a sample page.</b></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h3>Overview</h3>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Several types of goods are exempt from being returned. Perishable goods such as food, flowers, newspapers or magazines cannot be returned. We also do not accept products that are intimate or sanitary goods, hazardous materials, or flammable liquids or gases.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Additional non-returnable items:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Gift cards</li>\n<li>Downloadable software products</li>\n<li>Some health and personal care items</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>To complete your return, we require a receipt or proof of purchase.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Please do not send your purchase back to the manufacturer.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>There are certain situations where only partial refunds are granted:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Book with obvious signs of use</li>\n<li>CD, DVD, VHS tape, software, video game, cassette tape, or vinyl record that has been opened.</li>\n<li>Any item not in its original condition, is damaged or missing parts for reasons not due to our error.</li>\n<li>Any item that is returned more than 30 days after delivery</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<h2>Refunds</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Late or missing refunds</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you haven’t received a refund yet, first check your bank account again.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Then contact your credit card company, it may take some time before your refund is officially posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Next contact your bank. There is often some processing time before a refund is posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you’ve done all of this and you still have not received your refund yet, please contact us at {email address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Sale items</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Only regular priced items may be refunded. Sale items cannot be refunded.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Exchanges</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at {email address} and send your item to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Gifts</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item was marked as a gift when purchased and shipped directly to you, you’ll receive a gift credit for the value of your return. Once the returned item is received, a gift certificate will be mailed to you.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item wasn’t marked as a gift when purchased, or the gift giver had the order shipped to themselves to give to you later, we will send a refund to the gift giver and they will find out about your return.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Shipping returns</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To return your product, you should mail your product to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Depending on where you live, the time it may take for your exchanged product to reach you may vary.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are returning more expensive items, you may consider using a trackable shipping service or purchasing shipping insurance. We don’t guarantee that we will receive your returned item.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Need help?</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Contact us at {email} for questions related to refunds and returns.</p>\n<!-- /wp:paragraph -->', 'Refund and Returns Policy', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2024-03-25 18:47:08', '2024-03-25 18:47:08', '', 35, 'https://theatrum.ssl/?p=62', 0, 'revision', '', 0),
(63, 1, '2024-03-25 18:47:08', '2024-03-25 18:47:08', '', 'Shop', '', 'inherit', 'closed', 'closed', '', '31-revision-v1', '', '', '2024-03-25 18:47:08', '2024-03-25 18:47:08', '', 31, 'https://theatrum.ssl/?p=63', 0, 'revision', '', 0),
(64, 1, '2024-03-25 18:47:12', '2024-03-25 18:47:12', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-theatrum-fundamentum', '', '', '2024-03-25 18:47:12', '2024-03-25 18:47:12', '', 0, 'https://theatrum.ssl/blog/2024/03/25/wp-global-styles-theatrum-fundamentum/', 0, 'wp_global_styles', '', 0),
(65, 1, '2024-03-25 18:49:18', '2024-03-25 18:49:18', '<!-- wp:notion-wp-sync/notion-content /-->', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2024-03-25 18:50:09', '2024-03-25 18:50:09', '', 0, 'https://theatrum.ssl/?page_id=65', 7, 'page', '', 0),
(66, 1, '2024-03-25 18:49:18', '2024-03-25 18:49:18', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2024-03-25 18:49:18', '2024-03-25 18:49:18', '', 65, 'https://theatrum.ssl/?p=66', 0, 'revision', '', 0),
(67, 1, '2024-03-25 18:50:03', '2024-03-25 18:50:03', '<!-- wp:notion-wp-sync/notion-content /-->', 'Blog', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2024-03-25 18:50:03', '2024-03-25 18:50:03', '', 65, 'https://theatrum.ssl/?p=67', 0, 'revision', '', 0),
(68, 1, '2024-03-25 18:52:42', '0000-00-00 00:00:00', '', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2024-03-25 18:52:42', '0000-00-00 00:00:00', '', 0, 'https://theatrum.ssl/?post_type=product&p=68', 0, 'product', '', 0),
(69, 1, '2024-03-25 18:52:46', '2024-03-25 18:52:46', '<!-- wp:paragraph -->\n<p>Link-in-bios, landing page, resumes, or events</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Unlimited links</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>1 interactive component</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>1 form (newsletter sign up, contact form, RSVP form, etc.)</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Unus', 'Single Web Page', 'publish', 'open', 'closed', '', 'unus', '', '', '2024-03-25 18:55:36', '2024-03-25 18:55:36', '', 0, 'https://theatrum.ssl/?post_type=product&#038;p=69', 0, 'product', '', 0),
(70, 1, '2024-03-25 18:55:51', '2024-03-25 18:55:51', 'Showcase your work with a 4-page portfolio blog customized to your media.', 'Opus', 'Portfolio Website', 'publish', 'open', 'closed', '', 'opus', '', '', '2024-03-25 19:00:06', '2024-03-25 19:00:06', '', 0, 'https://theatrum.ssl/?post_type=product&#038;p=70', 0, 'product', '', 0),
(71, 1, '2024-03-25 18:55:55', '2024-03-25 18:55:55', '<!-- wp:paragraph -->\n<p>Get your website working harder for your organization!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Analytics</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Automation</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Vibrant brand representation</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Small Groups, Clubs, HOAs, etc.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>3-5 main pages</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>2 forms / 1 feature</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>2 templates, single page + archive</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->', 'Ordinatio', 'Websites for Organizations', 'publish', 'open', 'closed', '', 'ordinatio', '', '', '2024-03-25 19:02:34', '2024-03-25 19:02:34', '', 0, 'https://theatrum.ssl/?post_type=product&#038;p=71', 0, 'product', '', 0),
(72, 1, '2024-03-25 19:22:50', '2024-03-25 19:22:50', '<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Company Overview</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:paragraph -->\n<p>Theatrum Mundi—Latin for the concept that *All The World’s a Stage—*is a full-service Web Experience agency, specializing in building beautiful websites that reflect the personality, brand, and values of an organization, while also serving as an essential tool in day-to-day business operations. Your website shouldn’t be a nuisance to maintain or a back-burner project. Instead, your website should be seamlessly integrated with your existing systems and processes making your work easier. Everyone’s website can be doing more for them than it’s currently doing.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Whether is an e-commerce, business, event, micro-, membership, or non-profit website, Theatrum Mundi guides the client through the process of designing (or redesigning) their website from registering a domain name to regular maintenance.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Differentiator</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Anna Jennings is a web consultant, designer, and developer with a background in non-profit theatre producing and an MFA in Generative Dramaturgy. Still a practicing theatre artist, Anna founded Theatrum Mundi brings her artistic eye, storytelling intuition, and expertise in fusing form and function to the web design process.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Vision Statement</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam hendrerit nisi sed sollicitudin pellentesque. Nunc posuere purus rhoncus pulvinar aliquam. Ut aliquet tristique nisl vitae volutpat. Nulla aliquet porttitor venenatis. Donec a dui et dui fringilla consectetur id nec massa. Aliquam erat volutpat. Sed ut dui ut lacus dictum fermentum vel tincidunt neque. Sed sed lacinia lectus. Duis sit amet sodales felis. Duis nunc eros, mattis at dui ac, convallis semper risus. In adipiscing ultrices tellus, in suscipit massa vehicula eu.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Target Clients</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Established experience-centered organizations, companies, &amp; individuals, including restaurants, artists/performers, specialty retail, non-profits, and any organization with a story to tell.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Services</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Content</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Blog content</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Photography</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Copywriting</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Media Curation</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Design</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>UX/UI Design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Experience Design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Brand Design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Visual Design</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Development</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Customized systems</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>API Integrations</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Frontend (HTML, CSS, &amp; JavaScript)</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>WordPress, Wix, Webflow, SquareSpace</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Management</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Security</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Backups</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Updates</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Web Hosting</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Contact Info</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Anna Jennings, Owner &amp; Founder</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>5665 W. Wilshire Blvd #1679</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Los Angeles, CA 90036</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>520-232-4990</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="mailto:anna@theatrummundi.co">anna@theatrummundi.co</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="http://theatrummundi.co">theatrummundi.co</a></p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Company Info</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong>Founded in January 2023</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>LLC - Limited Liability Corporation</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>CPUC Small Business Certification (pending)</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>NAICS Codes</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=51&amp;chart=2022&amp;details=518210">518210 Computing Infrastructure Providers, Data Processing, Web Hosting, and Related Services</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=web&amp;year=2022&amp;details=541511">541511&nbsp;Web&nbsp;(i.e., Internet) page design services, custom</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=design&amp;year=2022&amp;details=541512">541512 Computer Systems Design Services</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=design&amp;year=2022&amp;details=541430">541430 Graphic Design Services</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=71&amp;chart=2022&amp;details=711510">711510 Independent Artists, Writers, and Performers</a></p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Past Projects</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">LAXcoastal.com</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">fullcirclefinancialplanning.com</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">abstractdepressionism.blog</h3>\n<!-- /wp:heading --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->', 'Capability Statement', '', 'publish', 'closed', 'closed', '', 'capability-statement', '', '', '2024-03-25 19:35:23', '2024-03-25 19:35:23', '', 0, 'https://theatrum.ssl/?page_id=72', 0, 'page', '', 0),
(73, 1, '2024-03-25 19:20:52', '2024-03-25 19:20:52', '<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Vision</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Balance form and function in the contemporary website.</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>We envision a website as an artistic object, living/breathing, and functional tool.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Mission</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Apply Dramaturgical practice to holistic web design</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Empower creative entrepreneurs with bespoke website that tells a story and solves problems.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Values</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Curiosity</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Empathy</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Innovation</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Creativity</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Empiricism</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Data-driven</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Heuristic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Research-backed</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Informed</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Collaboration</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Open source</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Community-driven</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Communication</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Universality</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Comprehensive</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>All-inclusive</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>User-/human-centric design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Holistic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Flexibility</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Artisanship</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Elegant</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Sophisticated</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>High-quality</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Detail-oriented</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Durability</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Aesthetic</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>High-contrast</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Black &amp; White</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Film noir</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Bold</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Kinetic</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Animations</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Movement</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Responsive design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Dynamic</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Remix</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Retro</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Classic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Adaptation</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Abstract</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>evocative</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>innovative</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>impressionistic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Form</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Line</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Color to evoke emotional response</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Saturation</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Dense</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Immersive</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Colorful</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->', 'Mission Vision Values', '', 'publish', 'closed', 'closed', '', 'mission-vision-values', '', '', '2024-03-25 19:20:52', '2024-03-25 19:20:52', '', 0, 'https://theatrum.ssl/blog/2024/03/25/mission-vision-values/', 0, 'wp_block', '', 0),
(74, 1, '2024-03-25 19:22:50', '2024-03-25 19:22:50', '<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Overview</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:paragraph -->\n<p>Theatrum Mundi—Latin for the concept that *All The World’s a Stage—*is a full-service Web Experience agency, specializing in building beautiful websites that reflect the personality, brand, and values of an organization, while also serving as an essential tool in day-to-day business operations. Your website shouldn’t be a nuisance to maintain or a back-burner project. Instead, your website should be seamlessly integrated with your existing systems and processes making your work easier. Everyone’s website can be doing more for them than it’s currently doing.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Whether is an e-commerce, business, event, micro-, membership, or non-profit website, Theatrum Mundi guides the client through the process of designing (or redesigning) their website from registering a domain name to regular maintenance.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Differentiator</h2>\n<!-- /wp:heading --></div>\n<!-- /wp:group -->\n\n<!-- wp:paragraph -->\n<p>Anna Jennings is a web consultant, designer, and developer with a background in non-profit theatre producing and an MFA in Generative Dramaturgy. Still a practicing theatre artist, Anna founded Theatrum Mundi brings her artistic eye, storytelling intuition, and expertise in fusing form and function to the web design process.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Vision Statement</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam hendrerit nisi sed sollicitudin pellentesque. Nunc posuere purus rhoncus pulvinar aliquam. Ut aliquet tristique nisl vitae volutpat. Nulla aliquet porttitor venenatis. Donec a dui et dui fringilla consectetur id nec massa. Aliquam erat volutpat. Sed ut dui ut lacus dictum fermentum vel tincidunt neque. Sed sed lacinia lectus. Duis sit amet sodales felis. Duis nunc eros, mattis at dui ac, convallis semper risus. In adipiscing ultrices tellus, in suscipit massa vehicula eu.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:block {"ref":73} /-->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Services</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Content</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Blog content</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Photography</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Copywriting</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Media Curation</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Design</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>UX/UI Design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Experience Design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Brand Design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Visual Design</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Development</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Customized systems</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>API Integrations</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Frontend (HTML, CSS, &amp; JavaScript)</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>WordPress, Wix, Webflow, SquareSpace</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Management</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Security</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Backups</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Updates</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Web Hosting</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Target Clients</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Established experience-centered organizations, companies, &amp; individuals, including restaurants, artists/performers, specialty retail, non-profits, and any organization with a story to tell.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Company Info</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong>Founded in January 2023</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>LLC - Limited Liability Corporation</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>CPUC Small Business Certification (pending)</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>NAICS Codes</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=51&amp;chart=2022&amp;details=518210">518210 Computing Infrastructure Providers, Data Processing, Web Hosting, and Related Services</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=web&amp;year=2022&amp;details=541511">541511&nbsp;Web&nbsp;(i.e., Internet) page design services, custom</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=design&amp;year=2022&amp;details=541512">541512 Computer Systems Design Services</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=design&amp;year=2022&amp;details=541430">541430 Graphic Design Services</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=71&amp;chart=2022&amp;details=711510">711510 Independent Artists, Writers, and Performers</a></p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Contact Info</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Anna Jennings, Owner &amp; Founder</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>5665 W. Wilshire Blvd #1679</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Los Angeles, CA 90036</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>520-232-4990</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="mailto:anna@theatrummundi.co">anna@theatrummundi.co</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="http://theatrummundi.co">theatrummundi.co</a></p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Past Projects</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">LAXcoastal.com</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">fullcirclefinancialplanning.com</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">abstractdepressionism.blog</h3>\n<!-- /wp:heading --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->', 'Capability Statement', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2024-03-25 19:22:50', '2024-03-25 19:22:50', '', 72, 'https://theatrum.ssl/?p=74', 0, 'revision', '', 0) ;
INSERT INTO `tu_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(75, 1, '2024-03-25 19:33:32', '2024-03-25 19:33:32', '<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Vision</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Balance form and function in the contemporary website.</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>We envision a website as an artistic object, living/breathing, and functional tool.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Mission</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Apply Dramaturgical practice to holistic web design</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Empower creative entrepreneurs with bespoke website that tells a story and solves problems.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Values</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Curiosity</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Empathy</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Innovation</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Creativity</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Empiricism</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Data-driven</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Heuristic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Research-backed</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Informed</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Collaboration</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Open source</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Community-driven</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Communication</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Universality</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Comprehensive</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>All-inclusive</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>User-/human-centric design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Holistic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Flexibility</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Artisanship</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Elegant</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Sophisticated</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>High-quality</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Detail-oriented</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Durability</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Aesthetic</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>High-contrast</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Black &amp; White</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Film noir</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Bold</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Kinetic</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Animations</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Movement</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Responsive design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Dynamic</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Remix</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Retro</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Classic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Adaptation</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Abstract</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>evocative</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>innovative</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>impressionistic</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Form</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Line</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Color to evoke emotional response</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading"><strong>Saturation</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Dense</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Immersive</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Colorful</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->', 'mvv', '', 'publish', 'closed', 'closed', '', 'mvv', '', '', '2024-03-25 19:33:32', '2024-03-25 19:33:32', '', 0, 'https://theatrum.ssl/blog/2024/03/25/mvv/', 0, 'wp_block', '', 0),
(77, 1, '2024-03-25 19:35:23', '2024-03-25 19:35:23', '<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Company Overview</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:paragraph -->\n<p>Theatrum Mundi—Latin for the concept that *All The World’s a Stage—*is a full-service Web Experience agency, specializing in building beautiful websites that reflect the personality, brand, and values of an organization, while also serving as an essential tool in day-to-day business operations. Your website shouldn’t be a nuisance to maintain or a back-burner project. Instead, your website should be seamlessly integrated with your existing systems and processes making your work easier. Everyone’s website can be doing more for them than it’s currently doing.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Whether is an e-commerce, business, event, micro-, membership, or non-profit website, Theatrum Mundi guides the client through the process of designing (or redesigning) their website from registering a domain name to regular maintenance.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Differentiator</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Anna Jennings is a web consultant, designer, and developer with a background in non-profit theatre producing and an MFA in Generative Dramaturgy. Still a practicing theatre artist, Anna founded Theatrum Mundi brings her artistic eye, storytelling intuition, and expertise in fusing form and function to the web design process.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Vision Statement</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam hendrerit nisi sed sollicitudin pellentesque. Nunc posuere purus rhoncus pulvinar aliquam. Ut aliquet tristique nisl vitae volutpat. Nulla aliquet porttitor venenatis. Donec a dui et dui fringilla consectetur id nec massa. Aliquam erat volutpat. Sed ut dui ut lacus dictum fermentum vel tincidunt neque. Sed sed lacinia lectus. Duis sit amet sodales felis. Duis nunc eros, mattis at dui ac, convallis semper risus. In adipiscing ultrices tellus, in suscipit massa vehicula eu.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Target Clients</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Established experience-centered organizations, companies, &amp; individuals, including restaurants, artists/performers, specialty retail, non-profits, and any organization with a story to tell.</p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Services</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Content</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Blog content</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Photography</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Copywriting</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Media Curation</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Design</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>UX/UI Design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Experience Design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Brand Design</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Visual Design</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Development</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Customized systems</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>API Integrations</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Frontend (HTML, CSS, &amp; JavaScript)</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>WordPress, Wix, Webflow, SquareSpace</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Management</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list -->\n<ul><!-- wp:list-item -->\n<li>Security</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Backups</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Updates</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Web Hosting</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Contact Info</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Anna Jennings, Owner &amp; Founder</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>5665 W. Wilshire Blvd #1679</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Los Angeles, CA 90036</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>520-232-4990</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="mailto:anna@theatrummundi.co">anna@theatrummundi.co</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="http://theatrummundi.co">theatrummundi.co</a></p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"constrained"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Company Info</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong>Founded in January 2023</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>LLC - Limited Liability Corporation</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>CPUC Small Business Certification (pending)</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>NAICS Codes</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=51&amp;chart=2022&amp;details=518210">518210 Computing Infrastructure Providers, Data Processing, Web Hosting, and Related Services</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=web&amp;year=2022&amp;details=541511">541511&nbsp;Web&nbsp;(i.e., Internet) page design services, custom</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=design&amp;year=2022&amp;details=541512">541512 Computer Systems Design Services</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=design&amp;year=2022&amp;details=541430">541430 Graphic Design Services</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href="https://www.census.gov/naics/?input=71&amp;chart=2022&amp;details=711510">711510 Independent Artists, Writers, and Performers</a></p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:group -->\n\n<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2 class="wp-block-heading">Past Projects</h2>\n<!-- /wp:heading -->\n\n<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->\n<div class="wp-block-group"><!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">LAXcoastal.com</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">fullcirclefinancialplanning.com</h3>\n<!-- /wp:heading -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">abstractdepressionism.blog</h3>\n<!-- /wp:heading --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->', 'Capability Statement', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2024-03-25 19:35:23', '2024-03-25 19:35:23', '', 72, 'https://theatrum.ssl/?p=77', 0, 'revision', '', 0),
(78, 1, '2024-03-25 19:37:07', '2024-03-25 19:37:07', '<!-- wp:template-part {"slug":"header","theme":"theatrum-fundamentum","tagName":"header","className":"site-header"} /-->\n\n<!-- wp:group {"tagName":"main","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"layout":{"type":"default"}} -->\n<main class="wp-block-group" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:post-content {"align":"full","layout":{"type":"constrained"}} /--></main>\n<!-- /wp:group -->\n\n<!-- wp:template-part {"slug":"footer","theme":"theatrum-fundamentum","tagName":"footer","className":"site-footer"} /-->', 'Pages', 'Display all static pages unless a custom template has been applied or a dedicated template exists.', 'publish', 'closed', 'closed', '', 'page', '', '', '2024-03-25 19:37:07', '2024-03-25 19:37:07', '', 0, 'https://theatrum.ssl/blog/2024/03/25/page/', 0, 'wp_template', '', 0),
(79, 1, '2024-03-25 20:01:05', '2024-03-25 20:01:05', '<!-- wp:navigation-link {"label":"Capability Statement","type":"page","id":72,"url":"https://theatrum.ssl/capability-statement/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Home","type":"page","id":11,"url":"https://theatrum.ssl/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"About","type":"page","id":12,"url":"https://theatrum.ssl/about/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Services","type":"page","id":13,"url":"https://theatrum.ssl/services/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Projects","type":"page","id":15,"url":"https://theatrum.ssl/projects/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Contact","type":"page","id":14,"url":"https://theatrum.ssl/contact/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Blog","type":"page","id":65,"url":"https://theatrum.ssl/blog/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Shop","type":"page","id":31,"url":"https://theatrum.ssl/shop/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Privacy Policy","type":"page","id":3,"url":"https://theatrum.ssl/privacy-policy/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Accessibility Statement","type":"page","id":16,"url":"https://theatrum.ssl/accessibility-statement/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Refund and Returns Policy","type":"page","id":35,"url":"https://theatrum.ssl/refund_returns/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Cart","type":"page","id":32,"url":"https://theatrum.ssl/cart/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Checkout","type":"page","id":33,"url":"https://theatrum.ssl/checkout/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"My account","type":"page","id":34,"url":"https://theatrum.ssl/my-account/","kind":"post-type"} /-->', 'Header Navigation', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2024-03-25 20:01:05', '2024-03-25 20:01:05', '', 21, 'https://theatrum.ssl/?p=79', 0, 'revision', '', 0),
(80, 1, '2024-03-25 20:01:05', '2024-03-25 20:01:05', '<!-- wp:group {"style":{"spacing":{"padding":{"left":"var:preset|spacing|60","right":"var:preset|spacing|60"}}},"layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->\n<div class="wp-block-group" style="padding-right:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)"><!-- wp:group {"layout":{"type":"flex"}} -->\n<div class="wp-block-group"><!-- wp:site-logo {"width":40} /-->\n\n<!-- wp:site-title {"level":0} /--></div>\n<!-- /wp:group -->\n\n<!-- wp:navigation {"ref":21,"overlayBackgroundColor":"base","overlayTextColor":"contrast","layout":{"type":"flex","justifyContent":"right"}} /--></div>\n<!-- /wp:group -->', 'Header', '', 'publish', 'closed', 'closed', '', 'header', '', '', '2024-03-25 20:01:05', '2024-03-25 20:01:05', '', 0, 'https://theatrum.ssl/blog/2024/03/25/header/', 0, 'wp_template_part', '', 0),
(81, 1, '2024-03-25 20:04:58', '2024-03-25 20:04:58', '<!-- wp:navigation-link {"label":"Capability Statement","type":"page","id":72,"url":"https://theatrum.ssl/capability-statement/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Home","type":"page","id":11,"url":"https://theatrum.ssl/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"About","type":"page","id":12,"url":"https://theatrum.ssl/about/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Services","type":"page","id":13,"url":"https://theatrum.ssl/services/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Projects","type":"page","id":15,"url":"https://theatrum.ssl/projects/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Contact","type":"page","id":14,"url":"https://theatrum.ssl/contact/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Blog","type":"page","id":65,"url":"https://theatrum.ssl/blog/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Shop","type":"page","id":31,"url":"https://theatrum.ssl/shop/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Privacy Policy","type":"page","id":3,"url":"https://theatrum.ssl/privacy-policy/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Accessibility Statement","type":"page","id":16,"url":"https://theatrum.ssl/accessibility-statement/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Refund and Returns Policy","type":"page","id":35,"url":"https://theatrum.ssl/refund_returns/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Cart","type":"page","id":32,"url":"https://theatrum.ssl/cart/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Checkout","type":"page","id":33,"url":"https://theatrum.ssl/checkout/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"My account","type":"page","id":34,"url":"https://theatrum.ssl/my-account/","kind":"post-type"} /-->', 'Footer Navigation', '', 'publish', 'closed', 'closed', '', 'footer-navigation', '', '', '2024-03-25 20:04:58', '2024-03-25 20:04:58', '', 0, 'https://theatrum.ssl/?p=81', 0, 'wp_navigation', '', 0),
(82, 1, '2024-03-25 20:02:25', '2024-03-25 20:02:25', '', 'Footer Navigation', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2024-03-25 20:02:25', '2024-03-25 20:02:25', '', 81, 'https://theatrum.ssl/?p=82', 0, 'revision', '', 0),
(83, 1, '2024-03-25 20:04:55', '2024-03-25 20:04:55', '<!-- wp:group {"style":{"spacing":{"margin":{"top":"var:preset|spacing|70"},"padding":{"left":"var:preset|spacing|60","right":"var:preset|spacing|60"}}},"layout":{"type":"default"}} -->\n<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)"><!-- wp:navigation {"ref":21,"overlayMenu":"never","overlayBackgroundColor":"base","overlayTextColor":"contrast","layout":{"type":"flex","justifyContent":"left","orientation":"horizontal"},"fontSize":"extra-small"} /-->\n\n<!-- wp:group {"align":"full","layout":{"type":"flex","justifyContent":"space-between"}} -->\n<div class="wp-block-group alignfull"><!-- wp:group {"layout":{"type":"flex","allowOrientation":false}} -->\n<div class="wp-block-group"><!-- wp:paragraph {"fontSize":"extra-small"} -->\n<p class="has-extra-small-font-size">\n		Copyright 2024		</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:site-title {"level":0,"fontSize":"extra-small"} /--></div>\n<!-- /wp:group -->\n\n<!-- wp:social-links {"className":"is-style-logos-only"} -->\n<ul class="wp-block-social-links is-style-logos-only"><!-- wp:social-link {"url":"https://wordpress.org","service":"wordpress"} /--></ul>\n<!-- /wp:social-links --></div>\n<!-- /wp:group --></div>\n<!-- /wp:group -->\n\n<!-- wp:navigation {"ref":21} /-->', 'Footer', '', 'publish', 'closed', 'closed', '', 'footer', '', '', '2024-03-25 20:04:55', '2024-03-25 20:04:55', '', 0, 'https://theatrum.ssl/blog/2024/03/25/footer/', 0, 'wp_template_part', '', 0),
(84, 1, '2024-03-25 20:04:58', '2024-03-25 20:04:58', '<!-- wp:navigation-link {"label":"Capability Statement","type":"page","id":72,"url":"https://theatrum.ssl/capability-statement/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Home","type":"page","id":11,"url":"https://theatrum.ssl/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"About","type":"page","id":12,"url":"https://theatrum.ssl/about/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Services","type":"page","id":13,"url":"https://theatrum.ssl/services/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Projects","type":"page","id":15,"url":"https://theatrum.ssl/projects/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Contact","type":"page","id":14,"url":"https://theatrum.ssl/contact/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Blog","type":"page","id":65,"url":"https://theatrum.ssl/blog/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Shop","type":"page","id":31,"url":"https://theatrum.ssl/shop/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Privacy Policy","type":"page","id":3,"url":"https://theatrum.ssl/privacy-policy/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Accessibility Statement","type":"page","id":16,"url":"https://theatrum.ssl/accessibility-statement/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Refund and Returns Policy","type":"page","id":35,"url":"https://theatrum.ssl/refund_returns/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Cart","type":"page","id":32,"url":"https://theatrum.ssl/cart/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"Checkout","type":"page","id":33,"url":"https://theatrum.ssl/checkout/","kind":"post-type"} /-->\n\n<!-- wp:navigation-link {"label":"My account","type":"page","id":34,"url":"https://theatrum.ssl/my-account/","kind":"post-type"} /-->', 'Footer Navigation', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2024-03-25 20:04:58', '2024-03-25 20:04:58', '', 81, 'https://theatrum.ssl/?p=84', 0, 'revision', '', 0),
(85, 1, '2024-03-25 20:07:52', '2024-03-25 20:07:52', '<!-- wp:block {"ref":86} /-->', 'Payments', '', 'publish', 'closed', 'closed', '', 'payments', '', '', '2024-03-25 20:07:52', '2024-03-25 20:07:52', '', 0, 'https://theatrum.ssl/?page_id=85', 0, 'page', '', 0),
(86, 1, '2024-03-25 20:07:03', '2024-03-25 20:07:03', '<!-- wp:woocommerce/checkout -->\n<div class="wp-block-woocommerce-checkout alignwide wc-block-checkout is-loading"><!-- wp:woocommerce/checkout-fields-block -->\n<div class="wp-block-woocommerce-checkout-fields-block"><!-- wp:woocommerce/checkout-express-payment-block -->\n<div class="wp-block-woocommerce-checkout-express-payment-block"></div>\n<!-- /wp:woocommerce/checkout-express-payment-block -->\n\n<!-- wp:woocommerce/checkout-contact-information-block -->\n<div class="wp-block-woocommerce-checkout-contact-information-block"></div>\n<!-- /wp:woocommerce/checkout-contact-information-block -->\n\n<!-- wp:woocommerce/checkout-shipping-method-block -->\n<div class="wp-block-woocommerce-checkout-shipping-method-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-method-block -->\n\n<!-- wp:woocommerce/checkout-pickup-options-block -->\n<div class="wp-block-woocommerce-checkout-pickup-options-block"></div>\n<!-- /wp:woocommerce/checkout-pickup-options-block -->\n\n<!-- wp:woocommerce/checkout-shipping-address-block -->\n<div class="wp-block-woocommerce-checkout-shipping-address-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-address-block -->\n\n<!-- wp:woocommerce/checkout-billing-address-block -->\n<div class="wp-block-woocommerce-checkout-billing-address-block"></div>\n<!-- /wp:woocommerce/checkout-billing-address-block -->\n\n<!-- wp:woocommerce/checkout-shipping-methods-block -->\n<div class="wp-block-woocommerce-checkout-shipping-methods-block"></div>\n<!-- /wp:woocommerce/checkout-shipping-methods-block -->\n\n<!-- wp:woocommerce/checkout-payment-block -->\n<div class="wp-block-woocommerce-checkout-payment-block"></div>\n<!-- /wp:woocommerce/checkout-payment-block -->\n\n<!-- wp:woocommerce/checkout-additional-information-block -->\n<div class="wp-block-woocommerce-checkout-additional-information-block"></div>\n<!-- /wp:woocommerce/checkout-additional-information-block -->\n\n<!-- wp:woocommerce/checkout-order-note-block -->\n<div class="wp-block-woocommerce-checkout-order-note-block"></div>\n<!-- /wp:woocommerce/checkout-order-note-block -->\n\n<!-- wp:woocommerce/checkout-terms-block -->\n<div class="wp-block-woocommerce-checkout-terms-block"></div>\n<!-- /wp:woocommerce/checkout-terms-block -->\n\n<!-- wp:woocommerce/checkout-actions-block -->\n<div class="wp-block-woocommerce-checkout-actions-block"></div>\n<!-- /wp:woocommerce/checkout-actions-block --></div>\n<!-- /wp:woocommerce/checkout-fields-block -->\n\n<!-- wp:woocommerce/checkout-totals-block -->\n<div class="wp-block-woocommerce-checkout-totals-block"><!-- wp:woocommerce/checkout-order-summary-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-block"><!-- wp:woocommerce/checkout-order-summary-cart-items-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-cart-items-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-cart-items-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-coupon-form-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-coupon-form-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-coupon-form-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-subtotal-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-subtotal-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-subtotal-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-fee-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-fee-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-fee-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-discount-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-discount-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-discount-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-shipping-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-shipping-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-shipping-block -->\n\n<!-- wp:woocommerce/checkout-order-summary-taxes-block -->\n<div class="wp-block-woocommerce-checkout-order-summary-taxes-block"></div>\n<!-- /wp:woocommerce/checkout-order-summary-taxes-block --></div>\n<!-- /wp:woocommerce/checkout-order-summary-block --></div>\n<!-- /wp:woocommerce/checkout-totals-block --></div>\n<!-- /wp:woocommerce/checkout -->', 'Payments', '', 'publish', 'closed', 'closed', '', 'payments', '', '', '2024-03-25 20:07:03', '2024-03-25 20:07:03', '', 0, 'https://theatrum.ssl/blog/2024/03/25/payments/', 0, 'wp_block', '', 0),
(87, 1, '2024-03-25 20:07:52', '2024-03-25 20:07:52', '<!-- wp:block {"ref":86} /-->', 'Payments', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2024-03-25 20:07:52', '2024-03-25 20:07:52', '', 85, 'https://theatrum.ssl/?p=87', 0, 'revision', '', 0),
(97, 1, '2024-03-25 20:35:42', '2024-03-25 20:35:42', '', 'fcfp-cover', '', 'inherit', 'open', 'closed', '', 'fcfp-cover', '', '', '2024-03-25 20:35:42', '2024-03-25 20:35:42', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/fcfp-cover.png', 0, 'attachment', 'image/png', 0),
(98, 1, '2024-03-25 20:35:45', '2024-03-25 20:35:45', '', 'fullmoonroad', '', 'inherit', 'open', 'closed', '', 'fullmoonroad', '', '', '2024-03-25 20:35:45', '2024-03-25 20:35:45', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/fullmoonroad.jpg', 0, 'attachment', 'image/jpeg', 0),
(99, 1, '2024-03-25 20:35:46', '2024-03-25 20:35:46', '', 'laxcover', '', 'inherit', 'open', 'closed', '', 'laxcover', '', '', '2024-03-25 20:35:46', '2024-03-25 20:35:46', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/laxcover.png', 0, 'attachment', 'image/png', 0),
(100, 1, '2024-03-25 20:36:02', '2024-03-25 20:36:02', '', 'mask@2x', '', 'inherit', 'open', 'closed', '', 'mask2x', '', '', '2024-03-25 20:36:02', '2024-03-25 20:36:02', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/mask@2x.png', 0, 'attachment', 'image/png', 0),
(101, 1, '2024-03-25 20:48:52', '2024-03-25 20:48:52', '', 'laxcover', '', 'inherit', 'open', 'closed', '', 'laxcover-2', '', '', '2024-03-25 20:48:52', '2024-03-25 20:48:52', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/laxcover-1.png', 0, 'attachment', 'image/png', 0),
(102, 1, '2024-03-25 20:48:55', '2024-03-25 20:48:55', '', 'masks', '', 'inherit', 'open', 'closed', '', 'masks', '', '', '2024-03-25 20:48:55', '2024-03-25 20:48:55', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/masks.jpg', 0, 'attachment', 'image/jpeg', 0),
(103, 1, '2024-03-25 20:48:59', '2024-03-25 20:48:59', '', 'onstage', '', 'inherit', 'open', 'closed', '', 'onstage', '', '', '2024-03-25 20:48:59', '2024-03-25 20:48:59', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/onstage.jpg', 0, 'attachment', 'image/jpeg', 0),
(104, 1, '2024-03-25 20:49:04', '2024-03-25 20:49:04', '', 'stage view', '', 'inherit', 'open', 'closed', '', 'stage-view', '', '', '2024-03-25 20:49:04', '2024-03-25 20:49:04', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/stage-view.jpg', 0, 'attachment', 'image/jpeg', 0),
(105, 1, '2024-03-25 20:49:09', '2024-03-25 20:49:09', '', 'statues', '', 'inherit', 'open', 'closed', '', 'statues', '', '', '2024-03-25 20:49:09', '2024-03-25 20:49:09', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/statues.jpg', 0, 'attachment', 'image/jpeg', 0),
(106, 1, '2024-03-25 20:49:14', '2024-03-25 20:49:14', '', 'theatrum2', '', 'inherit', 'open', 'closed', '', 'theatrum2', '', '', '2024-03-25 20:49:14', '2024-03-25 20:49:14', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/theatrum2.jpg', 0, 'attachment', 'image/jpeg', 0),
(107, 1, '2024-03-25 20:49:15', '2024-03-25 20:49:15', '', 'theatrum3', '', 'inherit', 'open', 'closed', '', 'theatrum3', '', '', '2024-03-25 20:49:15', '2024-03-25 20:49:15', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/theatrum3.jpg', 0, 'attachment', 'image/jpeg', 0),
(108, 1, '2024-03-25 20:49:15', '2024-03-25 20:49:15', '', 'Theatrvm-orbis-terrarvm', '', 'inherit', 'open', 'closed', '', 'theatrvm-orbis-terrarvm', '', '', '2024-03-25 20:49:15', '2024-03-25 20:49:15', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/Theatrvm-orbis-terrarvm.png', 0, 'attachment', 'image/png', 0),
(109, 1, '2024-03-25 20:49:17', '2024-03-25 20:49:17', '', 'Typvs-orbis-terrarvm', '', 'inherit', 'open', 'closed', '', 'typvs-orbis-terrarvm', '', '', '2024-03-25 20:49:17', '2024-03-25 20:49:17', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/Typvs-orbis-terrarvm.png', 0, 'attachment', 'image/png', 0),
(110, 1, '2024-03-25 20:49:19', '2024-03-25 20:49:19', '', 'under-the-dock', '', 'inherit', 'open', 'closed', '', 'under-the-dock', '', '', '2024-03-25 20:49:19', '2024-03-25 20:49:19', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/under-the-dock.jpg', 0, 'attachment', 'image/jpeg', 0),
(111, 1, '2024-03-25 20:49:23', '2024-03-25 20:49:23', '', 'audiencehands', '', 'inherit', 'open', 'closed', '', 'audiencehands', '', '', '2024-03-25 20:49:23', '2024-03-25 20:49:23', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/audiencehands.png', 0, 'attachment', 'image/png', 0),
(112, 1, '2024-03-25 20:49:23', '2024-03-25 20:49:23', '', 'greek-theatre', '', 'inherit', 'open', 'closed', '', 'greek-theatre', '', '', '2024-03-25 20:49:23', '2024-03-25 20:49:23', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/greek-theatre.jpg', 0, 'attachment', 'image/jpeg', 0) ;
INSERT INTO `tu_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(113, 1, '2024-03-25 20:55:49', '2024-03-25 20:55:49', 'https://theatrum.ssl/wp-content/uploads/2024/03/wp-migrate-db-pro.zip', 'wp-migrate-db-pro.zip', '', 'private', 'open', 'closed', '', 'wp-migrate-db-pro-zip', '', '', '2024-03-25 20:55:49', '2024-03-25 20:55:49', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/wp-migrate-db-pro.zip', 0, 'attachment', '', 0),
(114, 1, '2024-03-25 20:57:22', '2024-03-25 20:57:22', 'https://theatrum.ssl/wp-content/uploads/2024/03/wp-migrate-db-pro-2.6.12.zip', 'wp-migrate-db-pro-2.6.12.zip', '', 'private', 'open', 'closed', '', 'wp-migrate-db-pro-2-6-12-zip', '', '', '2024-03-25 20:57:22', '2024-03-25 20:57:22', '', 0, 'https://theatrum.ssl/wp-content/uploads/2024/03/wp-migrate-db-pro-2.6.12.zip', 0, 'attachment', '', 0) ;

#
# End of data contents of table `tu_posts`
# --------------------------------------------------------



#
# Delete any existing table `tu_registration_log`
#

DROP TABLE IF EXISTS `tu_registration_log`;


#
# Table structure of table `tu_registration_log`
#

CREATE TABLE `tu_registration_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `IP` varchar(30) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `IP` (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_registration_log`
#

#
# End of data contents of table `tu_registration_log`
# --------------------------------------------------------



#
# Delete any existing table `tu_signups`
#

DROP TABLE IF EXISTS `tu_signups`;


#
# Table structure of table `tu_signups`
#

CREATE TABLE `tu_signups` (
  `signup_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `activation_key` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `meta` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`signup_id`),
  KEY `activation_key` (`activation_key`),
  KEY `user_email` (`user_email`),
  KEY `user_login_email` (`user_login`,`user_email`),
  KEY `domain_path` (`domain`(140),`path`(51))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_signups`
#

#
# End of data contents of table `tu_signups`
# --------------------------------------------------------



#
# Delete any existing table `tu_site`
#

DROP TABLE IF EXISTS `tu_site`;


#
# Table structure of table `tu_site`
#

CREATE TABLE `tu_site` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `domain` (`domain`(140),`path`(51))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_site`
#
INSERT INTO `tu_site` ( `id`, `domain`, `path`) VALUES
(1, 'theatrum.ssl', '/') ;

#
# End of data contents of table `tu_site`
# --------------------------------------------------------



#
# Delete any existing table `tu_sitemeta`
#

DROP TABLE IF EXISTS `tu_sitemeta`;


#
# Table structure of table `tu_sitemeta`
#

CREATE TABLE `tu_sitemeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_sitemeta`
#
INSERT INTO `tu_sitemeta` ( `meta_id`, `site_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'site_name', 'Theatrum Universum'),
(2, 1, 'admin_email', 'anna@theatrummundi.co'),
(3, 1, 'admin_user_id', '1'),
(4, 1, 'registration', 'none'),
(5, 1, 'upload_filetypes', 'jpg jpeg png gif webp mov avi mpg 3gp 3g2 midi mid pdf doc ppt odt pptx docx pps ppsx xls xlsx key mp3 ogg flac m4a wav mp4 m4v webm ogv flv'),
(6, 1, 'blog_upload_space', '1000'),
(7, 1, 'fileupload_maxk', '100000'),
(8, 1, 'site_admins', 'a:1:{i:0;s:14:"theatrum-admin";}'),
(9, 1, 'allowedthemes', 'a:3:{s:16:"twentytwentyfour";b:1;s:15:"naked-wordpress";b:1;s:20:"theatrum-fundamentum";b:1;}'),
(10, 1, 'illegal_names', 'a:9:{i:0;s:3:"www";i:1;s:3:"web";i:2;s:4:"root";i:3;s:5:"admin";i:4;s:4:"main";i:5;s:6:"invite";i:6;s:13:"administrator";i:7;s:5:"files";i:8;s:4:"blog";}'),
(11, 1, 'wpmu_upgrade_site', '56657'),
(12, 1, 'welcome_email', 'Howdy USERNAME,\r\n\r\nYour new SITE_NAME site has been successfully set up at:\r\nBLOG_URL\r\n\r\nYou can log in to the administrator account with the following information:\r\n\r\nUsername: USERNAME\r\nPassword: PASSWORD\r\nLog in here: BLOG_URLwp-login.php\r\n\r\nWe hope you enjoy your new site. Thanks!\r\n\r\n--The Team @ SITE_NAME'),
(13, 1, 'first_post', 'Welcome to %s. This is your first post. Edit or delete it, then start writing!'),
(14, 1, 'siteurl', 'https://theatrum.ssl/'),
(15, 1, 'add_new_users', '0'),
(16, 1, 'upload_space_check_disabled', '0'),
(17, 1, 'subdomain_install', ''),
(18, 1, 'ms_files_rewriting', '0'),
(19, 1, 'user_count', '1'),
(20, 1, 'initial_db_version', '56657'),
(21, 1, 'active_sitewide_plugins', 'a:11:{s:31:"query-monitor/query-monitor.php";i:1711400285;s:35:"code-snippets-pro/code-snippets.php";i:1711389973;s:34:"advanced-custom-fields-pro/acf.php";i:1711389968;s:53:"advanced-database-cleaner-pro/advanced-db-cleaner.php";i:1711389968;s:51:"all-in-one-wp-security-and-firewall/wp-security.php";i:1711389971;s:29:"health-check/health-check.php";i:1711389973;s:35:"litespeed-cache/litespeed-cache.php";i:1711389973;s:31:"media-cleaner/media-cleaner.php";i:1711389973;s:33:"media-library-assistant/index.php";i:1711389973;s:37:"notion-wp-sync-pro/notion-wp-sync.php";i:1711389974;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";i:1711400285;}'),
(22, 1, 'WPLANG', ''),
(23, 1, 'main_site', '1'),
(33, 1, 'wp_force_deactivated_plugins', 'a:0:{}'),
(34, 1, 'blog_count', '1'),
(36, 1, 'can_compress_scripts', '1'),
(55, 1, 'recently_activated', 'a:7:{s:23:"wp-dark-mode/plugin.php";i:1711390272;s:51:"all-in-one-wp-migration/all-in-one-wp-migration.php";i:1711390238;s:62:"all-in-one-wp-security-and-firewall-premium/aiowps-premium.php";i:1711390235;s:27:"woocommerce/woocommerce.php";i:1711390129;s:47:"all-in-one-seo-pack-pro/all_in_one_seo_pack.php";i:1711390122;s:31:"wp-migrate-db/wp-migrate-db.php";i:1711390116;s:32:"wp-dark-mode-ultimate/plugin.php";i:1711390112;}'),
(56, 1, 'aios_antibot_key_map_info', 'a:2:{i:0;a:4:{i:0;a:2:{i:0;s:8:"vqfcjsjb";i:1;s:12:"hpxzcq70su91";}i:1;a:2:{i:0;s:8:"eni052xk";i:1;s:12:"cqgdl6vdii02";}i:2;a:2:{i:0;s:8:"zejm9iy8";i:1;s:12:"as80xff6v8n1";}i:3;a:2:{i:0;s:8:"4g2gx68x";i:1;s:12:"ts43ayff8d1d";}}i:1;a:3:{i:0;a:2:{i:0;s:8:"4cdca77g";i:1;s:12:"bxi56bdw0k5p";}i:1;a:2:{i:0;s:8:"m8ekz7mz";i:1;s:12:"2i3hdkfmvve9";}i:2;a:2:{i:0;s:8:"fmhmt7yo";i:1;s:12:"kdhquwidxlhe";}}}'),
(57, 1, 'aiowps_premium_configs', 'a:17:{s:33:"aiowps_cb_enable_country_blocking";s:0:"";s:25:"aiowps_cb_blocking_action";s:8:"redirect";s:27:"aiowps_cb_blocked_countries";s:0:"";s:43:"aiowps_cb_enable_secondary_country_blocking";s:0:"";s:35:"aiowps_cb_secondary_blocking_action";s:8:"redirect";s:32:"aiowps_cb_secondary_redirect_url";s:16:"http://127.0.0.1";s:38:"aiowps_secondary_cb_protected_post_ids";s:0:"";s:37:"aiowps_cb_secondary_blocked_countries";s:0:"";s:22:"aiowps_cb_ajax_enabled";s:0:"";s:28:"smart_404_all_time_404_count";s:0:"";s:23:"aiowps_enable_smart_404";s:0:"";s:23:"aiowps_max_404_attempts";s:2:"10";s:28:"aiowps_404_retry_time_period";s:2:"10";s:38:"aiowps_enable_instant_404_string_block";s:0:"";s:31:"smart_404_instant_block_strings";s:0:"";s:26:"enable_smart_404_whitelist";s:0:"";s:22:"smart_404_ip_whitelist";s:0:"";}'),
(58, 1, 'fs_accounts', 'a:9:{s:21:"id_slug_type_path_map";a:1:{i:10565;a:3:{s:4:"slug";s:13:"code-snippets";s:4:"type";s:6:"plugin";s:4:"path";s:35:"code-snippets-pro/code-snippets.php";}}s:11:"plugin_data";a:1:{s:13:"code-snippets";a:28:{s:16:"plugin_main_file";O:8:"stdClass":1:{s:4:"path";s:35:"code-snippets-pro/code-snippets.php";}s:20:"is_network_activated";b:1;s:17:"install_timestamp";i:1711389972;s:17:"was_plugin_loaded";b:1;s:21:"is_plugin_new_install";b:1;s:16:"sdk_last_version";N;s:11:"sdk_version";s:6:"2.5.12";s:16:"sdk_upgrade_mode";b:1;s:18:"sdk_downgrade_mode";b:0;s:19:"plugin_last_version";N;s:14:"plugin_version";s:5:"3.6.4";s:19:"plugin_upgrade_mode";b:1;s:21:"plugin_downgrade_mode";b:0;s:17:"connectivity_test";a:6:{s:12:"is_connected";b:1;s:4:"host";s:12:"theatrum.ssl";s:9:"server_ip";s:9:"127.0.0.1";s:9:"is_active";b:1;s:9:"timestamp";i:1711390055;s:7:"version";s:5:"3.6.4";}s:15:"prev_is_premium";b:1;s:30:"is_diagnostic_tracking_allowed";b:1;s:30:"is_extensions_tracking_allowed";b:0;s:14:"has_trial_plan";b:0;s:15:"network_user_id";s:7:"6928503";s:23:"network_install_blog_id";s:1:"1";s:20:"is_network_connected";b:1;s:19:"keepalive_timestamp";i:1711390057;s:16:"last_license_key";s:32:"34cd4f9aa5087cbb0dbcc9de88401fdf";s:20:"last_license_user_id";N;s:15:"is_whitelabeled";b:0;s:20:"activation_timestamp";i:1711390055;s:13:"subscriptions";a:1:{i:0;O:15:"FS_Subscription":21:{s:2:"id";s:6:"453993";s:7:"updated";s:19:"2024-01-07 02:10:24";s:7:"created";s:19:"2024-01-07 02:10:15";s:22:"\0FS_Entity\0_is_updated";b:0;s:7:"user_id";s:7:"6928503";s:10:"install_id";s:8:"14004077";s:7:"plan_id";s:5:"17873";s:10:"license_id";s:7:"1222111";s:11:"total_gross";d:66.0199999999999960209606797434389591217041015625;s:16:"amount_per_cycle";d:119.900000000000005684341886080801486968994140625;s:13:"billing_cycle";i:12;s:19:"outstanding_balance";i:0;s:15:"failed_payments";i:0;s:7:"gateway";s:6:"stripe";s:11:"external_id";s:28:"sub_1OVloXFmXz63vF5vAC0fkqE1";s:10:"trial_ends";N;s:12:"next_payment";s:19:"2025-01-07 02:10:13";s:11:"canceled_at";N;s:6:"vat_id";N;s:12:"country_code";s:2:"us";s:11:"_is_updated";b:0;}}s:9:"sync_cron";O:8:"stdClass":5:{s:7:"version";s:5:"3.6.4";s:7:"blog_id";s:1:"1";s:11:"sdk_version";s:6:"2.5.12";s:9:"timestamp";i:1711390063;s:2:"on";b:1;}}}s:13:"file_slug_map";a:1:{s:35:"code-snippets-pro/code-snippets.php";s:13:"code-snippets";}s:7:"plugins";a:1:{s:13:"code-snippets";O:9:"FS_Plugin":25:{s:2:"id";i:10565;s:7:"updated";N;s:7:"created";N;s:22:"\0FS_Entity\0_is_updated";b:0;s:10:"public_key";s:32:"pk_107ff34fc0b2a9700c150c1acf13a";s:10:"secret_key";N;s:16:"parent_plugin_id";N;s:5:"title";s:27:"Code Snippets Pro (Premium)";s:4:"slug";s:13:"code-snippets";s:12:"premium_slug";s:17:"code-snippets-pro";s:4:"type";s:6:"plugin";s:20:"affiliate_moderation";s:8:"selected";s:19:"is_wp_org_compliant";b:1;s:22:"premium_releases_count";N;s:4:"file";s:35:"code-snippets-pro/code-snippets.php";s:7:"version";s:5:"3.6.4";s:11:"auto_update";N;s:4:"info";N;s:10:"is_premium";b:1;s:14:"premium_suffix";s:3:"Pro";s:7:"is_live";b:1;s:9:"bundle_id";N;s:17:"bundle_public_key";N;s:17:"opt_in_moderation";N;s:11:"_is_updated";b:0;}}s:7:"updates";a:1:{i:10565;N;}s:5:"users";a:1:{i:6928503;O:7:"FS_User":13:{s:2:"id";s:7:"6928503";s:7:"updated";s:19:"2024-01-21 22:41:42";s:7:"created";s:19:"2023-04-21 19:46:04";s:22:"\0FS_Entity\0_is_updated";b:0;s:10:"public_key";s:32:"pk_74224a00e9c37f53da853f4a419a6";s:10:"secret_key";s:32:"sk_1%ihB;Z2B^k:%RUOXo!+F##]YGq$4";s:5:"email";s:24:"annajennings28@gmail.com";s:5:"first";s:5:"Admin";s:4:"last";s:0:"";s:11:"is_verified";b:1;s:11:"customer_id";N;s:5:"gross";N;s:11:"_is_updated";b:0;}}s:5:"plans";a:1:{s:13:"code-snippets";a:2:{i:0;O:14:"FS_Plugin_Plan":22:{s:2:"id";s:8:"MTc5MDA=";s:7:"updated";s:28:"MjAyMi0wNi0yNyAxNzo0Mjo1Nw==";s:7:"created";s:28:"MjAyMi0wNi0yNyAxNzozOTozNw==";s:22:"\0FS_Entity\0_is_updated";b:0;s:9:"plugin_id";s:8:"MTA1NjU=";s:4:"name";s:8:"ZnJlZQ==";s:5:"title";s:8:"RnJlZQ==";s:11:"description";s:8:"RnJlZQ==";s:17:"is_free_localhost";s:4:"MQ==";s:17:"is_block_features";s:4:"MQ==";s:12:"license_type";s:4:"MA==";s:16:"is_https_support";s:0:"";s:12:"trial_period";N;s:23:"is_require_subscription";s:0:"";s:10:"support_kb";s:40:"aHR0cHM6Ly9oZWxwLmNvZGVzbmlwcGV0cy5wcm8v";s:13:"support_forum";s:68:"aHR0cHM6Ly93d3cuZmFjZWJvb2suY29tL2dyb3Vwcy9jb2Rlc25pcHBldHNwbHVnaW4v";s:13:"support_email";N;s:13:"support_phone";N;s:13:"support_skype";N;s:18:"is_success_manager";s:0:"";s:11:"is_featured";s:0:"";s:11:"_is_updated";b:0;}i:1;O:14:"FS_Plugin_Plan":22:{s:2:"id";s:8:"MTc4NzM=";s:7:"updated";s:28:"MjAyMi0wNi0zMCAxNzoxMjoyNQ==";s:7:"created";s:28:"MjAyMi0wNi0yNSAxNDowMjozNg==";s:22:"\0FS_Entity\0_is_updated";b:0;s:9:"plugin_id";s:8:"MTA1NjU=";s:4:"name";s:4:"cHJv";s:5:"title";s:4:"UHJv";s:11:"description";s:24:"Q29kZSBTbmlwcGV0cyBQcm8=";s:17:"is_free_localhost";s:4:"MQ==";s:17:"is_block_features";s:4:"MQ==";s:12:"license_type";s:4:"MA==";s:16:"is_https_support";s:0:"";s:12:"trial_period";N;s:23:"is_require_subscription";s:0:"";s:10:"support_kb";s:40:"aHR0cHM6Ly9oZWxwLmNvZGVzbmlwcGV0cy5wcm8=";s:13:"support_forum";s:68:"aHR0cHM6Ly93d3cuZmFjZWJvb2suY29tL2dyb3Vwcy9jb2Rlc25pcHBldHNwbHVnaW4=";s:13:"support_email";s:28:"dGVhbUBjb2Rlc25pcHBldHMucHJv";s:13:"support_phone";N;s:13:"support_skype";N;s:18:"is_success_manager";s:0:"";s:11:"is_featured";s:4:"MQ==";s:11:"_is_updated";b:0;}}}s:23:"user_id_license_ids_map";a:1:{i:10565;a:1:{i:6928503;a:1:{i:0;i:1222111;}}}s:12:"all_licenses";a:1:{i:10565;a:2:{i:0;O:17:"FS_Plugin_License":22:{s:2:"id";s:7:"1222111";s:7:"updated";s:19:"2024-03-25 18:07:36";s:7:"created";s:19:"2023-10-18 18:00:01";s:22:"\0FS_Entity\0_is_updated";b:0;s:9:"plugin_id";s:5:"10565";s:7:"user_id";s:7:"6928503";s:7:"plan_id";s:5:"17873";s:16:"parent_plan_name";N;s:17:"parent_plan_title";N;s:17:"parent_license_id";N;s:8:"products";N;s:10:"pricing_id";s:5:"20174";s:5:"quota";i:200;s:9:"activated";i:19;s:15:"activated_local";i:1;s:10:"expiration";s:19:"2025-01-08 02:10:13";s:10:"secret_key";s:32:"sk_2GMk+3yVMmU?Umo!cnF~et%g9I:az";s:15:"is_whitelabeled";b:0;s:17:"is_free_localhost";b:1;s:17:"is_block_features";b:1;s:12:"is_cancelled";b:0;s:11:"_is_updated";b:0;}i:1;O:17:"FS_Plugin_License":22:{s:2:"id";s:7:"1222111";s:7:"updated";s:19:"2024-03-25 18:07:36";s:7:"created";s:19:"2023-10-18 18:00:01";s:22:"\0FS_Entity\0_is_updated";b:0;s:9:"plugin_id";s:5:"10565";s:7:"user_id";s:7:"6928503";s:7:"plan_id";s:5:"17873";s:16:"parent_plan_name";N;s:17:"parent_plan_title";N;s:17:"parent_license_id";N;s:8:"products";N;s:10:"pricing_id";s:5:"20174";s:5:"quota";i:200;s:9:"activated";i:19;s:15:"activated_local";i:1;s:10:"expiration";s:19:"2025-01-08 02:10:13";s:10:"secret_key";s:32:"sk_2GMk+3yVMmU?Umo!cnF~et%g9I:az";s:15:"is_whitelabeled";b:0;s:17:"is_free_localhost";b:1;s:17:"is_block_features";b:1;s:12:"is_cancelled";b:0;s:11:"_is_updated";b:0;}}}}'),
(59, 1, 'fs_api_cache', 'a:6:{s:26:"get:/v1/users/6928503.json";O:8:"stdClass":3:{s:6:"result";O:8:"stdClass":10:{s:5:"email";s:24:"annajennings28@gmail.com";s:5:"first";s:5:"Admin";s:4:"last";s:0:"";s:11:"is_verified";b:1;s:4:"auth";s:8:"password";s:10:"secret_key";s:32:"sk_1%ihB;Z2B^k:%RUOXo!+F##]YGq$4";s:10:"public_key";s:32:"pk_74224a00e9c37f53da853f4a419a6";s:2:"id";s:7:"6928503";s:7:"created";s:19:"2023-04-21 19:46:04";s:7:"updated";s:19:"2024-01-21 22:41:42";}s:7:"created";i:1711390055;s:9:"timestamp";i:1711476455;}s:62:"get:/v1/users/6928503/plugins/10565/installs.json?ids=14660112";O:8:"stdClass":3:{s:6:"result";O:8:"stdClass":1:{s:8:"installs";a:1:{i:0;O:8:"stdClass":32:{s:7:"site_id";s:9:"222855152";s:9:"plugin_id";s:5:"10565";s:7:"user_id";s:7:"6928503";s:3:"url";s:20:"https://theatrum.ssl";s:5:"title";s:14:"Theatrum Mundi";s:7:"version";s:5:"3.6.4";s:7:"plan_id";s:5:"17873";s:10:"license_id";s:7:"1222111";s:13:"trial_plan_id";N;s:10:"trial_ends";N;s:15:"subscription_id";s:6:"453993";s:5:"gross";i:0;s:12:"country_code";s:2:"us";s:8:"language";s:5:"en-US";s:16:"platform_version";s:5:"6.4.3";s:11:"sdk_version";s:6:"2.5.12";s:28:"programming_language_version";s:5:"8.2.2";s:9:"is_active";b:1;s:15:"is_disconnected";b:0;s:10:"is_premium";b:1;s:14:"is_uninstalled";b:0;s:9:"is_locked";b:0;s:6:"source";i:0;s:8:"upgraded";N;s:12:"last_seen_at";N;s:26:"last_served_update_version";N;s:10:"secret_key";s:32:"sk_DJuVxrJ_[[$t4#;0q]sL1r8n&D[Ou";s:10:"public_key";s:32:"pk_8361624f53705c0205f921e774970";s:2:"id";s:8:"14660112";s:7:"created";s:19:"2024-03-25 18:07:36";s:7:"updated";s:19:"2024-03-25 18:07:36";s:7:"charset";N;}}}s:7:"created";i:1711390055;s:9:"timestamp";i:1711476455;}s:46:"get:/v1/users/6928503/plugins/10565/plans.json";O:8:"stdClass":3:{s:6:"result";O:8:"stdClass":1:{s:5:"plans";a:2:{i:0;O:14:"FS_Plugin_Plan":22:{s:2:"id";s:5:"17900";s:7:"updated";s:19:"2022-06-27 17:42:57";s:7:"created";s:19:"2022-06-27 17:39:37";s:22:"\0FS_Entity\0_is_updated";b:0;s:9:"plugin_id";s:5:"10565";s:4:"name";s:4:"free";s:5:"title";s:4:"Free";s:11:"description";s:4:"Free";s:17:"is_free_localhost";b:1;s:17:"is_block_features";b:1;s:12:"license_type";i:0;s:16:"is_https_support";b:0;s:12:"trial_period";N;s:23:"is_require_subscription";b:0;s:10:"support_kb";s:30:"https://help.codesnippets.pro/";s:13:"support_forum";s:51:"https://www.facebook.com/groups/codesnippetsplugin/";s:13:"support_email";N;s:13:"support_phone";N;s:13:"support_skype";N;s:18:"is_success_manager";b:0;s:11:"is_featured";b:0;s:11:"_is_updated";b:0;}i:1;O:14:"FS_Plugin_Plan":22:{s:2:"id";s:5:"17873";s:7:"updated";s:19:"2022-06-30 17:12:25";s:7:"created";s:19:"2022-06-25 14:02:36";s:22:"\0FS_Entity\0_is_updated";b:0;s:9:"plugin_id";s:5:"10565";s:4:"name";s:3:"pro";s:5:"title";s:3:"Pro";s:11:"description";s:17:"Code Snippets Pro";s:17:"is_free_localhost";b:1;s:17:"is_block_features";b:1;s:12:"license_type";i:0;s:16:"is_https_support";b:0;s:12:"trial_period";N;s:23:"is_require_subscription";b:0;s:10:"support_kb";s:29:"https://help.codesnippets.pro";s:13:"support_forum";s:50:"https://www.facebook.com/groups/codesnippetsplugin";s:13:"support_email";s:21:"team@codesnippets.pro";s:13:"support_phone";N;s:13:"support_skype";N;s:18:"is_success_manager";b:0;s:11:"is_featured";b:1;s:11:"_is_updated";b:0;}}}s:7:"created";i:1711390055;s:9:"timestamp";i:1711476455;}s:66:"get:/v1/users/6928503/plugins/10565/licenses.json?is_enriched=true";O:8:"stdClass":3:{s:6:"result";O:8:"stdClass":1:{s:8:"licenses";a:2:{i:0;O:17:"FS_Plugin_License":22:{s:2:"id";s:7:"1222111";s:7:"updated";s:19:"2024-03-25 18:07:36";s:7:"created";s:19:"2023-10-18 18:00:01";s:22:"\0FS_Entity\0_is_updated";b:0;s:9:"plugin_id";s:5:"10565";s:7:"user_id";s:7:"6928503";s:7:"plan_id";s:5:"17873";s:16:"parent_plan_name";N;s:17:"parent_plan_title";N;s:17:"parent_license_id";N;s:8:"products";N;s:10:"pricing_id";s:5:"20174";s:5:"quota";i:200;s:9:"activated";i:19;s:15:"activated_local";i:1;s:10:"expiration";s:19:"2025-01-08 02:10:13";s:10:"secret_key";s:32:"sk_2GMk+3yVMmU?Umo!cnF~et%g9I:az";s:15:"is_whitelabeled";b:0;s:17:"is_free_localhost";b:1;s:17:"is_block_features";b:1;s:12:"is_cancelled";b:0;s:11:"_is_updated";b:0;}i:1;O:17:"FS_Plugin_License":22:{s:2:"id";s:7:"1222111";s:7:"updated";s:19:"2024-03-25 18:07:36";s:7:"created";s:19:"2023-10-18 18:00:01";s:22:"\0FS_Entity\0_is_updated";b:0;s:9:"plugin_id";s:5:"10565";s:7:"user_id";s:7:"6928503";s:7:"plan_id";s:5:"17873";s:16:"parent_plan_name";N;s:17:"parent_plan_title";N;s:17:"parent_license_id";N;s:8:"products";N;s:10:"pricing_id";s:5:"20174";s:5:"quota";i:200;s:9:"activated";i:19;s:15:"activated_local";i:1;s:10:"expiration";s:19:"2025-01-08 02:10:13";s:10:"secret_key";s:32:"sk_2GMk+3yVMmU?Umo!cnF~et%g9I:az";s:15:"is_whitelabeled";b:0;s:17:"is_free_localhost";b:1;s:17:"is_block_features";b:1;s:12:"is_cancelled";b:0;s:11:"_is_updated";b:0;}}}s:7:"created";i:1711390055;s:9:"timestamp";i:1711476455;}s:61:"get:/v1/installs/14660112/licenses/1222111/subscriptions.json";O:8:"stdClass":3:{s:6:"result";O:8:"stdClass":1:{s:13:"subscriptions";a:2:{i:0;O:8:"stdClass":33:{s:8:"tax_rate";i:0;s:11:"total_gross";d:66.0199999999999960209606797434389591217041015625;s:16:"amount_per_cycle";d:119.900000000000005684341886080801486968994140625;s:14:"initial_amount";d:66.0199999999999960209606797434389591217041015625;s:14:"renewal_amount";d:119.900000000000005684341886080801486968994140625;s:17:"renewals_discount";N;s:22:"renewals_discount_type";s:10:"percentage";s:13:"billing_cycle";i:12;s:19:"outstanding_balance";i:0;s:15:"failed_payments";i:0;s:10:"trial_ends";N;s:12:"next_payment";s:19:"2025-01-07 02:10:13";s:11:"canceled_at";N;s:7:"user_id";s:7:"6928503";s:10:"install_id";s:8:"14004077";s:7:"plan_id";s:5:"17873";s:10:"pricing_id";s:5:"20174";s:10:"license_id";s:7:"1222111";s:2:"ip";s:15:"172.116.247.151";s:12:"country_code";s:2:"us";s:15:"zip_postal_code";i:92701;s:6:"vat_id";N;s:9:"coupon_id";N;s:12:"user_card_id";s:6:"413770";s:6:"source";i:0;s:9:"plugin_id";s:5:"10565";s:11:"external_id";s:28:"sub_1OVloXFmXz63vF5vAC0fkqE1";s:7:"gateway";s:6:"stripe";s:11:"environment";i:0;s:2:"id";s:6:"453993";s:7:"created";s:19:"2024-01-07 02:10:15";s:7:"updated";s:19:"2024-01-07 02:10:24";s:8:"currency";s:3:"usd";}i:1;O:8:"stdClass":33:{s:8:"tax_rate";i:0;s:11:"total_gross";i:69;s:16:"amount_per_cycle";i:69;s:14:"initial_amount";i:69;s:14:"renewal_amount";i:69;s:17:"renewals_discount";N;s:22:"renewals_discount_type";s:10:"percentage";s:13:"billing_cycle";i:12;s:19:"outstanding_balance";i:0;s:15:"failed_payments";i:0;s:10:"trial_ends";N;s:12:"next_payment";s:19:"2024-10-18 17:59:58";s:11:"canceled_at";s:19:"2024-01-07 02:10:11";s:7:"user_id";s:7:"6928503";s:10:"install_id";s:8:"13367068";s:7:"plan_id";s:5:"17873";s:10:"pricing_id";s:5:"20173";s:10:"license_id";s:7:"1222111";s:2:"ip";s:14:"23.243.193.185";s:12:"country_code";s:2:"us";s:15:"zip_postal_code";i:92701;s:6:"vat_id";N;s:9:"coupon_id";N;s:12:"user_card_id";s:6:"390343";s:6:"source";i:0;s:9:"plugin_id";s:5:"10565";s:11:"external_id";s:28:"sub_1O2e2EFmXz63vF5vkbxJtJC5";s:7:"gateway";s:6:"stripe";s:11:"environment";i:0;s:2:"id";s:6:"430872";s:7:"created";s:19:"2023-10-18 18:00:01";s:7:"updated";s:19:"2024-01-07 02:10:11";s:8:"currency";s:3:"usd";}}}s:7:"created";i:1711390055;s:9:"timestamp";i:1711476455;}s:90:"get:/v1/installs/14660112/updates/latest.json?is_premium=true&newer_than=3.6.4&readme=true";O:8:"stdClass":3:{s:6:"result";O:8:"stdClass":1:{s:5:"error";O:8:"stdClass":3:{s:7:"message";s:40:"There\'s no newer release of the product.";s:4:"code";s:23:"newer_version_not_found";s:4:"http";i:404;}}s:7:"created";i:1711399830;s:9:"timestamp";i:1711401630;}}'),
(62, 1, 'litespeed.conf._version', '6.1'),
(63, 1, 'litespeed.conf.cache', ''),
(64, 1, 'litespeed.conf.use_primary_settings', ''),
(65, 1, 'litespeed.conf.auto_upgrade', ''),
(66, 1, 'litespeed.conf.guest', ''),
(67, 1, 'litespeed.conf.cache-favicon', '1'),
(68, 1, 'litespeed.conf.cache-resources', '1'),
(69, 1, 'litespeed.conf.cache-browser', ''),
(70, 1, 'litespeed.conf.cache-mobile', ''),
(71, 1, 'litespeed.conf.cache-mobile_rules', '["Mobile","Android","Silk\\/","Kindle","BlackBerry","Opera Mini","Opera Mobi"]'),
(72, 1, 'litespeed.conf.cache-login_cookie', ''),
(73, 1, 'litespeed.conf.cache-vary_cookies', '[]'),
(74, 1, 'litespeed.conf.cache-exc_cookies', '[]'),
(75, 1, 'litespeed.conf.cache-exc_useragents', '[]'),
(76, 1, 'litespeed.conf.cache-ttl_browser', '31557600'),
(77, 1, 'litespeed.conf.purge-upgrade', '1'),
(78, 1, 'litespeed.conf.object', ''),
(79, 1, 'litespeed.conf.object-kind', ''),
(80, 1, 'litespeed.conf.object-host', 'localhost'),
(81, 1, 'litespeed.conf.object-port', '11211'),
(82, 1, 'litespeed.conf.object-life', '360'),
(83, 1, 'litespeed.conf.object-persistent', '1'),
(84, 1, 'litespeed.conf.object-admin', '1'),
(85, 1, 'litespeed.conf.object-transients', '1'),
(86, 1, 'litespeed.conf.object-db_id', '0'),
(87, 1, 'litespeed.conf.object-user', ''),
(88, 1, 'litespeed.conf.object-pswd', ''),
(89, 1, 'litespeed.conf.object-global_groups', '["users","userlogins","usermeta","user_meta","useremail","userslugs","sites","site-details","site-transient","site-options","site-lookup","blog-lookup","blog-id-cache","blog-details","networks","rss","global-posts","global-cache-test"]'),
(90, 1, 'litespeed.conf.object-non_persistent_groups', '["comment","counts","plugins"]'),
(91, 1, 'litespeed.conf.debug-disable_all', ''),
(92, 1, 'litespeed.conf.debug', ''),
(93, 1, 'litespeed.conf.debug-ips', '["127.0.0.1"]'),
(94, 1, 'litespeed.conf.debug-level', ''),
(95, 1, 'litespeed.conf.debug-filesize', '3'),
(96, 1, 'litespeed.conf.debug-cookie', ''),
(97, 1, 'litespeed.conf.debug-collaps_qs', ''),
(98, 1, 'litespeed.conf.debug-inc', '[]'),
(99, 1, 'litespeed.conf.debug-exc', '[]'),
(100, 1, 'litespeed.conf.debug-exc_strings', '[]'),
(101, 1, 'litespeed.conf.img_optm-webp', ''),
(102, 1, 'code_snippets_version', '3.6.4'),
(103, 1, 'all-in-one-wp-security-and-firewall-premium_updater_options', 'a:2:{s:20:"wp55_option_migrated";b:1;s:14:"site_host_path";s:13:"theatrum.ssl/";}'),
(104, 1, 'auto_update_plugins', 'a:19:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:53:"advanced-database-cleaner-pro/advanced-db-cleaner.php";i:2;s:47:"all-in-one-seo-pack-pro/all_in_one_seo_pack.php";i:3;s:51:"all-in-one-wp-security-and-firewall/wp-security.php";i:4;s:62:"all-in-one-wp-security-and-firewall-premium/aiowps-premium.php";i:5;s:51:"all-in-one-wp-migration/all-in-one-wp-migration.php";i:6;s:35:"code-snippets-pro/code-snippets.php";i:7;s:29:"health-check/health-check.php";i:8;s:35:"litespeed-cache/litespeed-cache.php";i:9;s:31:"media-cleaner/media-cleaner.php";i:10;s:33:"media-library-assistant/index.php";i:11;s:37:"notion-wp-sync-pro/notion-wp-sync.php";i:12;s:31:"query-monitor/query-monitor.php";i:13;s:27:"woocommerce/woocommerce.php";i:14;s:23:"wp-dark-mode/plugin.php";i:15;s:32:"wp-dark-mode-ultimate/plugin.php";i:16;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";i:17;s:31:"wp-migrate-db/wp-migrate-db.php";i:18;s:87:"wp-service-payment-form-with-authorizenet/wp-service-payment-form-with-authorizenet.php";}'),
(108, 1, 'external_updates-all-in-one-wp-security-and-firewall-premium', 'O:8:"stdClass":5:{s:9:"lastCheck";i:1711390025;s:14:"checkedVersion";s:5:"1.0.3";s:6:"update";O:8:"stdClass":13:{s:4:"slug";s:43:"all-in-one-wp-security-and-firewall-premium";s:7:"version";s:5:"1.0.5";s:12:"download_url";N;s:12:"translations";a:0:{}s:2:"id";i:0;s:8:"homepage";s:0:"";s:6:"tested";s:5:"6.4.3";s:12:"requires_php";N;s:14:"upgrade_notice";N;s:5:"icons";a:0:{}s:8:"filename";s:62:"all-in-one-wp-security-and-firewall-premium/aiowps-premium.php";s:24:"x-spm-yourversion-tested";s:3:"6.4";s:25:"x-spm-subscription-active";b:0;}s:11:"updateClass";s:23:"Puc_v4p13_Plugin_Update";s:15:"updateBaseClass";s:13:"Plugin_Update";}'),
(110, 1, 'udmanager_updater_sid', 'a8220035543e840a7ddcaeeeb90f126d'),
(111, 1, 'simba_tfa_priv_key_format', '1'),
(119, 1, 'code_snippets_settings', 'a:3:{s:5:"debug";a:0:{}s:7:"general";a:9:{s:19:"activate_by_default";b:1;s:11:"enable_tags";b:1;s:18:"enable_description";b:1;s:18:"visual_editor_rows";i:5;s:10:"list_order";s:12:"priority-asc";s:13:"disable_prism";b:0;s:13:"minify_output";a:2:{i:0;s:3:"css";i:1;s:2:"js";}s:17:"hide_upgrade_menu";b:0;s:18:"complete_uninstall";b:0;}s:6:"editor";a:11:{s:5:"theme";s:7:"default";s:16:"indent_with_tabs";b:1;s:8:"tab_size";i:4;s:11:"indent_unit";i:4;s:10:"wrap_lines";b:1;s:12:"code_folding";b:1;s:12:"line_numbers";b:1;s:19:"auto_close_brackets";b:1;s:27:"highlight_selection_matches";b:1;s:21:"highlight_active_line";b:1;s:6:"keymap";s:7:"default";}}'),
(120, 1, 'code_snippets_settings', 'a:3:{s:5:"debug";a:0:{}s:7:"general";a:9:{s:19:"activate_by_default";b:1;s:11:"enable_tags";b:1;s:18:"enable_description";b:1;s:18:"visual_editor_rows";i:5;s:10:"list_order";s:12:"priority-asc";s:13:"disable_prism";b:0;s:13:"minify_output";a:2:{i:0;s:3:"css";i:1;s:2:"js";}s:17:"hide_upgrade_menu";b:0;s:18:"complete_uninstall";b:0;}s:6:"editor";a:11:{s:5:"theme";s:7:"default";s:16:"indent_with_tabs";b:1;s:8:"tab_size";i:4;s:11:"indent_unit";i:4;s:10:"wrap_lines";b:1;s:12:"code_folding";b:1;s:12:"line_numbers";b:1;s:19:"auto_close_brackets";b:1;s:27:"highlight_selection_matches";b:1;s:21:"highlight_active_line";b:1;s:6:"keymap";s:7:"default";}}'),
(130, 1, 'recently_activated_snippets', 'a:0:{}'),
(131, 1, 'fs_gdpr', 'a:1:{s:2:"u1";a:1:{s:18:"show_opt_in_notice";b:0;}}'),
(167, 1, 'registrationnotification', 'yes'),
(168, 1, 'welcome_user_email', 'Howdy USERNAME,\r\n\r\nYour new account is set up.\r\n\r\nYou can log in with the following information:\r\nUsername: USERNAME\r\nPassword: PASSWORD\r\nLOGINLINK\r\n\r\nThanks!\r\n\r\n--The Team @ SITE_NAME'),
(169, 1, 'menu_items', 'a:0:{}'),
(170, 1, 'first_page', ''),
(171, 1, 'first_comment', ''),
(172, 1, 'first_comment_url', ''),
(173, 1, 'first_comment_author', ''),
(174, 1, 'limited_email_domains', ''),
(175, 1, 'banned_email_domains', ''),
(176, 1, 'new_admin_email', 'anna@theatrummundi.co'),
(177, 1, 'first_comment_email', ''),
(202, 1, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1711400599;}') ;

#
# End of data contents of table `tu_sitemeta`
# --------------------------------------------------------



#
# Delete any existing table `tu_snippets`
#

DROP TABLE IF EXISTS `tu_snippets`;


#
# Table structure of table `tu_snippets`
#

CREATE TABLE `tu_snippets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `code` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tags` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scope` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'global',
  `priority` smallint(6) NOT NULL DEFAULT '10',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `revision` bigint(20) NOT NULL DEFAULT '1',
  `cloud_id` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scope` (`scope`),
  KEY `active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_snippets`
#

#
# End of data contents of table `tu_snippets`
# --------------------------------------------------------



#
# Delete any existing table `tu_term_relationships`
#

DROP TABLE IF EXISTS `tu_term_relationships`;


#
# Table structure of table `tu_term_relationships`
#

CREATE TABLE `tu_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_term_relationships`
#
INSERT INTO `tu_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(7, 2, 0),
(36, 17, 0),
(37, 17, 0),
(38, 17, 0),
(39, 17, 0),
(64, 19, 0),
(69, 3, 0),
(69, 16, 0),
(70, 3, 0),
(70, 16, 0),
(71, 3, 0),
(71, 16, 0),
(78, 19, 0),
(80, 19, 0),
(80, 20, 0),
(83, 19, 0),
(83, 21, 0) ;

#
# End of data contents of table `tu_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `tu_term_taxonomy`
#

DROP TABLE IF EXISTS `tu_term_taxonomy`;


#
# Table structure of table `tu_term_taxonomy`
#

CREATE TABLE `tu_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_term_taxonomy`
#
INSERT INTO `tu_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'product_type', '', 0, 3),
(4, 4, 'product_type', '', 0, 0),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_type', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_visibility', '', 0, 0),
(16, 16, 'product_cat', '', 0, 3),
(17, 17, 'wp_theme', '', 0, 4),
(19, 19, 'wp_theme', '', 0, 4),
(20, 20, 'wp_template_part_area', '', 0, 1),
(21, 21, 'wp_template_part_area', '', 0, 1) ;

#
# End of data contents of table `tu_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `tu_termmeta`
#

DROP TABLE IF EXISTS `tu_termmeta`;


#
# Table structure of table `tu_termmeta`
#

CREATE TABLE `tu_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_termmeta`
#
INSERT INTO `tu_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 16, 'product_count_product_cat', '3') ;

#
# End of data contents of table `tu_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `tu_terms`
#

DROP TABLE IF EXISTS `tu_terms`;


#
# Table structure of table `tu_terms`
#

CREATE TABLE `tu_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_terms`
#
INSERT INTO `tu_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'twentytwentyfour', 'twentytwentyfour', 0),
(3, 'simple', 'simple', 0),
(4, 'grouped', 'grouped', 0),
(5, 'variable', 'variable', 0),
(6, 'external', 'external', 0),
(7, 'exclude-from-search', 'exclude-from-search', 0),
(8, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(9, 'featured', 'featured', 0),
(10, 'outofstock', 'outofstock', 0),
(11, 'rated-1', 'rated-1', 0),
(12, 'rated-2', 'rated-2', 0),
(13, 'rated-3', 'rated-3', 0),
(14, 'rated-4', 'rated-4', 0),
(15, 'rated-5', 'rated-5', 0),
(16, 'Uncategorized', 'uncategorized', 0),
(17, 'woocommerce/woocommerce', 'woocommerce-woocommerce', 0),
(19, 'theatrum-fundamentum', 'theatrum-fundamentum', 0),
(20, 'header', 'header', 0),
(21, 'footer', 'footer', 0) ;

#
# End of data contents of table `tu_terms`
# --------------------------------------------------------



#
# Delete any existing table `tu_usermeta`
#

DROP TABLE IF EXISTS `tu_usermeta`;


#
# Table structure of table `tu_usermeta`
#

CREATE TABLE `tu_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_usermeta`
#
INSERT INTO `tu_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'theatrum-admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'tu_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'tu_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:3:{s:64:"a8a9c8cb1dcf8aedbb0ed55b3d9408be4b369c652555a766359277a5331afcb4";a:4:{s:10:"expiration";i:1711517289;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36";s:5:"login";i:1711344489;}s:64:"f78664186bc123a7e6917db667dbe491a4f9df8339a36a9975647e9d1c0f60a5";a:4:{s:10:"expiration";i:1711517533;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36";s:5:"login";i:1711344733;}s:64:"6cfce3e22edc0bd928bd6a94fca0ce7dbf20ab30a84573f6dcbd00b92975498a";a:4:{s:10:"expiration";i:1711568307;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36";s:5:"login";i:1711395507;}}'),
(17, 1, 'tu_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'source_domain', 'theatrum.ssl'),
(20, 1, 'primary_blog', '1'),
(21, 1, 'tu_persisted_preferences', 'a:3:{s:14:"core/edit-post";a:3:{s:26:"isComplementaryAreaVisible";b:0;s:12:"welcomeGuide";b:0;s:10:"openPanels";a:3:{i:0;s:11:"post-status";i:1;s:14:"featured-image";i:2;s:15:"page-attributes";}}s:9:"_modified";s:24:"2024-03-25T19:59:50.788Z";s:14:"core/edit-site";a:2:{s:12:"welcomeGuide";b:0;s:26:"isComplementaryAreaVisible";b:1;}}'),
(22, 1, '_woocommerce_tracks_anon_id', 'woo:C0bRyv6FPy9D+w93GFLjL/sk'),
(23, 1, 'tu_user-settings', 'urlbutton=none&libraryContent=upload'),
(24, 1, 'tu_user-settings-time', '1711391881'),
(25, 1, 'manageedit-acf-post-typecolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(26, 1, 'acf_user_settings', 'a:1:{s:19:"post-type-first-run";b:1;}'),
(27, 1, 'closedpostboxes_acf-post-type', 'a:0:{}'),
(28, 1, 'metaboxhidden_acf-post-type', 'a:1:{i:0;s:7:"slugdiv";}'),
(29, 1, 'last_update', '1711396791'),
(30, 1, 'woocommerce_admin_task_list_tracked_started_tasks', '{"products":1}'),
(31, 1, 'meta-box-order_product', 'a:3:{s:4:"side";s:84:"submitdiv,postimagediv,woocommerce-product-images,product_catdiv,tagsdiv-product_tag";s:6:"normal";s:55:"woocommerce-product-data,postcustom,slugdiv,postexcerpt";s:8:"advanced";s:0:"";}'),
(32, 1, 'wc_last_active', '1711324800'),
(34, 1, 'aiowps_last_login_time', '2024-03-25 19:38:27'),
(35, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:"cart";a:0:{}}'),
(36, 1, 'wpmdb_licence_key', '9be594c0-5f77-490f-876a-34cc5cf7a070') ;

#
# End of data contents of table `tu_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `tu_users`
#

DROP TABLE IF EXISTS `tu_users`;


#
# Table structure of table `tu_users`
#

CREATE TABLE `tu_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_users`
#
INSERT INTO `tu_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`, `spam`, `deleted`) VALUES
(1, 'theatrum-admin', '$P$B3YAiCM05/srS6PullyDhnyolm6LnV0', 'theatrum-admin', 'anna@theatrummundi.co', 'https://theatrum.ssl', '2024-03-25 05:27:36', '', 0, 'theatrum-admin', 0, 0) ;

#
# End of data contents of table `tu_users`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_admin_note_actions`
#

DROP TABLE IF EXISTS `tu_wc_admin_note_actions`;


#
# Table structure of table `tu_wc_admin_note_actions`
#

CREATE TABLE `tu_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonce_action` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `nonce_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=896 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_admin_note_actions`
#
INSERT INTO `tu_wc_admin_note_actions` ( `action_id`, `note_id`, `name`, `label`, `query`, `status`, `actioned_text`, `nonce_action`, `nonce_name`) VALUES
(92, 62, 'notify-refund-returns-page', 'Edit page', 'https://theatrum.ssl/wp-admin/post.php?post=35&action=edit', 'actioned', '', NULL, NULL),
(93, 63, 'notify-refund-returns-page', 'Edit page', 'https://theatrum.ssl/wp-admin/post.php?post=35&action=edit', 'actioned', '', NULL, NULL),
(462, 65, 'connect', 'Connect', '?page=wc-addons&section=helper', 'unactioned', '', NULL, NULL),
(801, 1, 'wayflyer_bnpl_q4_2021', 'Level up with funding', 'https://woo.com/products/wayflyer/?utm_source=inbox_note&utm_medium=product&utm_campaign=wayflyer_bnpl_q4_2021', 'actioned', '', NULL, NULL),
(802, 2, 'wc_shipping_mobile_app_usps_q4_2021', 'Get WooCommerce Shipping', 'https://woo.com/woocommerce-shipping/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_usps_q4_2021', 'actioned', '', NULL, NULL),
(803, 3, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox', 'unactioned', '', NULL, NULL),
(804, 4, 'learn-more', 'Learn more', 'https://woo.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'actioned', '', NULL, NULL),
(805, 5, 'optimizing-the-checkout-flow', 'Learn more', 'https://woo.com/posts/optimizing-woocommerce-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=optimizing-the-checkout-flow', 'actioned', '', NULL, NULL),
(806, 6, 'qualitative-feedback-from-new-users', 'Share feedback', 'https://automattic.survey.fm/wc-pay-new', 'actioned', '', NULL, NULL),
(807, 7, 'share-feedback', 'Share feedback', 'http://automattic.survey.fm/paypal-feedback', 'unactioned', '', NULL, NULL),
(808, 8, 'get-started', 'Get started', 'https://woo.com/products/google-listings-and-ads?utm_source=inbox_note&utm_medium=product&utm_campaign=get-started', 'actioned', '', NULL, NULL),
(809, 9, 'update-wc-subscriptions-3-0-15', 'View latest version', 'https://theatrum.ssl/wp-admin/&page=wc-addons&section=helper', 'actioned', '', NULL, NULL),
(810, 10, 'update-wc-core-5-4-0', 'How to update WooCommerce', 'https://docs.woocommerce.com/document/how-to-update-woocommerce/', 'actioned', '', NULL, NULL),
(811, 13, 'ppxo-pps-install-paypal-payments-1', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(812, 14, 'ppxo-pps-install-paypal-payments-2', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(813, 15, 'learn-more', 'Learn more', 'https://woo.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(814, 15, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(815, 16, 'learn-more', 'Learn more', 'https://woo.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(816, 16, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(817, 17, 'learn-more', 'Learn more', 'https://woo.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(818, 17, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(819, 18, 'learn-more', 'Learn more', 'https://woo.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(820, 18, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(821, 19, 'share-feedback', 'Share feedback', 'https://automattic.survey.fm/store-management', 'unactioned', '', NULL, NULL),
(822, 20, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(823, 20, 'woocommerce-core-paypal-march-2022-dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(824, 21, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(825, 21, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(826, 22, 'pinterest_03_2022_update', 'Update Instructions', 'https://woo.com/document/pinterest-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=pinterest_03_2022_update#section-3', 'actioned', '', NULL, NULL),
(827, 23, 'store_setup_survey_survey_q2_2022_share_your_thoughts', 'Tell us how it’s going', 'https://automattic.survey.fm/store-setup-survey-2022', 'actioned', '', NULL, NULL),
(828, 24, 'needs-update-eway-payment-gateway-rin-action-button-2022-12-20', 'See available updates', 'https://theatrum.ssl/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(829, 24, 'needs-update-eway-payment-gateway-rin-dismiss-button-2022-12-20', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(830, 25, 'updated-eway-payment-gateway-rin-action-button-2022-12-20', 'See all updates', 'https://theatrum.ssl/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(831, 25, 'updated-eway-payment-gateway-rin-dismiss-button-2022-12-20', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(832, 26, 'share-navigation-survey-feedback', 'Share feedback', 'https://automattic.survey.fm/new-ecommerce-plan-navigation', 'actioned', '', NULL, NULL),
(833, 27, 'woopay-beta-merchantrecruitment-activate-04MAY23', 'Activate WooPay', 'https://theatrum.ssl/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'actioned', '', NULL, NULL),
(834, 27, 'woopay-beta-merchantrecruitment-activate-learnmore-04MAY23', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-activate-learnmore-04MAY23', 'unactioned', '', NULL, NULL),
(835, 28, 'woocommerce-wcpay-march-2023-update-needed-button', 'See Blog Post', 'https://developer.woocommerce.com/2023/03/23/critical-vulnerability-detected-in-woocommerce-payments-what-you-need-to-know', 'unactioned', '', NULL, NULL),
(836, 28, 'woocommerce-wcpay-march-2023-update-needed-dismiss-button', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(837, 29, 'tap_to_pay_iphone_q2_2023_no_wcpay', 'Simplify my payments', 'https://woo.com/products/woocommerce-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=tap_to_pay_iphone_q2_2023_no_wcpay', 'actioned', '', NULL, NULL),
(838, 30, 'extension-settings', 'See available updates', 'https://theatrum.ssl/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(839, 30, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(840, 31, 'woopay-beta-merchantrecruitment-update-WCPay-04MAY23', 'Update WooCommerce Payments', 'https://theatrum.ssl/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(841, 31, 'woopay-beta-merchantrecruitment-update-activate-04MAY23', 'Activate WooPay', 'https://theatrum.ssl/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'actioned', '', NULL, NULL),
(842, 32, 'woopay-beta-existingmerchants-noaction-documentation-27APR23', 'Documentation', 'https://woo.com/document/woopay-merchant-documentation/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-existingmerchants-noaction-documentation-27APR23', 'actioned', '', NULL, NULL),
(843, 33, 'woopay-beta-existingmerchants-update-WCPay-27APR23', 'Update WooCommerce Payments', 'https://theatrum.ssl/wp-admin/plugins.php?plugin_status=all', 'actioned', '', NULL, NULL),
(844, 34, 'woopay-beta-merchantrecruitment-short-activate-04MAY23', 'Activate WooPay', 'https://theatrum.ssl/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'actioned', '', NULL, NULL),
(845, 34, 'woopay-beta-merchantrecruitment-short-activate-learnmore-04MAY23', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-04MAY23', 'actioned', '', NULL, NULL),
(846, 35, 'woopay-beta-merchantrecruitment-short-update-WCPay-04MAY23', 'Update WooCommerce Payments', 'https://theatrum.ssl/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(847, 35, 'woopay-beta-merchantrecruitment-short-update-activate-04MAY23', 'Activate WooPay', 'https://theatrum.ssl/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'actioned', '', NULL, NULL),
(848, 36, 'woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTA', 'Activate WooPay Test A', 'https://theatrum.ssl/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(849, 36, 'woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA', 'unactioned', '', NULL, NULL),
(850, 37, 'woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTB', 'Activate WooPay Test B', 'https://theatrum.ssl/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(851, 37, 'woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTA', 'unactioned', '', NULL, NULL),
(852, 38, 'woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTC', 'Activate WooPay Test C', 'https://theatrum.ssl/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(853, 38, 'woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTC', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTC', 'unactioned', '', NULL, NULL),
(854, 39, 'woopay-beta-merchantrecruitment-short-activate-06MAY23-TESTD', 'Activate WooPay Test D', 'https://theatrum.ssl/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(855, 39, 'woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTD', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-06MAY23-TESTD', 'unactioned', '', NULL, NULL),
(856, 40, 'woopay-beta-merchantrecruitment-short-activate-button-09MAY23', 'Activate WooPay', 'https://theatrum.ssl/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(857, 40, 'woopay-beta-merchantrecruitment-short-activate-learnmore-button2-09MAY23', 'Learn More', 'https://woo.com/woopay-businesses/?utm_source=inbox_note&utm_medium=product&utm_campaign=woopay-beta-merchantrecruitment-short-activate-learnmore-button2-09MAY23', 'unactioned', '', NULL, NULL),
(858, 41, 'woopay-beta-merchantrecruitment-short-update-WCPay-09MAY23', 'Update WooCommerce Payments', 'https://theatrum.ssl/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(859, 41, 'woopay-beta-merchantrecruitment-short-update-activate-09MAY23', 'Activate WooPay', 'https://theatrum.ssl/wp-admin/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments&method=platform_checkout', 'unactioned', '', NULL, NULL),
(860, 42, 'woocommerce-WCStripe-May-2023-updated-needed-Plugin-Settings', 'See available updates', 'https://theatrum.ssl/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(861, 42, 'woocommerce-WCStripe-May-2023-updated-needed-Plugin-Settings-dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(862, 43, 'woocommerce-WCPayments-June-2023-updated-needed-Plugin-Settings', 'See available updates', 'https://theatrum.ssl/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(863, 43, 'woocommerce-WCPayments-June-2023-updated-needed-Dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(864, 44, 'woocommerce-WCSubscriptions-June-2023-updated-needed-Plugin-Settings', 'See available updates', 'https://theatrum.ssl/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(865, 44, 'woocommerce-WCSubscriptions-June-2023-updated-needed-dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(866, 45, 'woocommerce-WCReturnsWarranty-June-2023-updated-needed', 'See available updates', 'https://theatrum.ssl/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(867, 45, 'woocommerce-WCReturnsWarranty-June-2023-updated-needed', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(868, 46, 'woocommerce-WCOPC-June-2023-updated-needed', 'See available updates', 'https://theatrum.ssl/wp-admin/plugins.php?plugin_status=all', 'actioned', '', NULL, NULL),
(869, 46, 'woocommerce-WCOPC-June-2023-updated-needed', 'Dismiss', 'https://theatrum.ssl/wp-admin/#', 'actioned', '', NULL, NULL),
(870, 47, 'woocommerce-WCGC-July-2023-update-needed', 'See available updates', 'https://theatrum.ssl/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(871, 47, 'woocommerce-WCGC-July-2023-update-needed', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(872, 48, 'learn-more', 'Learn more', 'https://woo.com/document/fedex/?utm_medium=product&utm_source=inbox_note&utm_campaign=learn-more#july-2023-api-outage', 'unactioned', '', NULL, NULL),
(873, 49, 'plugin-list', 'See available updates', 'https://theatrum.ssl/wp-admin/plugins.php?plugin_status=all', 'unactioned', '', NULL, NULL),
(874, 49, 'dismiss', 'Dismiss', 'https://theatrum.ssl/wp-admin/admin.php?page=wc-admin', 'actioned', '', NULL, NULL),
(875, 50, 'woocommerce-WCStripe-Aug-2023-update-needed', 'See available updates', 'https://theatrum.ssl/wp-admin/update-core.php?', 'unactioned', '', NULL, NULL),
(876, 50, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(877, 51, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(878, 52, 'woocommerce-WooPayments-Aug-2023-update-needed', 'See available updates', 'https://theatrum.ssl/wp-admin/update-core.php?', 'unactioned', '', NULL, NULL),
(879, 52, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(880, 53, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(881, 54, 'avalara_q3-2023_noAvaTax', 'Automate my sales tax', 'https://woo.com/products/woocommerce-avatax/?utm_source=inbox_note&utm_medium=product&utm_campaign=avalara_q3-2023_noAvaTax', 'unactioned', '', NULL, NULL),
(882, 55, 'woo-activation-survey-blockers-survey-button-22AUG23', 'Take our short survey', 'https://woocommerce.survey.fm/getting-started-with-woo', 'unactioned', '', NULL, NULL),
(883, 56, 'woocommerce-usermeta-Sept2023-productvendors', 'See available updates', 'https://theatrum.ssl/wp-admin/plugins.php', 'unactioned', '', NULL, NULL),
(884, 56, 'dismiss', 'Dismiss', 'https://theatrum.ssl/wp-admin/#', 'actioned', '', NULL, NULL),
(885, 57, 'woocommerce-STRIPE-Oct-2023-update-needed', 'See available updates', 'https://theatrum.ssl/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(886, 57, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(887, 58, 'amazon-mcf-review-button-2023-12-07', 'Leave a review', 'https://woo.com/products/woocommerce-amazon-fulfillment/?review&utm_source=inbox_note&utm_medium=product&utm_campaign=amazon-mcf-review-button-2023-12-07', 'actioned', '', NULL, NULL),
(888, 58, 'amazon-mcf-support-button-2023-12-07', 'Request support', 'https://woo.com/my-account/contact-support/?utm_source=inbox_note&utm_medium=product&utm_campaign=amazon-mcf-support-button-2023-12-07', 'actioned', '', NULL, NULL),
(889, 59, 'amazon_pay_ext-link_q1-24', 'Register your account now', 'https://eu.amazonpayments.com/2024-uk-woopricepromoregistration?utm_campaign=woo_price_promo&utm_medium=EM&utm_source=direct&utm_content=cta&utm_creative=&ld=EMUKAPA-woo_price_promo-direct-24Q1', 'actioned', '', NULL, NULL),
(890, 60, 'view_docs', 'Learn about Deposit schedules', 'https://woo.com/document/woopayments/deposits/deposit-schedule/?utm_source=inbox_note&utm_medium=product&utm_campaign=view_docs#available-funds', 'unactioned', '', NULL, NULL),
(891, 61, 'airwallex_q1_2024', 'Get started with Airwallex', 'https://woo.com/products/airwallexpayments/?utm_source=inbox_note&utm_medium=product&utm_campaign=airwallex_q1_2024', 'actioned', '', NULL, NULL),
(894, 64, 'update-db_run', 'Update WooCommerce Database', 'https://theatrum.ssl/wp-admin/network/settings.php?page=wp-migrate-db-pro&do_update_woocommerce=true', 'unactioned', 'wc_db_update', 'wc_db_update', 'wc_db_update_nonce'),
(895, 64, 'update-db_learn-more', 'Learn more about updates', 'https://woo.com/document/how-to-update-woocommerce/', 'unactioned', '', NULL, NULL) ;

#
# End of data contents of table `tu_wc_admin_note_actions`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_admin_notes`
#

DROP TABLE IF EXISTS `tu_wc_admin_notes`;


#
# Table structure of table `tu_wc_admin_notes`
#

CREATE TABLE `tu_wc_admin_notes` (
  `note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_520_ci,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT '0',
  `layout` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `icon` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_admin_notes`
#
INSERT INTO `tu_wc_admin_notes` ( `note_id`, `name`, `type`, `locale`, `title`, `content`, `content_data`, `status`, `source`, `date_created`, `date_reminder`, `is_snoozable`, `layout`, `image`, `is_deleted`, `is_read`, `icon`) VALUES
(1, 'wayflyer_bnpl_q4_2021', 'marketing', 'en_US', 'Grow your business with funding through Wayflyer', 'Fast, flexible financing to boost cash flow and help your business grow – one fee, no interest rates, penalties, equity, or personal guarantees. Based on your store’s performance, Wayflyer provides funding and analytical insights to invest in your business.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(2, 'wc_shipping_mobile_app_usps_q4_2021', 'marketing', 'en_US', 'Print and manage your shipping labels with WooCommerce Shipping and the WooCommerce Mobile App', 'Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href="https://woo.com/woocommerce-shipping/">WooCommerce Shipping</a> – all directly from your mobile device!', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(3, 'woocommerce-services', 'info', 'en_US', 'WooCommerce Shipping & Tax', 'WooCommerce Shipping &amp; Tax helps get your store "ready to sell" as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(4, 'your-first-product', 'info', 'en_US', 'Your first product', 'That’s huge! You’re well on your way to building a successful online store — now it’s time to think about how you’ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href="https://href.li/?https://woo.com/shipping" target="_blank">WooCommerce Shipping</a>.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(5, 'wc-admin-optimizing-the-checkout-flow', 'info', 'en_US', 'Optimizing the checkout flow', 'It’s crucial to get your store’s checkout as smooth as possible to avoid losing sales. Let’s take a look at how you can optimize the checkout experience for your shoppers.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(6, 'wc-payments-qualitative-feedback', 'info', 'en_US', 'WooCommerce Payments setup - let us know what you think', 'Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(7, 'share-your-feedback-on-paypal', 'info', 'en_US', 'Share your feedback on PayPal', 'Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(8, 'google_listings_and_ads_install', 'marketing', 'en_US', 'Drive traffic and sales with Google', 'Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(9, 'wc-subscriptions-security-update-3-0-15', 'info', 'en_US', 'WooCommerce Subscriptions security update!', 'We recently released an important security update to WooCommerce Subscriptions. To ensure your site’s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br /><br />Click the button below to view and update to the latest Subscriptions version, or log in to <a href="https://woo.com/my-dashboard">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br /><br />We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br /><br />If you have any questions we are here to help — just <a href="https://woo.com/my-account/create-a-ticket/">open a ticket</a>.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(10, 'woocommerce-core-update-5-4-0', 'info', 'en_US', 'Update to WooCommerce 5.4.1 now', 'WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(11, 'wcpay-promo-2020-11', 'marketing', 'en_US', 'wcpay-promo-2020-11', 'wcpay-promo-2020-11', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(12, 'wcpay-promo-2020-12', 'marketing', 'en_US', 'wcpay-promo-2020-12', 'wcpay-promo-2020-12', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(13, 'ppxo-pps-upgrade-paypal-payments-1', 'info', 'en_US', 'Get the latest PayPal extension for WooCommerce', 'Heads up! There’s a new PayPal on the block!<br /><br />Now is a great time to upgrade to our latest <a href="https://woo.com/products/woocommerce-paypal-payments/" target="_blank">PayPal extension</a> to continue to receive support and updates with PayPal.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(14, 'ppxo-pps-upgrade-paypal-payments-2', 'info', 'en_US', 'Upgrade your PayPal experience!', 'Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br /><br />Start using our <a href="https://woo.com/products/woocommerce-paypal-payments/" target="_blank">latest PayPal today</a> to continue to receive support and updates.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(15, 'woocommerce-core-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(16, 'woocommerce-blocks-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(17, 'woocommerce-core-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(18, 'woocommerce-blocks-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(19, 'habit-moment-survey', 'marketing', 'en_US', 'We’re all ears! Share your experience so far with WooCommerce', 'We’d love your input to shape the future of WooCommerce together. Feel free to share any feedback, ideas or suggestions that you have.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(20, 'woocommerce-core-paypal-march-2022-updated', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy PayPal Standard security updates for stores running WooCommerce (version 3.5 to 6.3). It’s recommended to disable PayPal Standard, and use <a href="https://woo.com/products/woocommerce-paypal-payments/" target="_blank">PayPal Payments</a> to accept PayPal.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(21, 'woocommerce-core-paypal-march-2022-updated-nopp', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy security updates related to PayPal Standard payment gateway for stores running WooCommerce (version 3.5 to 6.3).', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(22, 'pinterest_03_2022_update', 'marketing', 'en_US', 'Your Pinterest for WooCommerce plugin is out of date!', 'Update to the latest version of Pinterest for WooCommerce to continue using this plugin and keep your store connected with Pinterest. To update, visit <strong>Plugins &gt; Installed Plugins</strong>, and click on “update now” under Pinterest for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(23, 'store_setup_survey_survey_q2_2022', 'survey', 'en_US', 'How is your store setup going?', 'Our goal is to make sure you have all the right tools to start setting up your store in the smoothest way possible.\r\nWe’d love to know if we hit our mark and how we can improve. To collect your thoughts, we made a 2-minute survey.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(24, 'needs-update-eway-payment-gateway-rin-2022-12-20', 'update', 'en_US', 'Security vulnerability patched in WooCommerce Eway Gateway', 'In response to a potential vulnerability identified in WooCommerce Eway Gateway versions 3.1.0 to 3.5.0, we’ve worked to deploy security fixes and have released an updated version.\r\nNo external exploits have been detected, but we recommend you update to your latest supported version 3.1.26, 3.2.3, 3.3.1, 3.4.6, or 3.5.1', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(25, 'updated-eway-payment-gateway-rin-2022-12-20', 'update', 'en_US', 'WooCommerce Eway Gateway has been automatically updated', 'Your store is now running the latest secure version of WooCommerce Eway Gateway. We worked with the WordPress Plugins team to deploy a software update to stores running WooCommerce Eway Gateway (versions 3.1.0 to 3.5.0) in response to a security vulnerability that was discovered.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(26, 'ecomm-wc-navigation-survey-2023', 'info', 'en_US', 'Navigating WooCommerce on WordPress.com', 'We are improving the WooCommerce navigation on WordPress.com and would love your help to make it better! Please share your experience with us in this 2-minute survey.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(27, 'woopay-beta-merchantrecruitment-04MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'WooPay, a new express checkout feature built into WooCommerce Payments, is now available —and we’re inviting you to be one of the first to try it. \r\n<br><br>\r\nBoost conversions by offering your customers a simple, secure way to pay with a single click.\r\n<br><br>\r\nGet started in seconds.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(28, 'woocommerce-wcpay-march-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooCommerce Payments', '<strong>Your store requires a security update for WooCommerce Payments</strong>. Please update to the latest version of WooCommerce Payments immediately to address a potential vulnerability discovered on March 22. For more information on how to update, visit this WooCommerce Developer Blog Post.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(29, 'tap_to_pay_iphone_q2_2023_no_wcpay', 'marketing', 'en_US', 'Accept in-person contactless payments on your iPhone', 'Tap to Pay on iPhone and WooCommerce Payments is quick, secure, and simple to set up — no extra terminals or card readers are needed. Accept contactless debit and credit cards, Apple Pay, and other NFC digital wallets in person.', '[]', 'unactioned', 'woocommerce.com', '2024-03-25 18:52:21', NULL, 0, 'plain', '', 0, 0, 'info'),
(30, 'woocommerce-WCPreOrders-april-2023-update-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Pre-Orders extension', '<strong>Your store requires a security update for the WooCommerce Pre-Orders extension</strong>. Please update the WooCommerce Pre-Orders extension immediately to address a potential vulnerability discovered on April 11.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(31, 'woopay-beta-merchantrecruitment-update-04MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'WooPay, a new express checkout feature built into WooCommerce Payments, is now available — and you’re invited to try it. \r\n<br /><br />\r\nBoost conversions by offering your customers a simple, secure way to pay with a single click.\r\n<br /><br />\r\nUpdate WooCommerce Payments to get started.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(32, 'woopay-beta-existingmerchants-noaction-27APR23', 'info', 'en_US', 'WooPay is back!', 'Thanks for previously trying WooPay, the express checkout feature built into WooCommerce Payments. We’re excited to announce that WooPay availability has resumed. No action is required on your part.\r\n<br /><br />\r\nYou can now continue boosting conversions by offering your customers a simple, secure way to pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(33, 'woopay-beta-existingmerchants-update-27APR23', 'info', 'en_US', 'WooPay is back!', 'Thanks for previously trying WooPay, the express checkout feature built into WooCommerce Payments. We’re excited to announce that WooPay availability has resumed.\r\n<br /><br />\r\n\r\nUpdate to the latest WooCommerce Payments version to continue boosting conversions by offering your customers a simple, secure way to pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(34, 'woopay-beta-merchantrecruitment-short-04MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(35, 'woopay-beta-merchantrecruitment-short-update-04MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, our new express checkout feature. <br>Boost conversions by letting customers pay with a single click. <br><br>Update to the latest version of WooCommerce Payments to get started.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(36, 'woopay-beta-merchantrecruitment-short-06MAY23-TESTA', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(37, 'woopay-beta-merchantrecruitment-short-06MAY23-TESTB', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(38, 'woopay-beta-merchantrecruitment-short-06MAY23-TESTC', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(39, 'woopay-beta-merchantrecruitment-short-06MAY23-TESTD', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(40, 'woopay-beta-merchantrecruitment-short-09MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, a new express checkout feature for WooCommerce Payments. \r\n<br><br>\r\nBoost conversions by letting customers pay with a single click.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(41, 'woopay-beta-merchantrecruitment-short-update-09MAY23', 'info', 'en_US', 'Increase conversions with WooPay — our fastest checkout yet', 'Be one of the first to try WooPay, our new express checkout feature. <br>Boost conversions by letting customers pay with a single click. <br><br>Update to the latest version of WooCommerce Payments to get started.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(42, 'woocommerce-WCstripe-May-2023-updated-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Stripe plugin', '<strong>Your store requires a security update for the WooCommerce Stripe plugin</strong>. Please update the WooCommerce Stripe plugin immediately to address a potential vulnerability.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(43, 'woocommerce-WCPayments-June-2023-updated-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Payments', '<strong>Your store requires a security update for the WooCommerce Payments plugin</strong>. Please update the WooCommerce Payments plugin immediately to address a potential vulnerability.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(44, 'woocommerce-WCSubscriptions-June-2023-updated-needed', 'marketing', 'en_US', 'Action required: Security update of WooCommerce Subscriptions', '<strong>Your store requires a security update for the WooCommerce Subscriptions plugin</strong>. Please update the WooCommerce Subscriptions plugin immediately to address a potential vulnerability.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(45, 'woocommerce-WCReturnsWarranty-June-2023-updated-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Returns and Warranty Requests extension', '<strong>Your store requires a security update for the Returns and Warranty Requests extension</strong>.  Please update to the latest version of the WooCommerce Returns and Warranty Requests extension immediately to address a potential vulnerability discovered on May 31.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(46, 'woocommerce-WCOPC-June-2023-updated-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce One Page Checkout', '<strong>Your shop requires a security update to address a vulnerability in the WooCommerce One Page Checkout extension</strong>. The fix for this vulnerability was released for this extension on June 13th. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(47, 'woocommerce-WCGC-July-2023-update-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce GoCardless Extension', '<strong>Your shop requires a security update to address a vulnerability in the WooCommerce GoCardless extension</strong>. The fix for this vulnerability was released on July 4th. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(48, 'woocommerce-shipping-fedex-api-outage-2023-07-16', 'warning', 'en_US', 'Scheduled FedEx API outage — July 2023', 'On July 16 there will be a full outage of the FedEx API from 04:00 to 08:00 AM UTC. Due to planned maintenance by FedEx, you\'ll be unable to provide FedEx shipping rates during this time. Follow the link below for more information and recommendations on how to minimize impact.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(49, 'wcship-2023-07-hazmat-update-needed', 'update', 'en_US', 'Action required: USPS HAZMAT compliance update for WooCommerce Shipping & Tax extension', '<strong>Your store requires an update for the WooCommerce Shipping extension</strong>. Please update to the latest version of the WooCommerce Shipping &amp; Tax extension immediately to ensure compliance with new USPS HAZMAT rules currently in effect.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(50, 'woocommerce-WCStripe-Aug-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooCommerce Stripe plugin', '<strong>Your shop requires an important security update for the  WooCommerce Stripe plugin</strong>. The fix for this vulnerability was released on July 31. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(51, 'woocommerce-WCStripe-Aug-2023-security-updated', 'update', 'en_US', 'Security update of WooCommerce Stripe plugin', '<strong>Your store has been updated to the latest secure version of the WooCommerce Stripe plugin</strong>. This update was released on July 31.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(52, 'woocommerce-WooPayments-Aug-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooPayments (WooCommerce Payments) plugin', '<strong>Your shop requires an important security update for the WooPayments (WooCommerce Payments) extension</strong>. The fix for this vulnerability was released on July 31. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(53, 'woocommerce-WooPayments-Aug-2023-security-updated', 'update', 'en_US', 'Security update of WooPayments (WooCommerce Payments) plugin', '<strong>Your store has been updated to the more secure version of WooPayments (WooCommerce Payments)</strong>. This update was released on July 31.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(54, 'avalara_q3-2023_noAvaTax', 'marketing', 'en_US', 'Automatically calculate VAT in real time', 'Take the effort out of determining tax rates and sell confidently across borders with automated tax management from Avalara AvaTax— including built-in VAT calculation when you sell into or across the EU and UK. Save time and stay compliant when you let Avalara do the heavy lifting.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(55, 'woo-activation-survey-blockers-22AUG23', 'info', 'en_US', 'How can we help you get that first sale?', 'Your feedback is vital. Please take a minute to share your experience of setting up your new store and whether anything is preventing you from making those first few sales. Together, we can make Woo even better!', '[]', 'unactioned', 'woocommerce.com', '2024-03-25 20:50:44', NULL, 0, 'plain', '', 0, 0, 'info'),
(56, 'woocommerce-usermeta-Sept2023-productvendors', 'update', 'en_US', 'Your store requires a security update', '<strong>Your shop needs an update to address a vulnerability in WooCommerce.</strong> The fix was released on Sept 15. Please update WooCommerce to the latest version immediately. <a href="https://developer.woocommerce.com/2023/09/16/woocommerce-vulnerability-reintroduced-from-7-0-1/" />Read our developer update</a> for more information.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(57, 'woocommerce-STRIPE-Oct-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooCommerce Stripe Gateway', '<strong>Your shop requires a security update to address a vulnerability in the WooCommerce Stripe Gateway</strong>. The fix for this vulnerability was released on October 17. Please update immediately.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(58, 'amazon-mcf-reviews-2023-12-07', 'marketing', 'en_US', 'Enjoying Amazon MCF for WooCommerce?', 'We\'re Never Settle, the developers behind Amazon MCF for WooCommerce, and would be deeply honored to have your review. Reviews help immensely as other users can learn how MCF can solve their needs too! Not happy or need help? Please reach out for support and we’d love to make things right!', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(59, 'amazon_pay_reactivate_q1-24', 'marketing', 'en_US', 'Special offer: Activate 0% promo rate for Amazon Pay', 'For a limited time, Woo merchants who register with Amazon Pay can enjoy a promotional rate of 0% on all transaction fees for 30 days. Valid for businesses based in the United Kingdom. Terms and conditions apply.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(60, 'remove_estimated_deposits_2024', 'marketing', 'en_US', 'Estimated deposits are going away', 'To provide more accurate deposit information and support the expansion of instant deposits, estimated deposit details will no longer be available in WooPayments. We recommend upgrading to the latest version of WooPayments for more detailed balance status information.', '[]', 'pending', 'woocommerce.com', '2024-03-25 18:07:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(61, 'airwallex_q1_2024', 'marketing', 'en_US', 'Save big on foreign exchange (FX) fees', 'Boost your international sales by offering Apple Pay, Google Pay, and 60+ local payment methods with Airwallex. Save time and money by settling payments directly in USD, EUR, HKD, SGD, AUD, and more — without the extra FX fees. Simple, cost-effective, fast.', '[]', 'unactioned', 'woocommerce.com', '2024-03-25 18:52:21', NULL, 0, 'plain', '', 0, 0, 'info'),
(62, 'wc-refund-returns-page', 'info', 'en_US', 'Setup a Refund and Returns Policy page to boost your store\'s credibility.', 'We have created a sample draft Refund and Returns Policy page for you. Please have a look and update it to fit your store.', '[]', 'unactioned', 'woocommerce-core', '2024-03-25 18:07:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(63, 'wc-refund-returns-page', 'info', 'en_US', 'Setup a Refund and Returns Policy page to boost your store\'s credibility.', 'We have created a sample draft Refund and Returns Policy page for you. Please have a look and update it to fit your store.', '[]', 'unactioned', 'woocommerce-core', '2024-03-25 18:07:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(64, 'wc-update-db-reminder', 'update', 'en_US', 'WooCommerce database update required', 'WooCommerce has been updated! To keep things running smoothly, we have to update your database to the newest version. The database update process runs in the background and may take a little while, so please be patient. Advanced users can alternatively update via <a href="https://github.com/woocommerce/woocommerce/wiki/Upgrading-the-database-using-WP-CLI">WP CLI</a>.', '[]', 'unactioned', 'woocommerce-core', '2024-03-25 18:51:37', NULL, 0, 'plain', '', 0, 0, 'info'),
(65, 'wc-admin-wc-helper-connection', 'info', 'en_US', 'Connect to Woo.com', 'Connect to get important product notifications and updates.', '[]', 'unactioned', 'woocommerce-admin', '2024-03-25 18:51:40', NULL, 0, 'plain', '', 0, 0, 'info') ;

#
# End of data contents of table `tu_wc_admin_notes`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_category_lookup`
#

DROP TABLE IF EXISTS `tu_wc_category_lookup`;


#
# Table structure of table `tu_wc_category_lookup`
#

CREATE TABLE `tu_wc_category_lookup` (
  `category_tree_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_category_lookup`
#
INSERT INTO `tu_wc_category_lookup` ( `category_tree_id`, `category_id`) VALUES
(16, 16) ;

#
# End of data contents of table `tu_wc_category_lookup`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_customer_lookup`
#

DROP TABLE IF EXISTS `tu_wc_customer_lookup`;


#
# Table structure of table `tu_wc_customer_lookup`
#

CREATE TABLE `tu_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_customer_lookup`
#

#
# End of data contents of table `tu_wc_customer_lookup`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_download_log`
#

DROP TABLE IF EXISTS `tu_wc_download_log`;


#
# Table structure of table `tu_wc_download_log`
#

CREATE TABLE `tu_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_download_log`
#

#
# End of data contents of table `tu_wc_download_log`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_order_addresses`
#

DROP TABLE IF EXISTS `tu_wc_order_addresses`;


#
# Table structure of table `tu_wc_order_addresses`
#

CREATE TABLE `tu_wc_order_addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `address_type` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `first_name` text COLLATE utf8mb4_unicode_520_ci,
  `last_name` text COLLATE utf8mb4_unicode_520_ci,
  `company` text COLLATE utf8mb4_unicode_520_ci,
  `address_1` text COLLATE utf8mb4_unicode_520_ci,
  `address_2` text COLLATE utf8mb4_unicode_520_ci,
  `city` text COLLATE utf8mb4_unicode_520_ci,
  `state` text COLLATE utf8mb4_unicode_520_ci,
  `postcode` text COLLATE utf8mb4_unicode_520_ci,
  `country` text COLLATE utf8mb4_unicode_520_ci,
  `email` varchar(320) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address_type_order_id` (`address_type`,`order_id`),
  KEY `order_id` (`order_id`),
  KEY `email` (`email`(191)),
  KEY `phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_order_addresses`
#

#
# End of data contents of table `tu_wc_order_addresses`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_order_coupon_lookup`
#

DROP TABLE IF EXISTS `tu_wc_order_coupon_lookup`;


#
# Table structure of table `tu_wc_order_coupon_lookup`
#

CREATE TABLE `tu_wc_order_coupon_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_order_coupon_lookup`
#

#
# End of data contents of table `tu_wc_order_coupon_lookup`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_order_operational_data`
#

DROP TABLE IF EXISTS `tu_wc_order_operational_data`;


#
# Table structure of table `tu_wc_order_operational_data`
#

CREATE TABLE `tu_wc_order_operational_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `created_via` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `woocommerce_version` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `prices_include_tax` tinyint(1) DEFAULT NULL,
  `coupon_usages_are_counted` tinyint(1) DEFAULT NULL,
  `download_permission_granted` tinyint(1) DEFAULT NULL,
  `cart_hash` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `new_order_email_sent` tinyint(1) DEFAULT NULL,
  `order_key` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `order_stock_reduced` tinyint(1) DEFAULT NULL,
  `date_paid_gmt` datetime DEFAULT NULL,
  `date_completed_gmt` datetime DEFAULT NULL,
  `shipping_tax_amount` decimal(26,8) DEFAULT NULL,
  `shipping_total_amount` decimal(26,8) DEFAULT NULL,
  `discount_tax_amount` decimal(26,8) DEFAULT NULL,
  `discount_total_amount` decimal(26,8) DEFAULT NULL,
  `recorded_sales` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`),
  KEY `order_key` (`order_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_order_operational_data`
#

#
# End of data contents of table `tu_wc_order_operational_data`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_order_product_lookup`
#

DROP TABLE IF EXISTS `tu_wc_order_product_lookup`;


#
# Table structure of table `tu_wc_order_product_lookup`
#

CREATE TABLE `tu_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT '0',
  `product_gross_revenue` double NOT NULL DEFAULT '0',
  `coupon_amount` double NOT NULL DEFAULT '0',
  `tax_amount` double NOT NULL DEFAULT '0',
  `shipping_amount` double NOT NULL DEFAULT '0',
  `shipping_tax_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_order_product_lookup`
#

#
# End of data contents of table `tu_wc_order_product_lookup`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_order_stats`
#

DROP TABLE IF EXISTS `tu_wc_order_stats`;


#
# Table structure of table `tu_wc_order_stats`
#

CREATE TABLE `tu_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_paid` datetime DEFAULT '0000-00-00 00:00:00',
  `date_completed` datetime DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT '0',
  `total_sales` double NOT NULL DEFAULT '0',
  `tax_total` double NOT NULL DEFAULT '0',
  `shipping_total` double NOT NULL DEFAULT '0',
  `net_total` double NOT NULL DEFAULT '0',
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_order_stats`
#

#
# End of data contents of table `tu_wc_order_stats`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_order_tax_lookup`
#

DROP TABLE IF EXISTS `tu_wc_order_tax_lookup`;


#
# Table structure of table `tu_wc_order_tax_lookup`
#

CREATE TABLE `tu_wc_order_tax_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT '0',
  `order_tax` double NOT NULL DEFAULT '0',
  `total_tax` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`tax_rate_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_order_tax_lookup`
#

#
# End of data contents of table `tu_wc_order_tax_lookup`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_orders`
#

DROP TABLE IF EXISTS `tu_wc_orders`;


#
# Table structure of table `tu_wc_orders`
#

CREATE TABLE `tu_wc_orders` (
  `id` bigint(20) unsigned NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `currency` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `tax_amount` decimal(26,8) DEFAULT NULL,
  `total_amount` decimal(26,8) DEFAULT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `billing_email` varchar(320) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_created_gmt` datetime DEFAULT NULL,
  `date_updated_gmt` datetime DEFAULT NULL,
  `parent_order_id` bigint(20) unsigned DEFAULT NULL,
  `payment_method` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_method_title` text COLLATE utf8mb4_unicode_520_ci,
  `transaction_id` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_520_ci,
  `customer_note` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `date_created` (`date_created_gmt`),
  KEY `customer_id_billing_email` (`customer_id`,`billing_email`(171)),
  KEY `billing_email` (`billing_email`(191)),
  KEY `type_status_date` (`type`,`status`,`date_created_gmt`),
  KEY `parent_order_id` (`parent_order_id`),
  KEY `date_updated` (`date_updated_gmt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_orders`
#

#
# End of data contents of table `tu_wc_orders`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_orders_meta`
#

DROP TABLE IF EXISTS `tu_wc_orders_meta`;


#
# Table structure of table `tu_wc_orders_meta`
#

CREATE TABLE `tu_wc_orders_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `meta_key_value` (`meta_key`(100),`meta_value`(82)),
  KEY `order_id_meta_key_meta_value` (`order_id`,`meta_key`(100),`meta_value`(82))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_orders_meta`
#

#
# End of data contents of table `tu_wc_orders_meta`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_product_attributes_lookup`
#

DROP TABLE IF EXISTS `tu_wc_product_attributes_lookup`;


#
# Table structure of table `tu_wc_product_attributes_lookup`
#

CREATE TABLE `tu_wc_product_attributes_lookup` (
  `product_id` bigint(20) NOT NULL,
  `product_or_parent_id` bigint(20) NOT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `term_id` bigint(20) NOT NULL,
  `is_variation_attribute` tinyint(1) NOT NULL,
  `in_stock` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_or_parent_id`,`term_id`,`product_id`,`taxonomy`),
  KEY `is_variation_attribute_term_id` (`is_variation_attribute`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_product_attributes_lookup`
#

#
# End of data contents of table `tu_wc_product_attributes_lookup`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_product_download_directories`
#

DROP TABLE IF EXISTS `tu_wc_product_download_directories`;


#
# Table structure of table `tu_wc_product_download_directories`
#

CREATE TABLE `tu_wc_product_download_directories` (
  `url_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`url_id`),
  KEY `url` (`url`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_product_download_directories`
#
INSERT INTO `tu_wc_product_download_directories` ( `url_id`, `url`, `enabled`) VALUES
(1, 'file://C:/Library/Theatrum Universum/wp-root/wp-content/uploads/woocommerce_uploads/', 1),
(2, 'https://theatrum.ssl/wp-content/uploads/woocommerce_uploads/', 1) ;

#
# End of data contents of table `tu_wc_product_download_directories`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_product_meta_lookup`
#

DROP TABLE IF EXISTS `tu_wc_product_meta_lookup`;


#
# Table structure of table `tu_wc_product_meta_lookup`
#

CREATE TABLE `tu_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT '0',
  `downloadable` tinyint(1) DEFAULT '0',
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT '0',
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT '0',
  `average_rating` decimal(3,2) DEFAULT '0.00',
  `total_sales` bigint(20) DEFAULT '0',
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_product_meta_lookup`
#
INSERT INTO `tu_wc_product_meta_lookup` ( `product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`, `tax_status`, `tax_class`) VALUES
(69, 'unus', 0, 0, '1000.0000', '1000.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(70, 'opus', 0, 0, '3000.0000', '3000.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(71, 'ordinatio', 0, 0, '5000.0000', '5000.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', '') ;

#
# End of data contents of table `tu_wc_product_meta_lookup`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_rate_limits`
#

DROP TABLE IF EXISTS `tu_wc_rate_limits`;


#
# Table structure of table `tu_wc_rate_limits`
#

CREATE TABLE `tu_wc_rate_limits` (
  `rate_limit_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rate_limit_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `rate_limit_expiry` bigint(20) unsigned NOT NULL,
  `rate_limit_remaining` smallint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rate_limit_id`),
  UNIQUE KEY `rate_limit_key` (`rate_limit_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_rate_limits`
#

#
# End of data contents of table `tu_wc_rate_limits`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_reserved_stock`
#

DROP TABLE IF EXISTS `tu_wc_reserved_stock`;


#
# Table structure of table `tu_wc_reserved_stock`
#

CREATE TABLE `tu_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT '0',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_reserved_stock`
#

#
# End of data contents of table `tu_wc_reserved_stock`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_tax_rate_classes`
#

DROP TABLE IF EXISTS `tu_wc_tax_rate_classes`;


#
# Table structure of table `tu_wc_tax_rate_classes`
#

CREATE TABLE `tu_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_tax_rate_classes`
#
INSERT INTO `tu_wc_tax_rate_classes` ( `tax_rate_class_id`, `name`, `slug`) VALUES
(1, 'Reduced rate', 'reduced-rate'),
(2, 'Zero rate', 'zero-rate') ;

#
# End of data contents of table `tu_wc_tax_rate_classes`
# --------------------------------------------------------



#
# Delete any existing table `tu_wc_webhooks`
#

DROP TABLE IF EXISTS `tu_wc_webhooks`;


#
# Table structure of table `tu_wc_webhooks`
#

CREATE TABLE `tu_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wc_webhooks`
#

#
# End of data contents of table `tu_wc_webhooks`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_api_keys`
#

DROP TABLE IF EXISTS `tu_woocommerce_api_keys`;


#
# Table structure of table `tu_woocommerce_api_keys`
#

CREATE TABLE `tu_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_api_keys`
#

#
# End of data contents of table `tu_woocommerce_api_keys`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `tu_woocommerce_attribute_taxonomies`;


#
# Table structure of table `tu_woocommerce_attribute_taxonomies`
#

CREATE TABLE `tu_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_attribute_taxonomies`
#

#
# End of data contents of table `tu_woocommerce_attribute_taxonomies`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `tu_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `tu_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `tu_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_downloadable_product_permissions`
#

#
# End of data contents of table `tu_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_log`
#

DROP TABLE IF EXISTS `tu_woocommerce_log`;


#
# Table structure of table `tu_woocommerce_log`
#

CREATE TABLE `tu_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_log`
#

#
# End of data contents of table `tu_woocommerce_log`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `tu_woocommerce_order_itemmeta`;


#
# Table structure of table `tu_woocommerce_order_itemmeta`
#

CREATE TABLE `tu_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_order_itemmeta`
#

#
# End of data contents of table `tu_woocommerce_order_itemmeta`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_order_items`
#

DROP TABLE IF EXISTS `tu_woocommerce_order_items`;


#
# Table structure of table `tu_woocommerce_order_items`
#

CREATE TABLE `tu_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_order_items`
#

#
# End of data contents of table `tu_woocommerce_order_items`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_payment_tokenmeta`
#

DROP TABLE IF EXISTS `tu_woocommerce_payment_tokenmeta`;


#
# Table structure of table `tu_woocommerce_payment_tokenmeta`
#

CREATE TABLE `tu_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_payment_tokenmeta`
#

#
# End of data contents of table `tu_woocommerce_payment_tokenmeta`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_payment_tokens`
#

DROP TABLE IF EXISTS `tu_woocommerce_payment_tokens`;


#
# Table structure of table `tu_woocommerce_payment_tokens`
#

CREATE TABLE `tu_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_payment_tokens`
#

#
# End of data contents of table `tu_woocommerce_payment_tokens`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_sessions`
#

DROP TABLE IF EXISTS `tu_woocommerce_sessions`;


#
# Table structure of table `tu_woocommerce_sessions`
#

CREATE TABLE `tu_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_sessions`
#
INSERT INTO `tu_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(7, '1', 'a:8:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:793:"a:28:{s:2:"id";s:1:"1";s:13:"date_modified";s:25:"2024-03-25T19:59:51+00:00";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:21:"anna@theatrummundi.co";s:7:"address";s:0:"";s:9:"address_1";s:0:"";s:9:"address_2";s:0:"";s:4:"city";s:0:"";s:5:"state";s:2:"CA";s:8:"postcode";s:0:"";s:7:"country";s:2:"US";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";s:14:"shipping_phone";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_1";s:0:"";s:18:"shipping_address_2";s:0:"";s:13:"shipping_city";s:0:"";s:14:"shipping_state";s:2:"CA";s:17:"shipping_postcode";s:0:"";s:16:"shipping_country";s:2:"US";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:9:"meta_data";s:2:"[]";}";s:23:"chosen_shipping_methods";s:29:"a:1:{i:0;s:11:"flat_rate:0";}";}', 1711569950) ;

#
# End of data contents of table `tu_woocommerce_sessions`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_shipping_zone_locations`
#

DROP TABLE IF EXISTS `tu_woocommerce_shipping_zone_locations`;


#
# Table structure of table `tu_woocommerce_shipping_zone_locations`
#

CREATE TABLE `tu_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_shipping_zone_locations`
#
INSERT INTO `tu_woocommerce_shipping_zone_locations` ( `location_id`, `zone_id`, `location_code`, `location_type`) VALUES
(1, 1, 'US', 'country') ;

#
# End of data contents of table `tu_woocommerce_shipping_zone_locations`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_shipping_zone_methods`
#

DROP TABLE IF EXISTS `tu_woocommerce_shipping_zone_methods`;


#
# Table structure of table `tu_woocommerce_shipping_zone_methods`
#

CREATE TABLE `tu_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_shipping_zone_methods`
#
INSERT INTO `tu_woocommerce_shipping_zone_methods` ( `zone_id`, `instance_id`, `method_id`, `method_order`, `is_enabled`) VALUES
(1, 1, 'free_shipping', 1, 1) ;

#
# End of data contents of table `tu_woocommerce_shipping_zone_methods`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_shipping_zones`
#

DROP TABLE IF EXISTS `tu_woocommerce_shipping_zones`;


#
# Table structure of table `tu_woocommerce_shipping_zones`
#

CREATE TABLE `tu_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_shipping_zones`
#
INSERT INTO `tu_woocommerce_shipping_zones` ( `zone_id`, `zone_name`, `zone_order`) VALUES
(1, 'United States (US)', 0) ;

#
# End of data contents of table `tu_woocommerce_shipping_zones`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `tu_woocommerce_tax_rate_locations`;


#
# Table structure of table `tu_woocommerce_tax_rate_locations`
#

CREATE TABLE `tu_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_tax_rate_locations`
#

#
# End of data contents of table `tu_woocommerce_tax_rate_locations`
# --------------------------------------------------------



#
# Delete any existing table `tu_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `tu_woocommerce_tax_rates`;


#
# Table structure of table `tu_woocommerce_tax_rates`
#

CREATE TABLE `tu_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_woocommerce_tax_rates`
#

#
# End of data contents of table `tu_woocommerce_tax_rates`
# --------------------------------------------------------



#
# Delete any existing table `tu_wpdm_social_shares`
#

DROP TABLE IF EXISTS `tu_wpdm_social_shares`;


#
# Table structure of table `tu_wpdm_social_shares`
#

CREATE TABLE `tu_wpdm_social_shares` (
  `ID` int(9) NOT NULL AUTO_INCREMENT,
  `post_id` int(9) NOT NULL DEFAULT '0',
  `url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `channel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_id` int(9) NOT NULL DEFAULT '0',
  `user_agent` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wpdm_social_shares`
#

#
# End of data contents of table `tu_wpdm_social_shares`
# --------------------------------------------------------



#
# Delete any existing table `tu_wpspf_form_fields`
#

DROP TABLE IF EXISTS `tu_wpspf_form_fields`;


#
# Table structure of table `tu_wpspf_form_fields`
#

CREATE TABLE `tu_wpspf_form_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(11) NOT NULL DEFAULT '1',
  `field_name` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `field_position` int(11) NOT NULL DEFAULT '100',
  `field_other_attributes` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `form_id` (`form_id`,`field_name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wpspf_form_fields`
#
INSERT INTO `tu_wpspf_form_fields` ( `id`, `form_id`, `field_name`, `field_position`, `field_other_attributes`) VALUES
(1, 1, 'customer_first_name', 1, '{"wpspf_field_type":"text","wpspf_input_field_id":"customer_first_name","wpspf_input_field_name":"customer_first_name","wpspf_input_field_class":"form-field","wpspf_input_field_label":"First Name","wpspf_input_field_position":"1","wpspf_input_field_is_required":"true","wpspf_input_field_placeholder":"Enter your first name","wpspf_input_field_default_value":""}'),
(2, 1, 'customer_last_name', 2, '{"field_id":"2","wpspf_field_type":"text","wpspf_input_field_id":"customer_last_name","wpspf_input_field_name":"customer_last_name","wpspf_input_field_class":"form-field","wpspf_input_field_label":"Last Name","wpspf_input_field_position":"2","wpspf_input_field_is_required":"true","wpspf_input_field_placeholder":"Enter your last name","wpspf_input_field_default_value":""}'),
(3, 1, 'payment_amount', 4, '{"wpspf_field_type":"text","wpspf_input_field_id":"payment_amount","wpspf_input_field_name":"payment_amount","wpspf_input_field_class":"form-field","wpspf_input_field_label":"Payment Amount","wpspf_input_field_position":"4","wpspf_input_field_is_required":"true","wpspf_input_field_placeholder":"Enter payment amount","wpspf_input_field_default_value":"100"}'),
(4, 1, 'invoice_number', 5, '{"wpspf_field_type":"text","wpspf_input_field_id":"invoice_number","wpspf_input_field_name":"invoice_number","wpspf_input_field_class":"form-field","wpspf_input_field_label":"Invoice Number(s) (Optional)","wpspf_input_field_position":"5","wpspf_input_field_is_required":"false","wpspf_input_field_placeholder":"Enter invoice number","wpspf_input_field_default_value":""}'),
(5, 1, 'service_address', 7, '{"wpspf_field_type":"text","wpspf_input_field_id":"service_address","wpspf_input_field_name":"service_address","wpspf_input_field_class":"form-field","wpspf_input_field_label":"Service Address","wpspf_input_field_position":"7","wpspf_input_field_is_required":"true","wpspf_input_field_placeholder":"Enter you address","wpspf_input_field_default_value":""}'),
(6, 1, 'service_city', 8, '{"wpspf_field_type":"text","wpspf_input_field_id":"service_city","wpspf_input_field_name":"service_city","wpspf_input_field_class":"form-field","wpspf_input_field_label":"City","wpspf_input_field_position":"8","wpspf_input_field_is_required":"true","wpspf_input_field_placeholder":"Enter your city","wpspf_input_field_default_value":""}'),
(7, 1, 'service_state', 9, '{"wpspf_field_type":"text","wpspf_input_field_id":"service_state","wpspf_input_field_name":"service_state","wpspf_input_field_class":"form-field","wpspf_input_field_label":"State","wpspf_input_field_position":"9","wpspf_input_field_is_required":"true","wpspf_input_field_placeholder":"Enter your state","wpspf_input_field_default_value":""}'),
(8, 1, 'service_zipcode', 10, '{"wpspf_field_type":"text","wpspf_input_field_id":"service_zipcode","wpspf_input_field_name":"service_zipcode","wpspf_input_field_class":"form-field","wpspf_input_field_label":"Zip Code","wpspf_input_field_position":"10","wpspf_input_field_is_required":"true","wpspf_input_field_placeholder":"Enter zip code","wpspf_input_field_default_value":""}'),
(9, 1, 'service_country', 11, '{"wpspf_field_type":"text","wpspf_input_field_id":"service_country","wpspf_input_field_name":"service_country","wpspf_input_field_class":"form-field","wpspf_input_field_label":"Country","wpspf_input_field_position":"11","wpspf_input_field_is_required":"true","wpspf_input_field_placeholder":"Enter your country","wpspf_input_field_default_value":""}'),
(10, 1, 'email_address', 3, '{"field_id":"15","wpspf_field_type":"email","wpspf_input_field_id":"email_address","wpspf_input_field_name":"email_address","wpspf_input_field_class":"form-field","wpspf_input_field_label":"Email Address","wpspf_input_field_position":"3","wpspf_input_field_is_required":"true","wpspf_input_field_placeholder":"Enter your email address","wpspf_input_field_default_value":""}'),
(11, 1, 'servicetype', 12, '{"field_id":"16","wpspf_field_type":"select","wpspf_input_field_id":"servicetype","wpspf_input_field_name":"servicetype","wpspf_input_field_class":"form-field","wpspf_input_field_label":"Service Type","wpspf_input_field_options":"Plugin Development | Plugin Customization | Theme Development","wpspf_input_field_position":"12","wpspf_input_field_is_required":"false"}'),
(12, 1, 'company_name', 6, '{"wpspf_field_type":"text","wpspf_input_field_id":"company_name","wpspf_input_field_name":"company_name","wpspf_input_field_class":"form-field","wpspf_input_field_label":"Company Name","wpspf_input_field_position":"6","wpspf_input_field_is_required":"true","wpspf_input_field_placeholder":"Enter your company name","wpspf_input_field_default_value":""}') ;

#
# End of data contents of table `tu_wpspf_form_fields`
# --------------------------------------------------------



#
# Delete any existing table `tu_wpspf_payment_entry`
#

DROP TABLE IF EXISTS `tu_wpspf_payment_entry`;


#
# Table structure of table `tu_wpspf_payment_entry`
#

CREATE TABLE `tu_wpspf_payment_entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_first_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `customer_last_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email_address` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `payment_amount` decimal(10,2) NOT NULL,
  `payment_status` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wpspf_payment_entry`
#

#
# End of data contents of table `tu_wpspf_payment_entry`
# --------------------------------------------------------



#
# Delete any existing table `tu_wpspf_payment_entry_meta`
#

DROP TABLE IF EXISTS `tu_wpspf_payment_entry_meta`;


#
# Table structure of table `tu_wpspf_payment_entry_meta`
#

CREATE TABLE `tu_wpspf_payment_entry_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_id` int(11) NOT NULL,
  `field_key` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `field_value` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `tu_wpspf_payment_entry_meta`
#

#
# End of data contents of table `tu_wpspf_payment_entry_meta`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

